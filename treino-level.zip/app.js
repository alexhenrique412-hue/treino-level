/**
 * IronLevel - Gym & Running Tracker with Level Up System
 * Rule: 2 hours of training = 1 point
 */

// --- HAPTIC FEEDBACK (Vibration for Mobile Phones) ---
function triggerHaptic(type = "light") {
  if (!navigator.vibrate) return;
  try {
    if (type === "light") navigator.vibrate(30);
    else if (type === "medium") navigator.vibrate(55);
    else if (type === "success") navigator.vibrate([40, 30, 80]);
    else if (type === "levelup") navigator.vibrate([100, 50, 100, 50, 200]);
  } catch (e) {}
}

// --- AUDIO SYNTHESIZER (Web Audio API - Offline & Instant) ---
class SoundEffects {
  constructor() {
    this.ctx = null;
  }
  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }
  playBeep(freq = 600, duration = 0.15) {
    triggerHaptic("medium");
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
    gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + duration);
  }
  playCheck() {
    triggerHaptic("success");
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(now + 0.12);
  }
  playDone() {
    this.playCheck();
  }
  playLevelUp() {
    triggerHaptic("levelup");
    this.init();
    if (!this.ctx) return;
    const notes = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99]; // C E G C E G
    notes.forEach((freq, idx) => {
      setTimeout(() => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();
        osc.stop(this.ctx.currentTime + 0.35);
      }, idx * 110);
    });
  }
}
const sfx = new SoundEffects();

// --- HERO / HUNTER RANK DEFINITIONS (SOLO LEVELING RPG SYSTEM) ---
const LEVELS = [
  { level: 1, name: "Novato Desperto", rankTier: "E", badge: "E", rank: "Iniciando a Jornada", minPoints: 0, maxPoints: 1.5 },
  { level: 2, name: "Caçador em Treino", rankTier: "D", badge: "D", rank: "Criando o Hábito", minPoints: 1.5, maxPoints: 4.0 },
  { level: 3, name: "Caçador Notável", rankTier: "C", badge: "C", rank: "Disciplina de Aço", minPoints: 4.0, maxPoints: 8.0 },
  { level: 4, name: "Guerreiro de Elite", rankTier: "B", badge: "B", rank: "Ritmo Imparável", minPoints: 8.0, maxPoints: 15.0 },
  { level: 5, name: "Mestre dos Pesos", rankTier: "A", badge: "A", rank: "Físico em Construção", minPoints: 15.0, maxPoints: 25.0 },
  { level: 6, name: "Caçador Nacional", rankTier: "S", badge: "S", rank: "Força Brutal", minPoints: 25.0, maxPoints: 40.0 },
  { level: 7, name: "Lenda Suprema", rankTier: "S+", badge: "S+", rank: "Inspiração Total", minPoints: 40.0, maxPoints: 60.0 },
  { level: 8, name: "Monarca Supremo", rankTier: "SS", badge: "SS", rank: "Poder Máximo Absoluto", minPoints: 60.0, maxPoints: 9999 }
];

// Helper: Render Hero Rank Badge HTML
function getRankBadgeHtml(rankTier, isSupreme = false) {
  const raw = String(rankTier || 'E').toUpperCase().trim();
  let cssClass = 'rank-e';
  let label = 'RANK E';

  if (isSupreme || raw === 'SS' || raw.includes('SS')) {
    cssClass = 'rank-ss-supreme';
    label = 'RANK SS';
  } else if (raw === 'S+' || raw === 'S-PLUS') {
    cssClass = 'rank-s-plus';
    label = 'RANK S+';
  } else if (raw === 'S') {
    cssClass = 'rank-s';
    label = 'RANK S';
  } else if (raw === 'A') {
    cssClass = 'rank-a';
    label = 'RANK A';
  } else if (raw === 'B') {
    cssClass = 'rank-b';
    label = 'RANK B';
  } else if (raw === 'C') {
    cssClass = 'rank-c';
    label = 'RANK C';
  } else if (raw === 'D') {
    cssClass = 'rank-d';
    label = 'RANK D';
  } else {
    cssClass = 'rank-e';
    label = 'RANK E';
  }

  return `<span class="hero-rank-badge ${cssClass}">${label}</span>`;
}

// --- DEFAULT WORKOUT ROUTINES (7 DAYS) ---
const DEFAULT_WORKOUT_ROUTINES = {
  0: { // Segunda
    dayName: "Segunda-feira",
    title: "Peito & Tríceps",
    exercises: [
      { id: "e1", name: "Supino Reto com Barra", sets: 4, reps: "8-10", weight: 40, rest: 60, notes: "Cadência controlada na descida", done: false },
      { id: "e2", name: "Supino Inclinado com Halteres", sets: 4, reps: "10-12", weight: 18, rest: 60, notes: "Amplitude máxima e peitoral aberto", done: false },
      { id: "e3", name: "Crucifixo na Polia (Crossover)", sets: 3, reps: "12-15", weight: 15, rest: 45, notes: "Aperte 1s no pico de contração", done: false, isBiSet: true },
      { id: "e4", name: "Tríceps Corda na Polia", sets: 4, reps: "12-15", weight: 20, rest: 45, notes: "Abra a corda no final do movimento", done: false, isBiSet: true },
      { id: "e5", name: "Tríceps Francês Halter", sets: 3, reps: "10-12", weight: 14, rest: 60, notes: "Cotovelos fechados apontando para o teto", done: false }
    ]
  },
  1: { // Terça
    dayName: "Terça-feira",
    title: "Costas & Bíceps",
    exercises: [
      { id: "e6", name: "Puxada Frontal Alta", sets: 4, reps: "8-10", weight: 45, rest: 60, notes: "Puxe até o peitoral", done: false },
      { id: "e7", name: "Remada Baixa Triângulo", sets: 4, reps: "10-12", weight: 40, rest: 60, notes: "Costas retas", done: false },
      { id: "e8", name: "Remada Curvada com Barra", sets: 3, reps: "8-10", weight: 35, rest: 90, notes: "Pegada pronada", done: false },
      { id: "e9", name: "Rosca Direta com Barra W", sets: 4, reps: "10-12", weight: 20, rest: 60, notes: "Sem roubar com a coluna", done: false },
      { id: "e10", name: "Rosca Martelo Halteres", sets: 3, reps: "12-15", weight: 12, rest: 45, notes: "Foco no braquial", done: false }
    ]
  },
  2: { // Quarta
    dayName: "Quarta-feira",
    title: "Pernas Completo & Panturrilha",
    exercises: [
      { id: "e11", name: "Agachamento Livre", sets: 4, reps: "8-10", weight: 50, rest: 90, notes: "Desça até 90 graus ou mais", done: false },
      { id: "e12", name: "Leg Press 45°", sets: 4, reps: "10-12", weight: 120, rest: 90, notes: "Pés na largura dos ombros", done: false },
      { id: "e13", name: "Cadeira Extensora", sets: 3, reps: "12-15", weight: 35, rest: 45, notes: "Segura 1s em cima e volta lento", done: false, isBiSet: true },
      { id: "e14", name: "Mesa Flexora", sets: 4, reps: "10-12", weight: 30, rest: 60, notes: "Posterior de coxa em tensão constante", done: false, isBiSet: true },
      { id: "e15", name: "Panturrilha em Pé", sets: 4, reps: "15-20", weight: 40, rest: 45, notes: "Alongamento completo", done: false }
    ]
  },
  3: { // Quinta
    dayName: "Quinta-feira",
    title: "Ombros & Trapézio",
    exercises: [
      { id: "e16", name: "Desenvolvimento com Halteres", sets: 4, reps: "8-10", weight: 16, rest: 60, notes: "Controle na descida", done: false },
      { id: "e17", name: "Elevação Lateral com Halteres", sets: 4, reps: "12-15", weight: 8, rest: 45, notes: "Cotovelos levemente flexionados", done: false },
      { id: "e18", name: "Crucifixo Invertido", sets: 3, reps: "12-15", weight: 6, rest: 45, notes: "Deltoide posterior", done: false },
      { id: "e19", name: "Encolhimento com Barra", sets: 4, reps: "12-15", weight: 50, rest: 45, notes: "Trapézio alto", done: false }
    ]
  },
  4: { // Sexta
    dayName: "Sexta-feira",
    title: "Braços & Abdômen",
    exercises: [
      { id: "e20", name: "Rosca Scott na Máquina", sets: 3, reps: "10-12", weight: 25, rest: 60, notes: "Isolamento de bíceps", done: false },
      { id: "e21", name: "Tríceps Testa com Halteres", sets: 3, reps: "10-12", weight: 10, rest: 60, notes: "Estabilidade dos braços", done: false },
      { id: "e22", name: "Rosca Concentrada", sets: 3, reps: "12", weight: 10, rest: 45, notes: "Pico de bíceps", done: false },
      { id: "e23", name: "Abdominal Infra no Banco", sets: 4, reps: "15-20", weight: 0, rest: 45, notes: "Pernas estendidas", done: false },
      { id: "e24", name: "Prancha Abdominal", sets: 3, reps: "45 seg", weight: 0, rest: 45, notes: "Abdômen contraído", done: false }
    ]
  },
  5: { // Sábado
    dayName: "Sábado",
    title: "Cardio & Funcional",
    exercises: [
      { id: "e25", name: "Corrida na Esteira ou Rua", sets: 1, reps: "30-40 min", weight: 0, rest: 0, notes: "Manter ritmo constante", done: false },
      { id: "e26", name: "Polichinelos & Pular Corda", sets: 3, reps: "2 min", weight: 0, rest: 60, notes: "Aquecimento aeróbico", done: false },
      { id: "e27", name: "Burpees", sets: 3, reps: "12", weight: 0, rest: 60, notes: "Explosão muscular", done: false }
    ]
  },
  6: { // Domingo
    dayName: "Domingo",
    title: "Descanso Ativo / Recuperação",
    exercises: [
      { id: "e28", name: "Caminhada Leve ao Ar Livre", sets: 1, reps: "30-45 min", weight: 0, rest: 0, notes: "Recuperação ativa", done: false },
      { id: "e29", name: "Alongamento e Mobilidade", sets: 1, reps: "15 min", weight: 0, rest: 0, notes: "Articulações e músculos", done: false }
    ]
  }
};

// --- BADGES DEFINITION ---
const BADGES = [
  { id: "first_workout", name: "Primeiro Treino", icon: "🌱", desc: "Completou seu 1º treino", unlocked: false },
  { id: "streak_3", name: "Fogo Aceso", icon: "🔥", desc: "Sequência de 3 dias de treino", unlocked: false },
  { id: "streak_7", name: "Semana Blindada", icon: "🛡️", desc: "7 dias consecutivos treinando", unlocked: false },
  { id: "first_run", name: "Passada Firme", icon: "👟", desc: "Primeira corrida registrada", unlocked: false },
  { id: "run_5k", name: "5K Club", icon: "🏃‍♂️", desc: "Correu 5 km em uma única sessão", unlocked: false },
  { id: "hours_10", name: "10 Horas de Aço", icon: "⏱️", desc: "Acumulou 10 horas de treino", unlocked: false },
  { id: "double_workout", name: "Treino Duplo", icon: "⚡", desc: "Fez 2 sessões no mesmo dia", unlocked: false },
  { id: "points_10", name: "Dezena de Ouro", icon: "⭐", desc: "Alcançou 10 pontos totais", unlocked: false }
];

// --- APP STATE ---
const STATE = {
  user: {
    name: "Guerreiro",
    age: null,
    country: "Brasil",
    countryFlag: "🇧🇷",
    goal: "Hipertrofia",
    avatar: "G",
    photo: null,
    theme: "green",
    registered: false,
    memberNumber: null
  },
  // All-time totals:
  totalMinutes: 0, // Minutes trained (2h = 120min = 1 point)
  totalPoints: 0.0,
  currentLevel: 1,
  streakDays: 1,
  lastTrainedDate: null, // 'YYYY-MM-DD'
  
  // Daily Tracking:
  todayDate: null,
  todaySessions: [], // [{ id, type, durationMin, timeStr, pointsEarned }]
  todayRuns: [],     // [{ id, km, minutes, pace, timeStr }]
  
  // Daily Challenge:
  dailyChallenge: {
    date: null,
    title: "Treine pelo menos 40 minutos hoje!",
    targetMinutes: 40,
    completed: false
  },
  
  // Workouts routines:
  routines: DEFAULT_WORKOUT_ROUTINES,
  activeDayIndex: 0, // 0: Seg ... 6: Dom
  
  // Running history (All runs):
  runningHistory: [],
  
  // Badges:
  badges: BADGES,

  // Season / Reset Anual (Zera nível e pontos a cada virada de ano):
  currentSeasonYear: new Date().getFullYear(),
  seasonHistory: [], // [{ year, points, level, rankTier, rankName, date }]

  // Missão Surpresa Semanal (Ocorre em 1 dia aleatório da semana com penalidade de -1 ponto se falhar):
  surpriseMission: null, // { weekId, assignedDate, dayIndex, title, targetMinutes, desc, completed, penaltyApplied, alertSeen }
  penaltyHistory: []
};

// --- STORAGE SYSTEM ---
const STORAGE_KEY = "ironlevel_gym_data_v1";

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      Object.assign(STATE.user, parsed.user || {});
      STATE.totalMinutes = parsed.totalMinutes || 0;
      STATE.totalPoints = parsed.totalPoints || 0;
      STATE.currentLevel = parsed.currentLevel || 1;
      STATE.streakDays = parsed.streakDays || 1;
      STATE.lastTrainedDate = parsed.lastTrainedDate || null;
      STATE.todayDate = parsed.todayDate || null;
      STATE.todaySessions = parsed.todaySessions || [];
      STATE.todayRuns = parsed.todayRuns || [];
      STATE.dailyChallenge = parsed.dailyChallenge || STATE.dailyChallenge;
      STATE.routines = parsed.routines || DEFAULT_WORKOUT_ROUTINES;
      STATE.runningHistory = parsed.runningHistory || [];
      STATE.currentSeasonYear = parsed.currentSeasonYear || new Date().getFullYear();
      STATE.seasonHistory = parsed.seasonHistory || [];
      STATE.surpriseMission = parsed.surpriseMission || null;
      STATE.penaltyHistory = parsed.penaltyHistory || [];
      if (parsed.badges) {
        STATE.badges.forEach(b => {
          const found = parsed.badges.find(pb => pb.id === b.id);
          if (found) b.unlocked = found.unlocked;
        });
      }
    }
  } catch (err) {
    console.error("Erro ao carregar dados:", err);
  }
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(STATE));
  } catch (err) {
    console.error("Erro ao salvar dados:", err);
  }
}

// --- DATE HELPERS ---
function getTodayDateStr() {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getFormattedDayMonth() {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function getCurrentDayOfWeekIndex() {
  // JavaScript getDay(): 0 is Sunday, 1 is Monday...
  // We want: 0 = Segunda, 1 = Terça ... 5 = Sábado, 6 = Domingo
  const jsDay = new Date().getDay();
  return jsDay === 0 ? 6 : jsDay - 1;
}

// Retorna identificador único da semana no formato "YYYY-WXX"
function getWeekId(d = new Date()) {
  const date = new Date(d.getTime());
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
  const week1 = new Date(date.getFullYear(), 0, 4);
  const weekNum = 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
  return `${date.getFullYear()}-W${String(weekNum).padStart(2, '0')}`;
}

// Retorna as 7 datas (YYYY-MM-DD) de Segunda a Domingo da semana atual
function getDatesOfCurrentWeek() {
  const now = new Date();
  const dayOfWeek = (now.getDay() + 6) % 7; // 0 = Seg ... 6 = Dom
  const monday = new Date(now);
  monday.setDate(now.getDate() - dayOfWeek);
  const weekDates = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    weekDates.push(`${y}-${m}-${day}`);
  }
  return weekDates;
}

// Sorteia e cria a Missão Surpresa em 1 dia aleatório da semana (de HOJE até Domingo)
function generateWeeklySurpriseMission() {
  const currentWeek = getWeekId();
  const weekDates = getDatesOfCurrentWeek();
  const today = getTodayDateStr();

  // Sorteia apenas entre datas de HOJE até Domingo para não gerar missão no passado!
  const validDates = weekDates.filter(d => d >= today);
  const targetDate = validDates.length > 0 
    ? validDates[Math.floor(Math.random() * validDates.length)] 
    : today;
  const randDayIdx = weekDates.indexOf(targetDate);

  const SURPRISE_QUEST_POOL = [
    { title: "Treino de Emergência: 45 min hoje!", targetMinutes: 45, desc: "Alerta de Sobrevivência! O sistema exige 45 minutos de treino pesado hoje para manter seu Rank." },
    { title: "Provação Relâmpago: 40 min sem desculpas!", targetMinutes: 40, desc: "Dia surpresa ativado! Complete pelo menos 40 minutos de treino ou cardio hoje." },
    { title: "Desafio de Honra: 50 min de esforço!", targetMinutes: 50, desc: "A arena dos heróis clama por esforço! Treine 50 minutos hoje para não sofrer penalidade." },
    { title: "Alerta Crítico: 35 min de ferro ou corrida!", targetMinutes: 35, desc: "Missão obrigatória da semana! Complete 35 minutos hoje antes da meia-noite." }
  ];
  const q = SURPRISE_QUEST_POOL[Math.floor(Math.random() * SURPRISE_QUEST_POOL.length)];

  STATE.surpriseMission = {
    weekId: currentWeek,
    assignedDate: targetDate,
    dayIndex: randDayIdx,
    title: q.title,
    targetMinutes: q.targetMinutes,
    desc: q.desc,
    completed: false,
    penaltyApplied: false,
    alertSeen: false
  };
  saveState();
}

// Verifica status da Missão Surpresa e aplica penalidade de -1 Ponto se falhou
function checkSurpriseMissionStatus() {
  const currentWeek = getWeekId();
  const today = getTodayDateStr();

  // Se não tem missão sorteada ou é de outra semana, sorteia para os dias restantes
  if (!STATE.surpriseMission || STATE.surpriseMission.weekId !== currentWeek) {
    generateWeeklySurpriseMission();
  }

  // Se a missão era de um dia anterior desta mesma semana e não foi concluída
  if (STATE.surpriseMission && STATE.surpriseMission.assignedDate < today) {
    if (!STATE.surpriseMission.completed && !STATE.surpriseMission.penaltyApplied) {
      STATE.surpriseMission.penaltyApplied = true;
      const penaltyMinutes = 120;
      STATE.totalMinutes = Math.max(0, STATE.totalMinutes - penaltyMinutes);
      STATE.totalPoints = calculatePoints(STATE.totalMinutes);
      const newLevelObj = getLevelForPoints(STATE.totalPoints);
      STATE.currentLevel = newLevelObj.level;

      if (!STATE.penaltyHistory) STATE.penaltyHistory = [];
      STATE.penaltyHistory.push({
        date: STATE.surpriseMission.assignedDate,
        mission: STATE.surpriseMission.title,
        pointsLost: 1.0,
        appliedAt: new Date().toISOString()
      });

      saveState();
      setTimeout(() => {
        triggerPenaltyModal(STATE.surpriseMission);
      }, 700);
    }
  }

  // Se hoje É o dia da missão surpresa e o usuário ainda não viu o alerta
  if (STATE.surpriseMission && STATE.surpriseMission.assignedDate === today) {
    if (!STATE.surpriseMission.alertSeen && !STATE.surpriseMission.completed) {
      STATE.surpriseMission.alertSeen = true;
      saveState();
      setTimeout(() => {
        triggerSurpriseMissionModal();
      }, 500);
    }
  }
}

// Verifica virada de Ano: Reseta pontos e níveis para que todos comecem do zero
function checkYearTurnover() {
  const currentYear = new Date().getFullYear();
  if (!STATE.currentSeasonYear) {
    STATE.currentSeasonYear = currentYear;
    saveState();
    return;
  }

  if (STATE.currentSeasonYear < currentYear) {
    const pastYear = STATE.currentSeasonYear;
    const finalLevelObj = getLevelForPoints(STATE.totalPoints);

    if (!STATE.seasonHistory) STATE.seasonHistory = [];
    STATE.seasonHistory.unshift({
      year: pastYear,
      points: STATE.totalPoints,
      level: STATE.currentLevel,
      rankTier: finalLevelObj.rankTier || 'E',
      rankName: finalLevelObj.name,
      date: new Date().toISOString()
    });

    // Zera pontos e nível para a nova temporada anual
    STATE.totalMinutes = 0;
    STATE.totalPoints = 0.0;
    STATE.currentLevel = 1;
    STATE.currentSeasonYear = currentYear;
    saveState();

    setTimeout(() => {
      triggerSeasonResetModal(pastYear, finalLevelObj);
    }, 600);
  }
}

// Check for date turnover (new day resets today's sessions and checks streak)
function checkDateTurnover() {
  checkYearTurnover();
  checkSurpriseMissionStatus();

  const today = getTodayDateStr();
  if (STATE.todayDate !== today) {
    // Check streak
    if (STATE.lastTrainedDate) {
      const last = new Date(STATE.lastTrainedDate);
      const curr = new Date(today);
      const diffDays = Math.round((curr - last) / (1000 * 60 * 60 * 24));
      if (diffDays === 1) {
        // trained yesterday, streak keeps going
      } else if (diffDays > 1) {
        // missed day, reset streak to 0
        STATE.streakDays = 0;
      }
    } else {
      STATE.streakDays = 0;
    }
    
    STATE.todayDate = today;
    STATE.todaySessions = [];
    STATE.todayRuns = [];
    
    // Generate new daily challenge
    const challengesList = [
      { title: "Treine pelo menos 40 minutos hoje!", targetMinutes: 40 },
      { title: "Bata 45 min de treino pesado!", targetMinutes: 45 },
      { title: "Corra ou faça cardio de pelo menos 20 min!", targetMinutes: 20 },
      { title: "Desafio 1 Hora: Treine 60 minutos hoje!", targetMinutes: 60 },
      { title: "Faça pelo menos 30 min e complete seus exercícios!", targetMinutes: 30 }
    ];
    const picked = challengesList[new Date().getDay() % challengesList.length];
    STATE.dailyChallenge = {
      date: today,
      title: picked.title,
      targetMinutes: picked.targetMinutes,
      completed: false
    };

    // Reset exercise checkboxes for the new day
    Object.keys(STATE.routines).forEach(d => {
      STATE.routines[d].exercises.forEach(e => e.done = false);
    });

    saveState();
  }
}

// --- POINTS & LEVEL CALCULATIONS ---
// Rule: 2 hours (120 minutes) = 1 point!
function calculatePoints(minutes) {
  return parseFloat((minutes / 120).toFixed(2));
}

function getLevelForPoints(points) {
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (points >= LEVELS[i].minPoints) {
      return LEVELS[i];
    }
  }
  return LEVELS[0];
}

function updateLevelAndPoints() {
  const oldLevel = STATE.currentLevel;
  STATE.totalPoints = calculatePoints(STATE.totalMinutes);
  const currentLevelObj = getLevelForPoints(STATE.totalPoints);
  STATE.currentLevel = currentLevelObj.level;

  // Check if leveled up!
  if (STATE.currentLevel > oldLevel) {
    triggerLevelUpModal(currentLevelObj);
  }
  
  checkBadges();
  saveState();
  renderAll();
}

function addTrainingMinutes(mins, type = "Treino") {
  STATE.totalMinutes += mins;
  const today = getTodayDateStr();
  
  // Update streak if first workout of the day
  if (STATE.lastTrainedDate !== today) {
    STATE.streakDays = (STATE.streakDays || 0) + 1;
    STATE.lastTrainedDate = today;
  }
  
  // Record session
  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const pointsEarned = parseFloat((mins / 120).toFixed(2));
  
  STATE.todaySessions.push({
    id: "s_" + Date.now(),
    type: type,
    durationMin: mins,
    timeStr: timeStr,
    pointsEarned: pointsEarned
  });

  // Check daily challenge
  const todayTotalMin = STATE.todaySessions.reduce((acc, s) => acc + s.durationMin, 0);
  if (!STATE.dailyChallenge.completed && todayTotalMin >= STATE.dailyChallenge.targetMinutes) {
    STATE.dailyChallenge.completed = true;
  }

  // Check surprise mission (se hoje for o dia sorteado)
  if (STATE.surpriseMission && STATE.surpriseMission.assignedDate === today && !STATE.surpriseMission.completed) {
    if (todayTotalMin >= STATE.surpriseMission.targetMinutes) {
      STATE.surpriseMission.completed = true;
      triggerHaptic('success');
      sfx.playLevelUp();
    }
  }

  updateLevelAndPoints();
}

// --- BADGES CHECKER ---
function checkBadges() {
  // 1st workout
  if (STATE.todaySessions.length > 0 || STATE.totalMinutes > 0) {
    unlockBadge("first_workout");
  }
  // Streak 3
  if (STATE.streakDays >= 3) {
    unlockBadge("streak_3");
  }
  // Streak 7
  if (STATE.streakDays >= 7) {
    unlockBadge("streak_7");
  }
  // First run
  if (STATE.runningHistory.length > 0) {
    unlockBadge("first_run");
  }
  // 5K run
  if (STATE.runningHistory.some(r => r.km >= 5)) {
    unlockBadge("run_5k");
  }
  // 10 hours of training
  if (STATE.totalMinutes >= 600) {
    unlockBadge("hours_10");
  }
  // Double workout
  if (STATE.todaySessions.length >= 2) {
    unlockBadge("double_workout");
  }
  // 10 points
  if (STATE.totalPoints >= 10) {
    unlockBadge("points_10");
  }
}

function unlockBadge(id) {
  const badge = STATE.badges.find(b => b.id === id);
  if (badge && !badge.unlocked) {
    badge.unlocked = true;
    sfx.playCheck();
  }
}

// --- WORKOUT LIVE TIMER (SUPORTE TOTAL A TELA BLOQUEADA & SEGUNDO PLANO) ---
const WORKOUT_TIMER_STORAGE_KEY = 'ironlevel_active_workout_timer_v2';
const REST_TIMER_STORAGE_KEY = 'ironlevel_active_rest_timer_v2';
const GPS_TIMER_STORAGE_KEY = 'ironlevel_active_gps_timer_v2';
const ROPE_TIMER_STORAGE_KEY = 'ironlevel_active_rope_timer_v2';

let screenWakeLock = null;
async function requestScreenWakeLock() {
  if ('wakeLock' in navigator) {
    try {
      if (screenWakeLock === null || screenWakeLock.released) {
        screenWakeLock = await navigator.wakeLock.request('screen');
        screenWakeLock.addEventListener('release', () => {
          if ((timerRunning || gpsTracking || ropeActive) && document.visibilityState === 'visible') {
            setTimeout(requestScreenWakeLock, 300);
          }
        });
      }
    } catch (err) {}
  }
}

function releaseScreenWakeLock() {
  if (screenWakeLock !== null) {
    try {
      screenWakeLock.release().then(() => { screenWakeLock = null; }).catch(() => {});
    } catch (e) {}
  }
}

// Background Web Worker Ticker (não é congelado pelo navegador quando a tela apaga)
let bgWorker = null;
function startBackgroundWorkerTicker() {
  if (bgWorker) return;
  try {
    const workerScript = `
      let timer = null;
      self.onmessage = function(e) {
        if (e.data === 'start') {
          if (!timer) {
            timer = setInterval(function() {
              self.postMessage('tick');
            }, 1000);
          }
        } else if (e.data === 'stop') {
          if (timer) {
            clearInterval(timer);
            timer = null;
          }
        }
      };
    `;
    const blob = new Blob([workerScript], { type: 'application/javascript' });
    const url = URL.createObjectURL(blob);
    bgWorker = new Worker(url);
    bgWorker.onmessage = function(e) {
      if (e.data === 'tick') {
        syncAllTimersWithWallClock();
      }
    };
    bgWorker.postMessage('start');
  } catch (err) {
    console.warn("Background worker indisponível:", err);
  }
}

function stopBackgroundWorkerTicker() {
  if (timerRunning || gpsTracking || ropeActive || (restEndTime && restRemaining > 0)) {
    return; // outro timer ativo ainda precisa do worker
  }
  if (bgWorker) {
    try {
      bgWorker.postMessage('stop');
      bgWorker.terminate();
    } catch (e) {}
    bgWorker = null;
  }
}

let timerInterval = null;
let timerSeconds = 0;
let timerRunning = false;
let timerStartTime = null;        // Timestamp exato do relógio (Date.now())
let timerAccumulatedSeconds = 0;   // Segundos acumulados antes da última pausa

function formatSeconds(sec) {
  const safeSec = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(safeSec / 3600);
  const m = Math.floor((safeSec % 3600) / 60);
  const s = safeSec % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

// Retorna sempre o tempo REAL baseado no relógio do sistema, imune ao bloqueio de tela
function getActualWorkoutSeconds() {
  if (!timerRunning || !timerStartTime) {
    return timerAccumulatedSeconds;
  }
  const diffSec = Math.max(0, Math.floor((Date.now() - timerStartTime) / 1000));
  return timerAccumulatedSeconds + diffSec;
}

function updateWorkoutTimerUI() {
  timerSeconds = getActualWorkoutSeconds();
  const disp = document.getElementById("liveTimerDisplay");
  if (disp) disp.innerText = formatSeconds(timerSeconds);
  const estPoints = (timerSeconds / 7200).toFixed(2);
  const ptEl = document.getElementById("timerPointsEstimate");
  if (ptEl) ptEl.innerText = `+${estPoints} pt`;
  updateActiveWorkoutBottomBar();
}

function saveActiveWorkoutTimerSession() {
  try {
    if (timerRunning && timerStartTime) {
      const session = {
        running: true,
        startTime: timerStartTime,
        accumulatedSeconds: timerAccumulatedSeconds,
        savedAt: Date.now(),
        activeDayIndex: STATE.activeDayIndex
      };
      localStorage.setItem(WORKOUT_TIMER_STORAGE_KEY, JSON.stringify(session));
    } else if (!timerRunning && timerAccumulatedSeconds > 0) {
      const session = {
        running: false,
        startTime: null,
        accumulatedSeconds: timerAccumulatedSeconds,
        savedAt: Date.now(),
        activeDayIndex: STATE.activeDayIndex
      };
      localStorage.setItem(WORKOUT_TIMER_STORAGE_KEY, JSON.stringify(session));
    } else {
      localStorage.removeItem(WORKOUT_TIMER_STORAGE_KEY);
    }
  } catch (e) {}
}

function restoreActiveWorkoutTimerSession() {
  try {
    const raw = localStorage.getItem(WORKOUT_TIMER_STORAGE_KEY);
    if (!raw) return;
    const session = JSON.parse(raw);
    if (!session) return;

    // Se a sessão for de mais de 14 horas atrás, descarta
    const MAX_SESSION_AGE = 14 * 60 * 60 * 1000;
    if (Date.now() - session.savedAt > MAX_SESSION_AGE) {
      localStorage.removeItem(WORKOUT_TIMER_STORAGE_KEY);
      return;
    }

    timerAccumulatedSeconds = session.accumulatedSeconds || 0;
    if (session.running && session.startTime) {
      timerStartTime = session.startTime;
      timerRunning = true;
      timerSeconds = getActualWorkoutSeconds();

      if (timerInterval) clearInterval(timerInterval);
      timerInterval = setInterval(() => {
        updateWorkoutTimerUI();
      }, 1000);

      requestScreenWakeLock();
      startBackgroundWorkerTicker();

      const btnStart = document.getElementById("btnTimerStart");
      const btnPause = document.getElementById("btnTimerPause");
      const btnFinish = document.getElementById("btnTimerFinish");
      const btnReset = document.getElementById("btnTimerReset");
      if (btnStart) btnStart.style.display = "none";
      if (btnPause) btnPause.style.display = "inline-flex";
      if (btnFinish) btnFinish.style.display = "inline-flex";
      if (btnReset) btnReset.style.display = "inline-flex";
    } else {
      timerRunning = false;
      timerSeconds = timerAccumulatedSeconds;
      const btnStart = document.getElementById("btnTimerStart");
      const btnPause = document.getElementById("btnTimerPause");
      const btnFinish = document.getElementById("btnTimerFinish");
      const btnReset = document.getElementById("btnTimerReset");
      if (btnStart) {
        btnStart.style.display = "inline-flex";
        btnStart.innerText = "▶ Continuar";
      }
      if (btnPause) btnPause.style.display = "none";
      if (btnFinish) btnFinish.style.display = "inline-flex";
      if (btnReset) btnReset.style.display = "inline-flex";
    }

    updateWorkoutTimerUI();
    updateActiveWorkoutBottomBar();
  } catch (err) {
    console.error("Erro ao restaurar timer:", err);
  }
}

function toggleWorkoutTimer() {
  sfx.init();
  triggerHaptic("medium");
  if (!timerRunning) {
    timerRunning = true;
    timerStartTime = Date.now();
    requestScreenWakeLock();
    startBackgroundWorkerTicker();

    const btnStart = document.getElementById("btnTimerStart");
    const btnPause = document.getElementById("btnTimerPause");
    const btnFinish = document.getElementById("btnTimerFinish");
    const btnReset = document.getElementById("btnTimerReset");
    if (btnStart) btnStart.style.display = "none";
    if (btnPause) btnPause.style.display = "inline-flex";
    if (btnFinish) btnFinish.style.display = "inline-flex";
    if (btnReset) btnReset.style.display = "inline-flex";

    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(() => {
      updateWorkoutTimerUI();
    }, 1000);

    saveActiveWorkoutTimerSession();
    updateWorkoutTimerUI();
  }
}

function pauseWorkoutTimer() {
  if (timerRunning) {
    timerAccumulatedSeconds = getActualWorkoutSeconds();
    timerStartTime = null;
    timerRunning = false;
    if (timerInterval) {
      clearInterval(timerInterval);
      timerInterval = null;
    }
    releaseScreenWakeLock();
    stopBackgroundWorkerTicker();
    saveActiveWorkoutTimerSession();

    const btnStart = document.getElementById("btnTimerStart");
    const btnPause = document.getElementById("btnTimerPause");
    if (btnStart) {
      btnStart.style.display = "inline-flex";
      btnStart.innerText = "▶ Continuar";
    }
    if (btnPause) btnPause.style.display = "none";
    updateWorkoutTimerUI();
  }
}

function finishWorkoutTimer() {
  finishWorkoutSessionPro();
}

function resetWorkoutTimer() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
  releaseScreenWakeLock();
  timerRunning = false;
  timerStartTime = null;
  timerAccumulatedSeconds = 0;
  timerSeconds = 0;
  stopBackgroundWorkerTicker();

  try {
    localStorage.removeItem(WORKOUT_TIMER_STORAGE_KEY);
  } catch (e) {}

  const disp = document.getElementById("liveTimerDisplay");
  if (disp) disp.innerText = "00:00:00";
  const ptEl = document.getElementById("timerPointsEstimate");
  if (ptEl) ptEl.innerText = "+0.0 pt";

  const btnStart = document.getElementById("btnTimerStart");
  const btnPause = document.getElementById("btnTimerPause");
  const btnFinish = document.getElementById("btnTimerFinish");
  const btnReset = document.getElementById("btnTimerReset");
  if (btnStart) {
    btnStart.style.display = "inline-flex";
    btnStart.innerText = "▶ Iniciar";
  }
  if (btnPause) btnPause.style.display = "none";
  if (btnFinish) btnFinish.style.display = "none";
  if (btnReset) btnReset.style.display = "none";
  updateActiveWorkoutBottomBar();
}

// --- REST TIMER COM ALARME EM SEGUNDO PLANO / TELA BLOQUEADA ---
let restInterval = null;
let restRemaining = 0;
let restEndTime = null;
let restTotalSeconds = 0;

function startRestTimer(seconds) {
  sfx.playBeep(520, 0.1);
  if (restInterval) clearInterval(restInterval);

  restTotalSeconds = seconds;
  restEndTime = Date.now() + (seconds * 1000);
  restRemaining = seconds;

  try {
    localStorage.setItem(REST_TIMER_STORAGE_KEY, JSON.stringify({
      endTime: restEndTime,
      totalSeconds: restTotalSeconds,
      startedAt: Date.now()
    }));
  } catch (e) {}

  const pill = document.getElementById("restTimerPill");
  if (pill) pill.classList.add("active");
  updateRestTimerUI();

  restInterval = setInterval(tickRestTimer, 1000);
  startBackgroundWorkerTicker();
}

function tickRestTimer() {
  if (!restEndTime) return;
  const now = Date.now();
  restRemaining = Math.max(0, Math.ceil((restEndTime - now) / 1000));
  updateRestTimerUI();

  if (restRemaining <= 0) {
    finishRestTimer();
  }
}

function updateRestTimerUI() {
  const disp = document.getElementById("restTimerDisplay");
  if (disp) {
    const m = Math.floor(restRemaining / 60);
    const s = restRemaining % 60;
    disp.innerText = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
}

function finishRestTimer() {
  if (restInterval) {
    clearInterval(restInterval);
    restInterval = null;
  }
  restEndTime = null;
  restRemaining = 0;
  stopBackgroundWorkerTicker();

  try {
    localStorage.removeItem(REST_TIMER_STORAGE_KEY);
  } catch (e) {}

  const pill = document.getElementById("restTimerPill");
  if (pill) pill.classList.remove("active");

  // Alerta sonoro triplo e vibração forte mesmo se o celular estiver acordando do bloqueio
  sfx.playBeep(880, 0.2);
  setTimeout(() => sfx.playBeep(880, 0.2), 250);
  setTimeout(() => sfx.playBeep(1100, 0.4), 500);

  if ('vibrate' in navigator) {
    try {
      navigator.vibrate([300, 120, 300, 120, 500]);
    } catch (e) {}
  }
}

function cancelRestTimer() {
  if (restInterval) {
    clearInterval(restInterval);
    restInterval = null;
  }
  restEndTime = null;
  restRemaining = 0;
  stopBackgroundWorkerTicker();
  try {
    localStorage.removeItem(REST_TIMER_STORAGE_KEY);
  } catch (e) {}
  const pill = document.getElementById("restTimerPill");
  if (pill) pill.classList.remove("active");
}

function checkExpiredRestTimer() {
  try {
    const raw = localStorage.getItem(REST_TIMER_STORAGE_KEY);
    if (!raw) return;
    const data = JSON.parse(raw);
    if (!data || !data.endTime) return;

    if (Date.now() >= data.endTime) {
      // O tempo de descanso expirou enquanto o celular estava com a tela bloqueada!
      finishRestTimer();
      showToast("⏱️ Descanso Concluído! Bora pra próxima série! 💪");
    } else {
      // Ainda resta tempo: ressincroniza o cronômetro
      restEndTime = data.endTime;
      restTotalSeconds = data.totalSeconds || 60;
      restRemaining = Math.max(0, Math.ceil((restEndTime - Date.now()) / 1000));
      const pill = document.getElementById("restTimerPill");
      if (pill) pill.classList.add("active");
      updateRestTimerUI();
      if (!restInterval) {
        restInterval = setInterval(tickRestTimer, 1000);
      }
      startBackgroundWorkerTicker();
    }
  } catch (e) {}
}

function syncAllTimersWithWallClock() {
  if (timerRunning) {
    updateWorkoutTimerUI();
  }
  if (restEndTime) {
    tickRestTimer();
  }
  if (gpsTracking && !gpsPaused) {
    gpsElapsedSeconds = getActualGpsSeconds();
    updateGpsHud();
  }
  if (ropeActive && !ropePaused) {
    ropeElapsedSeconds = getActualRopeSeconds();
    updateRopeHud();
  }
}

// --- RUNNING TRACKER & STRAVA-STYLE GPS ENGINE ---
let currentRunSubtab = 'gps';
let leafletMap = null;
let mapStreetLayer = null;
let mapSatLayer = null;
let isSatellite = true;
let routePolyline = null;
let currentPosMarker = null;
let startPosMarker = null;

// GPS Tracking State (Imune a tela bloqueada / segundo plano)
let gpsTracking = false;
let gpsPaused = false;
let gpsWatchId = null;
let gpsTimerInterval = null;
let gpsElapsedSeconds = 0;
let gpsStartTime = null;
let gpsAccumulatedSeconds = 0;
let gpsTotalKm = 0;
let gpsRoutePoints = [];
let lastGpsPoint = null;
let currentGpsActivity = 'run'; // 'run' | 'bike'

function getActualGpsSeconds() {
  if (gpsTracking && !gpsPaused && gpsStartTime) {
    const diff = Math.max(0, Math.floor((Date.now() - gpsStartTime) / 1000));
    return gpsAccumulatedSeconds + diff;
  }
  return gpsAccumulatedSeconds;
}

function saveActiveGpsSession() {
  try {
    if (gpsTracking) {
      localStorage.setItem(GPS_TIMER_STORAGE_KEY, JSON.stringify({
        tracking: true,
        paused: gpsPaused,
        startTime: gpsStartTime,
        accumulatedSeconds: gpsAccumulatedSeconds,
        totalKm: gpsTotalKm,
        activity: currentGpsActivity,
        savedAt: Date.now()
      }));
    } else {
      localStorage.removeItem(GPS_TIMER_STORAGE_KEY);
    }
  } catch(e) {}
}

function restoreActiveGpsSession() {
  try {
    const raw = localStorage.getItem(GPS_TIMER_STORAGE_KEY);
    if (!raw) return;
    const s = JSON.parse(raw);
    if (!s || !s.tracking) return;
    if (Date.now() - s.savedAt > 10 * 60 * 60 * 1000) {
      localStorage.removeItem(GPS_TIMER_STORAGE_KEY);
      return;
    }
    gpsTracking = true;
    gpsPaused = !!s.paused;
    currentGpsActivity = s.activity || 'run';
    gpsTotalKm = s.totalKm || 0;
    gpsAccumulatedSeconds = s.accumulatedSeconds || 0;
    if (!gpsPaused && s.startTime) {
      gpsStartTime = s.startTime;
      gpsElapsedSeconds = getActualGpsSeconds();
      startBackgroundWorkerTicker();
      requestScreenWakeLock();
    } else {
      gpsElapsedSeconds = gpsAccumulatedSeconds;
    }
    updateGpsHud();
  } catch(e) {}
}

// Route Viewer Modal State
let routeModalMap = null;
let routeModalPolyline = null;

// --- JUMP ROPE SENSOR STATE (Opção 1 - Imune a tela bloqueada) ---
let ropeActive = false;
let ropePaused = false;
let ropeJumpCount = 0;
let ropeElapsedSeconds = 0;
let ropeStartTime = null;
let ropeAccumulatedSeconds = 0;
let ropeTimerInterval = null;
let ropeRecentJumpTimestamps = [];
let lastJumpTimestamp = 0;
let ropeMotionHandler = null;

function getActualRopeSeconds() {
  if (ropeActive && !ropePaused && ropeStartTime) {
    const diff = Math.max(0, Math.floor((Date.now() - ropeStartTime) / 1000));
    return ropeAccumulatedSeconds + diff;
  }
  return ropeAccumulatedSeconds;
}

function saveActiveRopeSession() {
  try {
    if (ropeActive) {
      localStorage.setItem(ROPE_TIMER_STORAGE_KEY, JSON.stringify({
        active: true,
        paused: ropePaused,
        startTime: ropeStartTime,
        accumulatedSeconds: ropeAccumulatedSeconds,
        jumpCount: ropeJumpCount,
        savedAt: Date.now()
      }));
    } else {
      localStorage.removeItem(ROPE_TIMER_STORAGE_KEY);
    }
  } catch(e) {}
}

function restoreActiveRopeSession() {
  try {
    const raw = localStorage.getItem(ROPE_TIMER_STORAGE_KEY);
    if (!raw) return;
    const s = JSON.parse(raw);
    if (!s || !s.active) return;
    if (Date.now() - s.savedAt > 6 * 60 * 60 * 1000) {
      localStorage.removeItem(ROPE_TIMER_STORAGE_KEY);
      return;
    }
    ropeActive = true;
    ropePaused = !!s.paused;
    ropeJumpCount = s.jumpCount || 0;
    ropeAccumulatedSeconds = s.accumulatedSeconds || 0;
    if (!ropePaused && s.startTime) {
      ropeStartTime = s.startTime;
      ropeElapsedSeconds = getActualRopeSeconds();
      startBackgroundWorkerTicker();
      requestScreenWakeLock();
    } else {
      ropeElapsedSeconds = ropeAccumulatedSeconds;
    }
    updateRopeHud();
  } catch(e) {}
}

function switchRunSubtab(subtab) {
  triggerHaptic('light');
  currentRunSubtab = subtab;

  const gpsBtn = document.getElementById("subtab-gps-btn");
  const ropeBtn = document.getElementById("subtab-rope-btn");
  const manualBtn = document.getElementById("subtab-manual-btn");

  const gpsView = document.getElementById("runGpsView");
  const ropeView = document.getElementById("runRopeView");
  const manualView = document.getElementById("runManualView");

  if (gpsBtn) gpsBtn.classList.remove("active");
  if (ropeBtn) ropeBtn.classList.remove("active");
  if (manualBtn) manualBtn.classList.remove("active");

  if (gpsView) gpsView.style.display = "none";
  if (ropeView) ropeView.style.display = "none";
  if (manualView) manualView.style.display = "none";

  if (subtab === 'gps') {
    if (gpsBtn) gpsBtn.classList.add("active");
    if (gpsView) gpsView.style.display = "block";
    initRunMapIfNeeded();
  } else if (subtab === 'rope') {
    if (ropeBtn) ropeBtn.classList.add("active");
    if (ropeView) ropeView.style.display = "block";
  } else {
    if (manualBtn) manualBtn.classList.add("active");
    if (manualView) manualView.style.display = "block";
  }
}

// --- GPS ACTIVITY SELECTOR (Opção 4: Corrida vs Ciclismo/Bike) ---
function setGpsActivity(activity) {
  if (gpsTracking) {
    alert("Não é possível alternar modalidade com o GPS em gravação. Finalize ou pause a atividade atual.");
    return;
  }
  triggerHaptic('light');
  currentGpsActivity = activity;

  const runBtn = document.getElementById("gpsModeRunBtn");
  const bikeBtn = document.getElementById("gpsModeBikeBtn");
  const startBtn = document.getElementById("btnGpsStart");
  const hudTitle = document.getElementById("gpsHudTitle");
  const hudSecLabel = document.getElementById("gpsHudLabelSecondary");
  const statusText = document.getElementById("gpsStatusText");

  if (activity === 'bike') {
    if (runBtn) {
      runBtn.classList.remove("active-activity-btn");
      runBtn.style.borderColor = "rgba(255,255,255,0.15)";
      runBtn.style.color = "var(--text-muted)";
      runBtn.style.background = "transparent";
    }
    if (bikeBtn) {
      bikeBtn.classList.add("active-activity-btn", "bike");
      bikeBtn.style.borderColor = "#00d2ff";
      bikeBtn.style.color = "#00d2ff";
      bikeBtn.style.background = "rgba(0, 210, 255, 0.15)";
    }
    if (startBtn) startBtn.innerHTML = "▶ Iniciar Ciclismo GPS 🚴";
    if (hudTitle) hudTitle.innerText = "⏱️ TEMPO DE CICLISMO";
    if (hudSecLabel) hudSecLabel.innerText = "Velocidade Média";
    if (statusText && !gpsTracking) statusText.innerText = "GPS pronto para Ciclismo. Toque em Iniciar e comece a pedalar!";
    
    // Switch polyline color to cyan for bike
    if (routePolyline) {
      routePolyline.setStyle({ color: '#00d2ff' });
    }
  } else {
    if (bikeBtn) {
      bikeBtn.classList.remove("active-activity-btn", "bike");
      bikeBtn.style.borderColor = "rgba(255,255,255,0.15)";
      bikeBtn.style.color = "var(--text-muted)";
      bikeBtn.style.background = "transparent";
    }
    if (runBtn) {
      runBtn.classList.add("active-activity-btn");
      runBtn.style.borderColor = "var(--accent-orange)";
      runBtn.style.color = "var(--accent-orange)";
      runBtn.style.background = "rgba(245, 158, 11, 0.12)";
    }
    if (startBtn) startBtn.innerHTML = "▶ Iniciar Corrida GPS 🏃";
    if (hudTitle) hudTitle.innerText = "⏱️ TEMPO DE CORRIDA";
    if (hudSecLabel) hudSecLabel.innerText = "Ritmo (Pace /km)";
    if (statusText && !gpsTracking) statusText.innerText = "GPS pronto para Corrida. Toque em Iniciar e comece a correr!";

    // Switch polyline color to orange for running
    if (routePolyline) {
      routePolyline.setStyle({ color: '#ff5722' });
    }
  }
}

// --- JUMP ROPE LOGIC (Opção 1: Pular Corda com Acelerômetro Real) ---
function startJumpRope() {
  sfx.init();
  triggerHaptic('success');

  // Request iOS permission if available (Safari 13+)
  if (typeof DeviceMotionEvent !== 'undefined' && typeof DeviceMotionEvent.requestPermission === 'function') {
    DeviceMotionEvent.requestPermission().then(permissionState => {
      if (permissionState === 'granted') {
        beginJumpRopeTracking();
      } else {
        alert("Atenção: Permissão do sensor negada. Você ainda pode usar o botão '+1 Pulo' para testar.");
        beginJumpRopeTracking();
      }
    }).catch(err => {
      console.warn("DeviceMotion permission error:", err);
      beginJumpRopeTracking();
    });
  } else {
    beginJumpRopeTracking();
  }
}

function beginJumpRopeTracking() {
  ropeActive = true;
  ropePaused = false;
  ropeJumpCount = 0;
  ropeElapsedSeconds = 0;
  ropeStartTime = Date.now();
  ropeAccumulatedSeconds = 0;
  ropeRecentJumpTimestamps = [];
  lastJumpTimestamp = 0;

  requestScreenWakeLock();
  startBackgroundWorkerTicker();
  saveActiveRopeSession();

  // Update UI buttons
  const startBtn = document.getElementById("btnRopeStart");
  const pauseBtn = document.getElementById("btnRopePause");
  const resumeBtn = document.getElementById("btnRopeResume");
  const finishBtn = document.getElementById("btnRopeFinish");
  const cancelBtn = document.getElementById("btnRopeCancel");

  if (startBtn) startBtn.style.display = "none";
  if (pauseBtn) pauseBtn.style.display = "inline-flex";
  if (resumeBtn) resumeBtn.style.display = "none";
  if (finishBtn) finishBtn.style.display = "inline-flex";
  if (cancelBtn) cancelBtn.style.display = "inline-flex";

  setRopeBadgeStatus("Pulando corda... Bora! 🪢", true);
  updateRopeHud();

  // Attach DeviceMotion sensor
  if (!ropeMotionHandler) {
    ropeMotionHandler = handleDeviceMotionRope;
  }
  window.removeEventListener('devicemotion', ropeMotionHandler);
  window.addEventListener('devicemotion', ropeMotionHandler);

  // Timer interval
  if (ropeTimerInterval) clearInterval(ropeTimerInterval);
  ropeTimerInterval = setInterval(() => {
    if (ropeActive && !ropePaused) {
      ropeElapsedSeconds = getActualRopeSeconds();
      updateRopeHud();
    }
  }, 1000);
}

function handleDeviceMotionRope(e) {
  if (!ropeActive || ropePaused) return;

  const acc = e.accelerationIncludingGravity || e.acceleration;
  if (!acc) return;

  const ax = acc.x || 0;
  const ay = acc.y || 0;
  const az = acc.z || 0;
  const magnitude = Math.sqrt(ax * ax + ay * ay + az * az);

  // Sensitivity thresholds (m/s²) and debouncing intervals
  const selectEl = document.getElementById("ropeSensitivitySelect");
  const sens = selectEl ? selectEl.value : 'normal';

  let threshold = 14.0;
  let minIntervalMs = 270;

  if (sens === 'high') {
    threshold = 12.5;
    minIntervalMs = 230;
  } else if (sens === 'fast') {
    threshold = 13.5;
    minIntervalMs = 190;
  }

  const now = Date.now();
  if (magnitude >= threshold && (now - lastJumpTimestamp) > minIntervalMs) {
    lastJumpTimestamp = now;
    recordRopeJump();
  }
}

function recordRopeJump() {
  ropeJumpCount++;
  const now = Date.now();
  ropeRecentJumpTimestamps.push(now);

  triggerHaptic('light');

  const countEl = document.getElementById("ropeJumpCount");
  if (countEl) {
    countEl.innerText = ropeJumpCount;
    countEl.classList.add("jump-pop");
    setTimeout(() => {
      countEl.classList.remove("jump-pop");
    }, 90);
  }

  // Milestone beep/haptic every 50 jumps
  if (ropeJumpCount % 50 === 0) {
    triggerHaptic('success');
    if (sfx && typeof sfx.playCheck === 'function') sfx.playCheck();
  }

  updateRopeHud();
}

function simulateRopeJump() {
  if (!ropeActive) {
    startJumpRope();
  }
  recordRopeJump();
}

function updateRopeHud() {
  // Timer MM:SS
  const m = Math.floor(ropeElapsedSeconds / 60);
  const s = ropeElapsedSeconds % 60;
  const timerStr = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  const timerEl = document.getElementById("ropeLiveTimer");
  if (timerEl) timerEl.innerText = timerStr;

  // Jump count
  const countEl = document.getElementById("ropeJumpCount");
  if (countEl && !countEl.classList.contains("jump-pop")) {
    countEl.innerText = ropeJumpCount;
  }

  // Cadence (jumps per minute in last 10 seconds)
  const now = Date.now();
  ropeRecentJumpTimestamps = ropeRecentJumpTimestamps.filter(t => (now - t) <= 10000);
  let cadence = 0;
  if (ropeRecentJumpTimestamps.length > 0) {
    cadence = Math.round((ropeRecentJumpTimestamps.length / 10) * 60);
  }
  const cadenceEl = document.getElementById("ropeLiveCadence");
  if (cadenceEl) cadenceEl.innerText = cadence;

  // Calories: ~0.14 kcal per jump + time factor
  const calories = Math.round((ropeJumpCount * 0.14) + (ropeElapsedSeconds / 60) * 2);
  const calEl = document.getElementById("ropeLiveCalories");
  if (calEl) calEl.innerText = calories;
}

function pauseJumpRope() {
  triggerHaptic('medium');
  ropeAccumulatedSeconds = getActualRopeSeconds();
  ropeStartTime = null;
  ropePaused = true;
  saveActiveRopeSession();
  document.getElementById("btnRopePause").style.display = "none";
  document.getElementById("btnRopeResume").style.display = "inline-flex";
  setRopeBadgeStatus("Treino de corda pausado ⏸️", false);
}

function resumeJumpRope() {
  triggerHaptic('medium');
  ropeStartTime = Date.now();
  ropePaused = false;
  startBackgroundWorkerTicker();
  saveActiveRopeSession();
  document.getElementById("btnRopeResume").style.display = "none";
  document.getElementById("btnRopePause").style.display = "inline-flex";
  setRopeBadgeStatus("Pulando corda... Bora! 🪢", true);
}

function cancelJumpRope() {
  if (confirm("Deseja cancelar o treino de corda? Os pulos atuais serão descartados.")) {
    stopJumpRopeTracking();
    resetRopeHud();
  }
}

function stopJumpRopeTracking() {
  ropeActive = false;
  ropePaused = false;
  ropeStartTime = null;
  ropeAccumulatedSeconds = 0;
  try { localStorage.removeItem(ROPE_TIMER_STORAGE_KEY); } catch(e) {}
  stopBackgroundWorkerTicker();
  if (ropeTimerInterval) {
    clearInterval(ropeTimerInterval);
    ropeTimerInterval = null;
  }
  if (ropeMotionHandler) {
    window.removeEventListener('devicemotion', ropeMotionHandler);
  }
  releaseScreenWakeLock();

  const startBtn = document.getElementById("btnRopeStart");
  const pauseBtn = document.getElementById("btnRopePause");
  const resumeBtn = document.getElementById("btnRopeResume");
  const finishBtn = document.getElementById("btnRopeFinish");
  const cancelBtn = document.getElementById("btnRopeCancel");

  if (startBtn) startBtn.style.display = "inline-flex";
  if (pauseBtn) pauseBtn.style.display = "none";
  if (resumeBtn) resumeBtn.style.display = "none";
  if (finishBtn) finishBtn.style.display = "none";
  if (cancelBtn) cancelBtn.style.display = "none";

  setRopeBadgeStatus("Pronto para iniciar", false);
}

function resetRopeHud() {
  ropeJumpCount = 0;
  ropeElapsedSeconds = 0;
  ropeRecentJumpTimestamps = [];
  lastJumpTimestamp = 0;
  const countEl = document.getElementById("ropeJumpCount");
  const timerEl = document.getElementById("ropeLiveTimer");
  const cadenceEl = document.getElementById("ropeLiveCadence");
  const calEl = document.getElementById("ropeLiveCalories");

  if (countEl) countEl.innerText = "0";
  if (timerEl) timerEl.innerText = "00:00";
  if (cadenceEl) cadenceEl.innerText = "0";
  if (calEl) calEl.innerText = "0";
}

function setRopeBadgeStatus(text, isActive) {
  const textEl = document.getElementById("ropeStatusText");
  const dotEl = document.getElementById("ropeStatusDot");
  if (textEl) textEl.innerText = text;
  if (dotEl) {
    if (isActive) dotEl.classList.add("active");
    else dotEl.classList.remove("active");
  }
}

function finishJumpRope() {
  triggerHaptic('success');
  sfx.playLevelUp();

  if (ropeJumpCount < 15 && ropeElapsedSeconds < 20) {
    if (!confirm(`Você registrou apenas ${ropeJumpCount} pulos. Deseja realmente salvar este treino?`)) {
      return;
    }
  }

  const minutes = Math.max(1, Math.round(ropeElapsedSeconds / 60));
  const finalJumps = ropeJumpCount;
  const avgCadence = Math.round(finalJumps / (minutes || 1));
  const calories = Math.round((finalJumps * 0.14) + minutes * 2);

  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const ropeItem = {
    id: "rope_" + Date.now(),
    date: getTodayDateStr(),
    timeStr: timeStr,
    activity: 'rope',
    jumps: finalJumps,
    minutes: minutes,
    km: 0,
    pace: `${avgCadence} pulos/min`,
    calories: calories,
    isGps: false,
    isSensor: true,
    earnedMinutes: minutes,
    route: null
  };

  STATE.todayRuns.push(ropeItem);
  STATE.runningHistory.unshift(ropeItem);

  // Add the rope minutes to training hours (2h = 1pt rule)
  addTrainingMinutes(minutes, `Pular Corda (${finalJumps} pulos)`);

  stopJumpRopeTracking();
  resetRopeHud();
  renderRunningTab();

  alert(`🪢 Treino de Corda Finalizado com Sucesso!\n\n🔢 Pulos: ${finalJumps}\n⏱️ Duração: ${minutes} min\n⚡ Cadência Média: ${avgCadence} pulos/min\n🔥 Calorias: ~${calories} kcal\n\n+${minutes} minutos somados para seu Nível!`);
}

function initRunMapIfNeeded() {
  if (typeof L === 'undefined') return;

  const mapContainer = document.getElementById("runMap");
  if (!mapContainer) return;

  if (!leafletMap) {
    // Default center (ex: Brasil central or fallback)
    leafletMap = L.map('runMap', { zoomControl: false, preferCanvas: true }).setView([-23.5505, -46.6333], 15);
    L.control.zoom({ position: 'bottomright' }).addTo(leafletMap);

    // Street layer (OpenStreetMap)
    mapStreetLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap'
    });

    // Satellite layer (Esri World Imagery - identical to Strava)
    mapSatLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
      maxZoom: 19,
      attribution: '© Esri Satellite'
    });

    // Default to Satellite view!
    mapSatLayer.addTo(leafletMap);
    isSatellite = true;

    // Orange Route Polyline (Strava orange #ff5722)
    routePolyline = L.polyline([], {
      color: '#ff5722',
      weight: 6,
      opacity: 0.95,
      lineCap: 'round',
      lineJoin: 'round'
    }).addTo(leafletMap);

    // Initial position fetch
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          if (leafletMap) {
            leafletMap.setView([lat, lng], 16);
            updateCurrentPosMarker(lat, lng);
          }
        },
        (err) => {
          console.log("GPS inicial:", err.message);
        },
        { enableHighAccuracy: true, timeout: 8000 }
      );
    }
  }

  setTimeout(() => {
    if (leafletMap) leafletMap.invalidateSize();
  }, 200);
}

function toggleMapTiles() {
  triggerHaptic('light');
  if (!leafletMap) return;
  const btn = document.getElementById("btnToggleMapLayer");
  if (isSatellite) {
    leafletMap.removeLayer(mapSatLayer);
    mapStreetLayer.addTo(leafletMap);
    isSatellite = false;
    if (btn) btn.innerText = "🗺️ Ruas";
  } else {
    leafletMap.removeLayer(mapStreetLayer);
    mapSatLayer.addTo(leafletMap);
    isSatellite = true;
    if (btn) btn.innerText = "🛰️ Satélite";
  }
}

function centerMapOnCurrentPos() {
  triggerHaptic('light');
  if (lastGpsPoint && leafletMap) {
    leafletMap.setView([lastGpsPoint.lat, lastGpsPoint.lng], 17);
  } else if (navigator.geolocation && leafletMap) {
    navigator.geolocation.getCurrentPosition((pos) => {
      const lat = pos.coords.latitude;
      const lng = pos.coords.longitude;
      leafletMap.setView([lat, lng], 17);
      updateCurrentPosMarker(lat, lng);
    });
  }
}

function updateCurrentPosMarker(lat, lng) {
  if (!leafletMap || typeof L === 'undefined') return;

  const pulseIcon = L.divIcon({
    className: 'gps-pulse-icon',
    html: `<div style="width: 16px; height: 16px; border-radius: 50%; background: #3b82f6; border: 3px solid #fff; box-shadow: 0 0 12px #3b82f6;"></div>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8]
  });

  if (!currentPosMarker) {
    currentPosMarker = L.marker([lat, lng], { icon: pulseIcon }).addTo(leafletMap);
  } else {
    currentPosMarker.setLatLng([lat, lng]);
  }
}

// Haversine Distance Formula (km)
function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function startGpsRun() {
  if (!navigator.geolocation) {
    alert("Geolocalização GPS não é suportada pelo seu navegador.");
    return;
  }

  sfx.init();
  triggerHaptic('success');
  initRunMapIfNeeded();

  gpsTracking = true;
  gpsPaused = false;
  gpsElapsedSeconds = 0;
  gpsTotalKm = 0;
  gpsRoutePoints = [];
  lastGpsPoint = null;

  if (routePolyline) {
    routePolyline.setLatLngs([]);
    routePolyline.setStyle({ color: currentGpsActivity === 'bike' ? '#00d2ff' : '#ff5722' });
  }
  if (startPosMarker && leafletMap) {
    leafletMap.removeLayer(startPosMarker);
    startPosMarker = null;
  }

  // Keep mobile screen on
  requestScreenWakeLock();

  // Update UI buttons
  document.getElementById("btnGpsStart").style.display = "none";
  document.getElementById("btnGpsPause").style.display = "inline-flex";
  document.getElementById("btnGpsFinish").style.display = "inline-flex";
  document.getElementById("btnGpsCancel").style.display = "inline-flex";
  document.getElementById("btnGpsResume").style.display = "none";

  const statusText = document.getElementById("gpsStatusText");
  if (statusText) {
    statusText.innerText = currentGpsActivity === 'bike' 
      ? "🔴 Gravando pedalada GPS ao vivo... Bora pedalar! 🚴" 
      : "🔴 Gravando rota GPS ao vivo... Bora correr! 🏃";
  }

  // Start Live Timer (Imune ao bloqueio de tela)
  gpsStartTime = Date.now();
  gpsAccumulatedSeconds = 0;
  gpsElapsedSeconds = 0;
  startBackgroundWorkerTicker();
  saveActiveGpsSession();

  if (gpsTimerInterval) clearInterval(gpsTimerInterval);
  gpsTimerInterval = setInterval(() => {
    if (!gpsPaused) {
      gpsElapsedSeconds = getActualGpsSeconds();
      updateGpsHud();
    }
  }, 1000);

  // Start GPS Watch Position
  gpsWatchId = navigator.geolocation.watchPosition(
    handleGpsPosition,
    handleGpsError,
    { enableHighAccuracy: true, maximumAge: 1000, timeout: 10000 }
  );
}

function handleGpsPosition(position) {
  if (!gpsTracking || gpsPaused) return;

  const { latitude, longitude, accuracy } = position.coords;

  // Filter out extreme GPS jitter
  if (accuracy > 40) return;

  const statusText = document.getElementById("gpsStatusText");
  if (statusText) {
    statusText.innerText = `🔴 Gravando • Precisão GPS: ±${Math.round(accuracy)}m`;
  }

  const currentLatLng = [latitude, longitude];

  if (lastGpsPoint) {
    const dKm = calculateDistanceKm(lastGpsPoint.lat, lastGpsPoint.lng, latitude, longitude);
    // Only accumulate if moved at least 2.5 meters
    if (dKm >= 0.0025) {
      gpsTotalKm += dKm;
      lastGpsPoint = { lat: latitude, lng: longitude };
      gpsRoutePoints.push(currentLatLng);
      if (routePolyline) routePolyline.addLatLng(currentLatLng);
    }
  } else {
    // First GPS point (Start)
    lastGpsPoint = { lat: latitude, lng: longitude };
    gpsRoutePoints.push(currentLatLng);
    if (routePolyline) routePolyline.addLatLng(currentLatLng);

    // Add Green Start Flag/Circle
    if (leafletMap && typeof L !== 'undefined') {
      const startIcon = L.divIcon({
        className: 'start-marker-icon',
        html: `<div style="background: #10b981; color: #000; font-weight: 800; font-size: 11px; width: 22px; height: 22px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2px solid #fff; box-shadow: 0 0 10px #10b981;">▶</div>`,
        iconSize: [22, 22],
        iconAnchor: [11, 11]
      });
      startPosMarker = L.marker(currentLatLng, { icon: startIcon }).addTo(leafletMap);
    }
  }

  // Update current pos marker & pan map smoothly
  updateCurrentPosMarker(latitude, longitude);
  if (leafletMap) leafletMap.panTo(currentLatLng);

  updateGpsHud();
}

function handleGpsError(err) {
  console.warn("Erro GPS:", err.message);
  const statusText = document.getElementById("gpsStatusText");
  if (statusText) {
    statusText.innerText = "Aguardando sinal de satélite GPS...";
  }
}

function updateGpsHud() {
  // Time format
  const h = Math.floor(gpsElapsedSeconds / 3600);
  const m = Math.floor((gpsElapsedSeconds % 3600) / 60);
  const s = gpsElapsedSeconds % 60;
  const timeStr = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  document.getElementById("gpsLiveTimer").innerText = timeStr;

  // Distance
  document.getElementById("gpsLiveDistance").innerText = gpsTotalKm.toFixed(2);

  // Secondary metric (Pace for running, Average Speed for bike)
  if (gpsTotalKm > 0.05) {
    if (currentGpsActivity === 'bike') {
      const avgSpeed = (gpsTotalKm / (gpsElapsedSeconds / 3600)).toFixed(1);
      document.getElementById("gpsLivePace").innerText = `${avgSpeed} km/h`;
    } else {
      const paceDecimal = (gpsElapsedSeconds / 60) / gpsTotalKm;
      const paceMin = Math.floor(paceDecimal);
      const paceSec = Math.round((paceDecimal - paceMin) * 60);
      if (paceMin < 60) {
        document.getElementById("gpsLivePace").innerText = `${paceMin}'${String(paceSec).padStart(2, '0')}"`;
      } else {
        document.getElementById("gpsLivePace").innerText = "-";
      }
    }

    // Speed km/h
    const speed = (gpsTotalKm / (gpsElapsedSeconds / 3600)).toFixed(1);
    document.getElementById("gpsLiveSpeed").innerText = speed;
  } else {
    document.getElementById("gpsLivePace").innerText = currentGpsActivity === 'bike' ? "0.0 km/h" : "-";
    document.getElementById("gpsLiveSpeed").innerText = "0.0";
  }
}

function pauseGpsRun() {
  triggerHaptic('medium');
  gpsAccumulatedSeconds = getActualGpsSeconds();
  gpsStartTime = null;
  gpsPaused = true;
  saveActiveGpsSession();
  document.getElementById("btnGpsPause").style.display = "none";
  document.getElementById("btnGpsResume").style.display = "inline-flex";
  const statusText = document.getElementById("gpsStatusText");
  if (statusText) {
    statusText.innerText = currentGpsActivity === 'bike'
      ? "⏸ Ciclismo pausado. Toque em Continuar para retomar."
      : "⏸ Corrida pausada. Toque em Continuar para retomar.";
  }
}

function resumeGpsRun() {
  triggerHaptic('medium');
  gpsStartTime = Date.now();
  gpsPaused = false;
  startBackgroundWorkerTicker();
  saveActiveGpsSession();
  document.getElementById("btnGpsResume").style.display = "none";
  document.getElementById("btnGpsPause").style.display = "inline-flex";
  const statusText = document.getElementById("gpsStatusText");
  if (statusText) {
    statusText.innerText = currentGpsActivity === 'bike'
      ? "🔴 Gravando pedalada GPS ao vivo... Bora pedalar! 🚴"
      : "🔴 Gravando rota GPS ao vivo... Bora correr! 🏃";
  }
}

function cancelGpsRun() {
  const actName = currentGpsActivity === 'bike' ? "este pedal de bike" : "esta corrida";
  if (confirm(`Deseja realmente cancelar ${actName}? Os dados não serão salvos.`)) {
    stopGpsTracking();
    resetGpsHud();
  }
}

function stopGpsTracking() {
  gpsTracking = false;
  gpsPaused = false;
  gpsStartTime = null;
  gpsAccumulatedSeconds = 0;
  try { localStorage.removeItem(GPS_TIMER_STORAGE_KEY); } catch(e) {}
  stopBackgroundWorkerTicker();
  if (gpsWatchId) {
    navigator.geolocation.clearWatch(gpsWatchId);
    gpsWatchId = null;
  }
  if (gpsTimerInterval) {
    clearInterval(gpsTimerInterval);
    gpsTimerInterval = null;
  }
  releaseScreenWakeLock();

  document.getElementById("btnGpsStart").style.display = "inline-flex";
  document.getElementById("btnGpsPause").style.display = "none";
  document.getElementById("btnGpsResume").style.display = "none";
  document.getElementById("btnGpsFinish").style.display = "none";
  document.getElementById("btnGpsCancel").style.display = "none";

  const statusText = document.getElementById("gpsStatusText");
  if (statusText) {
    statusText.innerText = currentGpsActivity === 'bike'
      ? "GPS pronto para Ciclismo. Toque em Iniciar e comece a pedalar!"
      : "GPS pronto para Corrida. Toque em Iniciar e comece a correr!";
  }
}

function resetGpsHud() {
  gpsElapsedSeconds = 0;
  gpsTotalKm = 0;
  gpsRoutePoints = [];
  lastGpsPoint = null;
  document.getElementById("gpsLiveTimer").innerText = "00:00:00";
  document.getElementById("gpsLiveDistance").innerText = "0.00";
  document.getElementById("gpsLivePace").innerText = currentGpsActivity === 'bike' ? "0.0 km/h" : "0'00\"";
  document.getElementById("gpsLiveSpeed").innerText = "0.0";
  if (routePolyline) routePolyline.setLatLngs([]);
}

function finishGpsRun() {
  triggerHaptic('success');
  sfx.playLevelUp();

  const isBike = currentGpsActivity === 'bike';
  const minutes = Math.max(1, Math.round(gpsElapsedSeconds / 60));
  const finalKm = parseFloat(gpsTotalKm.toFixed(2));

  let paceStr = "-";
  if (finalKm > 0) {
    if (isBike) {
      const avgSpeed = (finalKm / (minutes / 60)).toFixed(1);
      paceStr = `${avgSpeed} km/h`;
    } else {
      const paceDecimal = minutes / finalKm;
      const paceMin = Math.floor(paceDecimal);
      const paceSec = Math.round((paceDecimal - paceMin) * 60);
      paceStr = `${paceMin}'${String(paceSec).padStart(2, '0')}"/km`;
    }
  }

  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const runItem = {
    id: (isBike ? "bike_" : "run_") + Date.now(),
    date: getTodayDateStr(),
    timeStr: timeStr,
    activity: isBike ? 'bike' : 'run',
    km: finalKm,
    minutes: minutes,
    pace: paceStr,
    isGps: true,
    earnedMinutes: minutes,
    route: [...gpsRoutePoints] // Save the route for map viewing!
  };

  STATE.todayRuns.push(runItem);
  STATE.runningHistory.unshift(runItem);

  // Add the minutes to training hours (2h = 1pt rule!)
  const actLabel = isBike ? `Ciclismo GPS (${finalKm} km)` : `Corrida GPS (${finalKm} km)`;
  addTrainingMinutes(minutes, actLabel);

  stopGpsTracking();
  resetGpsHud();
  renderRunningTab();

  if (isBike) {
    alert(`🚴 Ciclismo finalizado com sucesso!\n\n📏 Distância: ${finalKm} km\n⏱️ Duração: ${minutes} min\n⚡ Vel. Média: ${paceStr}\n\nSua rota foi salva no Histórico!`);
  } else {
    alert(`🏁 Corrida finalizada com sucesso!\n\n📏 Distância: ${finalKm} km\n⏱️ Duração: ${minutes} min\n⚡ Ritmo: ${paceStr}\n\nSua rota foi salva no Histórico!`);
  }
}

// --- ROUTE MODAL VIEWER (View saved GPS routes on satellite map) ---
function openRouteModal(runId) {
  triggerHaptic('light');
  const run = STATE.runningHistory.find(r => r.id === runId);
  if (!run || !run.route || run.route.length === 0) {
    alert("Esta atividade foi registrada manualmente e não possui rota de mapa.");
    return;
  }

  const isBike = run.activity === 'bike';
  document.getElementById("routeModalTitle").innerText = isBike 
    ? `🚴 Ciclismo de ${run.km} km` 
    : `🏃 Corrida de ${run.km} km`;
  
  const metricLabel = isBike ? "Vel. Média:" : "Ritmo:";
  document.getElementById("routeModalDetails").innerHTML = `
    <strong>Data:</strong> ${run.date} às ${run.timeStr} • <strong>Tempo:</strong> ${run.minutes} min • <strong>${metricLabel}</strong> ${run.pace}
  `;

  document.getElementById("routeModal").classList.add("open");

  setTimeout(() => {
    initRouteModalMap(run.route, isBike);
  }, 250);
}

function closeRouteModal() {
  triggerHaptic('light');
  document.getElementById("routeModal").classList.remove("open");
}

function initRouteModalMap(routePoints, isBike) {
  if (typeof L === 'undefined') return;

  const container = document.getElementById("routeModalMap");
  if (!container) return;

  if (routeModalMap) {
    routeModalMap.remove();
    routeModalMap = null;
  }

  routeModalMap = L.map('routeModalMap', { zoomControl: false, preferCanvas: true });
  L.control.zoom({ position: 'bottomright' }).addTo(routeModalMap);

  // Satellite layer (Esri)
  L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19,
    attribution: '© Esri Satellite'
  }).addTo(routeModalMap);

  // Line color: Cyan for bike, Orange for running
  const lineColor = isBike ? '#00d2ff' : '#ff5722';
  routeModalPolyline = L.polyline(routePoints, {
    color: lineColor,
    weight: 6,
    opacity: 0.95,
    lineCap: 'round',
    lineJoin: 'round'
  }).addTo(routeModalMap);

  // Fit bounds to route
  if (routePoints.length > 0) {
    routeModalMap.fitBounds(routeModalPolyline.getBounds(), { padding: [30, 30] });

    // Start Pin (Green)
    L.circleMarker(routePoints[0], {
      radius: 7,
      color: '#fff',
      weight: 2,
      fillColor: '#10b981',
      fillOpacity: 1
    }).addTo(routeModalMap).bindPopup(isBike ? "Início do Ciclismo" : "Início da Corrida");

    // End Pin (Red)
    L.circleMarker(routePoints[routePoints.length - 1], {
      radius: 7,
      color: '#fff',
      weight: 2,
      fillColor: '#ef4444',
      fillOpacity: 1
    }).addTo(routeModalMap).bindPopup(isBike ? "Fim do Ciclismo" : "Fim da Corrida");
  }
}

// --- MANUAL RUN FORM ---
function calcRunPace() {
  const km = parseFloat(document.getElementById("runInputKm").value) || 0;
  const mins = parseFloat(document.getElementById("runInputMinutes").value) || 0;
  
  const paceEl = document.getElementById("runCalcPace");
  const speedEl = document.getElementById("runCalcSpeed");
  const calEl = document.getElementById("runCalcCalories");
  
  if (km > 0 && mins > 0) {
    const paceDecimal = mins / km;
    const paceMin = Math.floor(paceDecimal);
    const paceSec = Math.round((paceDecimal - paceMin) * 60);
    paceEl.innerText = `${paceMin}'${String(paceSec).padStart(2, '0')}"/km`;
    
    const speed = (km / (mins / 60)).toFixed(1);
    speedEl.innerText = `${speed} km/h`;
    
    const cals = Math.round(km * 65);
    calEl.innerText = `~${cals} kcal`;
  } else {
    paceEl.innerText = "-";
    speedEl.innerText = "-";
    calEl.innerText = "-";
  }
}

function handleSaveRun(e) {
  e.preventDefault();
  sfx.init();
  const km = parseFloat(document.getElementById("runInputKm").value);
  const minutes = parseInt(document.getElementById("runInputMinutes").value, 10);
  
  if (!km || !minutes) return;

  const paceDecimal = minutes / km;
  const paceMin = Math.floor(paceDecimal);
  const paceSec = Math.round((paceDecimal - paceMin) * 60);
  const paceStr = `${paceMin}'${String(paceSec).padStart(2, '0')}"/km`;

  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const runItem = {
    id: "run_" + Date.now(),
    date: getTodayDateStr(),
    timeStr: timeStr,
    km: km,
    minutes: minutes,
    pace: paceStr,
    isGps: false,
    earnedMinutes: 0, // Manual runs do NOT give level points (GPS anti-cheat rule)
    route: null
  };

  STATE.todayRuns.push(runItem);
  STATE.runningHistory.unshift(runItem);

  // Manual runs do NOT award level points - save state & update UI
  saveState();
  sfx.playCheck();

  document.getElementById("runForm").reset();
  calcRunPace();
  alert(`📝 Corrida manual de ${km} km salva no histórico!\n\n🛡️ Nota: Registros manuais de esteira não pontuam para o Nível/Ranking. Apenas corridas ao vivo rastreadas pelo GPS oficial somam pontos de evolução.`);
  renderRunningTab();
}

// --- EDIT & DELETE RUN / CARDIO FUNCTIONS ---
function openEditRunModal(runId) {
  triggerHaptic('light');
  const run = STATE.runningHistory.find(r => r.id === runId);
  if (!run) return;

  document.getElementById("editRunId").value = runId;
  document.getElementById("editRunNewMinutes").value = run.minutes;

  const isRope = run.activity === 'rope';
  const isBike = run.activity === 'bike';
  const isGps = !!(run.isGps || (run.route && run.route.length > 0));
  const isOfficial = isGps || run.isSensor || isRope;

  let activityHeader = `🏃 <strong>Distância:</strong> ${run.km} km`;
  if (isRope) {
    activityHeader = `🪢 <strong>Pular Corda:</strong> ${run.jumps || 0} pulos`;
  } else if (isBike) {
    activityHeader = `🚴 <strong>Ciclismo / Bike:</strong> ${run.km} km`;
  }

  let modalBadge = '<span style="color: var(--accent-orange); font-weight:700;">📝 Manual / Esteira (Sem Pontos)</span>';
  if (isRope) {
    modalBadge = '<span style="color: #60a5fa; font-weight:700;">📲 Sensor Oficial (Pontua)</span>';
  } else if (isBike) {
    modalBadge = '<span style="color: #00d2ff; font-weight:700;">🛰️ GPS Bike Oficial (Pontua)</span>';
  } else if (isGps) {
    modalBadge = '<span style="color: var(--accent-green); font-weight:700;">🛰️ GPS Corrida Oficial (Pontua)</span>';
  }

  const infoEl = document.getElementById("editRunInfo");
  infoEl.innerHTML = `
    <div>${activityHeader}</div>
    <div><strong>📅 Data:</strong> ${run.date} às ${run.timeStr}</div>
    <div><strong>⏱️ Tempo Atual:</strong> ${run.minutes} minutos</div>
    <div style="margin-top: 4px;"><strong>Modalidade:</strong> ${modalBadge}</div>
  `;

  const noteEl = document.getElementById("editRunPointsNote");
  if (isOfficial) {
    noteEl.innerHTML = `💡 Como esta atividade é <strong>Oficial (GPS / Sensor)</strong>, ao alterar os minutos, sua pontuação de nível e horas de treino serão <strong>recalculadas automaticamente</strong> (2 horas = 1 ponto).`;
    noteEl.style.color = "var(--accent-green)";
  } else {
    noteEl.innerHTML = `ℹ️ Esta atividade foi registrada <strong>manualmente</strong>. O tempo será atualizado, mas não concede pontos de nível (regra anti-fraude).`;
    noteEl.style.color = "var(--text-muted)";
  }

  document.getElementById("editRunModal").classList.add("open");
}

function closeEditRunModal() {
  triggerHaptic('light');
  const modal = document.getElementById("editRunModal");
  if (modal) modal.classList.remove("open");
}

function handleSaveEditRun(e) {
  e.preventDefault();
  triggerHaptic('light');
  const runId = document.getElementById("editRunId").value;
  const newMinutes = parseInt(document.getElementById("editRunNewMinutes").value, 10);

  if (!newMinutes || newMinutes < 1) {
    alert("Por favor, digite um tempo válido em minutos (mínimo 1 min).");
    return;
  }

  const run = STATE.runningHistory.find(r => r.id === runId);
  if (!run) return;

  const oldMinutes = run.minutes || 0;
  const isRope = run.activity === 'rope';
  const isBike = run.activity === 'bike';
  const isGps = !!(run.isGps || (run.route && run.route.length > 0));
  const isOfficial = isGps || run.isSensor || isRope;

  run.minutes = newMinutes;

  // Recalculate metrics
  if (isRope) {
    run.pace = `${Math.round((run.jumps || 0) / newMinutes)} pulos/min`;
  } else if (isBike && run.km > 0) {
    const avgSpeed = (run.km / (newMinutes / 60)).toFixed(1);
    run.pace = `${avgSpeed} km/h`;
  } else if (run.km > 0) {
    const paceDecimal = newMinutes / run.km;
    const paceMin = Math.floor(paceDecimal);
    const paceSec = Math.round((paceDecimal - paceMin) * 60);
    run.pace = `${paceMin}'${String(paceSec).padStart(2, '0')}"/km`;
  }

  // Update in todayRuns if present
  const todayRun = (STATE.todayRuns || []).find(r => r.id === runId);
  if (todayRun) {
    todayRun.minutes = newMinutes;
    todayRun.pace = run.pace;
  }

  // Recalculate points if Official (GPS / Sensor)
  if (isOfficial) {
    const diff = newMinutes - oldMinutes;
    run.earnedMinutes = (typeof run.earnedMinutes === 'number' ? run.earnedMinutes : oldMinutes) + diff;
    STATE.totalMinutes = Math.max(0, (STATE.totalMinutes || 0) + diff);
    updateLevelAndPoints();
  }

  saveState();
  closeEditRunModal();
  renderRunningTab();
  triggerHaptic('success');
  alert(`✓ Tempo da atividade atualizado para ${newMinutes} minutos com sucesso!`);
}

function deleteRun(runId) {
  triggerHaptic('light');
  const index = STATE.runningHistory.findIndex(r => r.id === runId);
  if (index === -1) return;

  const run = STATE.runningHistory[index];
  const isRope = run.activity === 'rope';
  const isBike = run.activity === 'bike';
  const isGps = !!(run.isGps || (run.route && run.route.length > 0));
  const isOfficial = isGps || run.isSensor || isRope;
  
  // Calculate if this session contributed minutes to level
  let earnedMinutes = 0;
  if (typeof run.earnedMinutes === 'number') {
    earnedMinutes = run.earnedMinutes;
  } else if (isOfficial) {
    earnedMinutes = run.minutes || 0;
  } else if (!('isGps' in run)) {
    earnedMinutes = run.minutes || 0;
  }

  let actDesc = `${run.km} km (${run.minutes} min)`;
  if (isRope) {
    actDesc = `corda de ${run.jumps || 0} pulos (${run.minutes} min)`;
  } else if (isBike) {
    actDesc = `ciclismo de ${run.km} km (${run.minutes} min)`;
  }

  const confirmMsg = earnedMinutes > 0
    ? `Deseja realmente apagar esta atividade de ${actDesc}?\n\n⚠️ Esta atividade gerou ${earnedMinutes} minutos de treino. Seus pontos e nível serão recalculados automaticamente.`
    : `Deseja realmente apagar esta atividade de ${actDesc} do seu histórico?`;

  if (!confirm(confirmMsg)) return;

  // Deduct points/minutes if it had earned minutes
  if (earnedMinutes > 0) {
    STATE.totalMinutes = Math.max(0, (STATE.totalMinutes || 0) - earnedMinutes);
    // Remove from todaySessions / workoutHistory if matched
    STATE.todaySessions = (STATE.todaySessions || []).filter(s => {
      const isCardio = s.type && (s.type.includes('Corrida') || s.type.includes('Ciclismo') || s.type.includes('Corda'));
      return !(isCardio && s.minutes === run.minutes && s.date === run.date);
    });
    STATE.workoutHistory = (STATE.workoutHistory || []).filter(s => {
      const isCardio = s.type && (s.type.includes('Corrida') || s.type.includes('Ciclismo') || s.type.includes('Corda'));
      return !(isCardio && s.minutes === run.minutes && s.date === run.date);
    });
    updateLevelAndPoints();
  }

  // Remove from arrays
  STATE.runningHistory.splice(index, 1);
  STATE.todayRuns = (STATE.todayRuns || []).filter(r => r.id !== runId);

  saveState();
  renderRunningTab();
  triggerHaptic('success');
}

function clearAllRunsHistory() {
  triggerHaptic('light');
  if (!STATE.runningHistory || STATE.runningHistory.length === 0) {
    alert("Seu histórico de cardio já está vazio.");
    return;
  }

  if (!confirm("⚠️ Atenção: Deseja apagar TODO o seu histórico de cardio (Corrida, Bike e Corda)?\n\nTodas as atividades serão excluídas e os minutos oficiais serão recalculados no seu nível.")) {
    return;
  }

  // Calculate total minutes to deduct
  let totalDeduction = 0;
  STATE.runningHistory.forEach(run => {
    const isOfficial = !!(run.isGps || run.isSensor || run.activity === 'rope' || (run.route && run.route.length > 0));
    if (typeof run.earnedMinutes === 'number') {
      totalDeduction += run.earnedMinutes;
    } else if (isOfficial) {
      totalDeduction += (run.minutes || 0);
    } else if (!('isGps' in run)) {
      totalDeduction += (run.minutes || 0);
    }
  });

  if (totalDeduction > 0) {
    STATE.totalMinutes = Math.max(0, (STATE.totalMinutes || 0) - totalDeduction);
    STATE.todaySessions = (STATE.todaySessions || []).filter(s => !(s.type && (s.type.includes('Corrida') || s.type.includes('Ciclismo') || s.type.includes('Corda'))));
    STATE.workoutHistory = (STATE.workoutHistory || []).filter(s => !(s.type && (s.type.includes('Corrida') || s.type.includes('Ciclismo') || s.type.includes('Corda'))));
    updateLevelAndPoints();
  }

  STATE.runningHistory = [];
  STATE.todayRuns = [];

  saveState();
  renderRunningTab();
  triggerHaptic('success');
  alert(`✓ Histórico de cardio apagado com sucesso!${totalDeduction > 0 ? ` (-${totalDeduction} min ajustados)` : ''}`);
}

// --- DAILY CHALLENGE CLAIM ---
function claimDailyChallenge() {
  if (STATE.dailyChallenge.completed) {
    alert("Você já completou o desafio de hoje! Parabéns pela disciplina! 🔥");
    return;
  }
  const todayTotalMin = STATE.todaySessions.reduce((acc, s) => acc + s.durationMin, 0);
  if (todayTotalMin >= STATE.dailyChallenge.targetMinutes) {
    STATE.dailyChallenge.completed = true;
    sfx.playLevelUp();
    saveState();
    renderHomeTab();
    alert("Desafio Diário Concluído com Sucesso! 🏆");
  } else {
    const diff = STATE.dailyChallenge.targetMinutes - todayTotalMin;
    alert(`Faltam ${diff} minutos de treino para bater a meta de hoje! Continue firme!`);
  }
}

// --- MISSÃO SURPRESA DA SEMANA (SOLO LEVELING STYLE) ---
function renderSurpriseMissionCard() {
  const section = document.getElementById("surpriseMissionSection");
  if (!section) return;

  const today = getTodayDateStr();
  if (!STATE.surpriseMission) {
    section.style.display = "none";
    return;
  }

  const isToday = STATE.surpriseMission.assignedDate === today;
  if (isToday) {
    section.style.display = "block";
    document.getElementById("surpriseMissionTitle").innerText = STATE.surpriseMission.title;
    document.getElementById("surpriseMissionDesc").innerText = STATE.surpriseMission.desc;

    const todayTotalMin = STATE.todaySessions.reduce((acc, s) => acc + s.durationMin, 0);
    const target = STATE.surpriseMission.targetMinutes;
    const pct = Math.min(100, Math.round((todayTotalMin / target) * 100));

    document.getElementById("surpriseProgressBar").style.width = `${pct}%`;
    document.getElementById("surpriseProgressText").innerText = `${todayTotalMin} / ${target} min concluídos`;

    const statusBadge = document.getElementById("surpriseStatusBadge");
    const btn = document.getElementById("btnClaimSurpriseMission");

    if (STATE.surpriseMission.completed || todayTotalMin >= target) {
      if (!STATE.surpriseMission.completed) {
        STATE.surpriseMission.completed = true;
        saveState();
      }
      statusBadge.innerText = "MISSÃO CUMPRIDA! 🛡️";
      statusBadge.style.color = "var(--accent-green)";
      btn.disabled = true;
      btn.innerText = "✅ Salvo da Penalidade!";
      btn.style.background = "var(--accent-green)";
      btn.style.borderColor = "var(--accent-green)";
      btn.style.color = "#000";
    } else {
      statusBadge.innerText = "MISSÃO SURPRESA ATIVA";
      statusBadge.style.color = "#fca5a5";
      btn.disabled = false;
      btn.innerText = "🛡️ Concluir Missão";
      btn.style.background = "linear-gradient(135deg, #ef4444, #b91c1c)";
      btn.style.borderColor = "#f87171";
      btn.style.color = "#fff";
    }
  } else {
    section.style.display = "none";
  }
}

function claimSurpriseMission() {
  const todayTotalMin = STATE.todaySessions.reduce((acc, s) => acc + s.durationMin, 0);
  const target = STATE.surpriseMission ? STATE.surpriseMission.targetMinutes : 45;

  if (todayTotalMin >= target) {
    STATE.surpriseMission.completed = true;
    saveState();
    triggerHaptic('success');
    sfx.playLevelUp();
    alert("🛡️ MISSÃO SURPRESA CONCLUÍDA!\nVocê atingiu os minutos necessários, evitou a penalidade de -1 ponto e manteve sua posição no Ranking!");
    renderHomeTab();
  } else {
    triggerHaptic('warning');
    alert(`Ainda faltam ${target - todayTotalMin} minutos de treino para bater a missão surpresa e se salvar da penalidade de -1 ponto! Bora treinar! 💪`);
  }
}

function triggerSurpriseMissionModal() {
  if (!STATE.surpriseMission) return;
  sfx.playLevelUp();
  triggerHaptic('heavy');
  document.getElementById("modalSurpriseTitle").innerText = STATE.surpriseMission.title;
  document.getElementById("modalSurpriseMin").innerText = STATE.surpriseMission.targetMinutes;
  document.getElementById("surpriseMissionModal").classList.add("open");
}

function closeSurpriseMissionModal() {
  document.getElementById("surpriseMissionModal").classList.remove("open");
}

function triggerPenaltyModal(mission) {
  triggerHaptic('heavy');
  document.getElementById("penaltyModal").classList.add("open");
}

function closePenaltyModal() {
  document.getElementById("penaltyModal").classList.remove("open");
  renderAll();
}

function triggerSeasonResetModal(pastYear, levelObj) {
  triggerHaptic('success');
  sfx.playLevelUp();
  const nextYear = new Date().getFullYear();
  document.getElementById("seasonResetTitle").innerText = `BEM-VINDO A ${nextYear}!`;
  const summaryEl = document.getElementById("seasonArchiveSummary");
  if (summaryEl) {
    const pointsSaved = STATE.seasonHistory && STATE.seasonHistory[0] ? STATE.seasonHistory[0].points.toFixed(1) : '0.0';
    summaryEl.innerHTML = `
      <strong>🏆 Registro da Temporada ${pastYear}:</strong><br>
      Você encerrou o ano anterior com <strong>${levelObj.rankTier || 'E'} • ${levelObj.name}</strong> (${pointsSaved} pts).<br>
      Seus pontos foram zerados para a nova temporada anual. Boa sorte na busca pelo Rank SS Supremo deste ano!
    `;
  }
  document.getElementById("seasonResetModal").classList.add("open");
}

function closeSeasonResetModal() {
  document.getElementById("seasonResetModal").classList.remove("open");
  renderAll();
}

// --- WORKOUT BUILDER & EXERCISE MANAGEMENT ---
function setWorkoutDay(dayIndex) {
  STATE.activeDayIndex = dayIndex;
  renderWorkoutTab();
}

function editWorkoutTitle() {
  const current = STATE.routines[STATE.activeDayIndex].title;
  const newTitle = prompt("Novo título para o treino deste dia:", current);
  if (newTitle && newTitle.trim()) {
    STATE.routines[STATE.activeDayIndex].title = newTitle.trim();
    saveState();
    renderWorkoutTab();
  }
}

// --- EXERCISE CATALOG FOR BEGINNERS & QUICK SELECTOR ---
const EXERCISE_CATALOG = [
  // PEITO
  { muscle: "peito", name: "Supino Reto com Barra", sets: 4, reps: "8-10", rest: 60, notes: "Desça a barra no meio do peito com controle, sem bater." },
  { muscle: "peito", name: "Supino Inclinado com Halteres", sets: 4, reps: "10-12", rest: 60, notes: "Banco em 30-45 graus. Foco na porção superior do peitoral." },
  { muscle: "peito", name: "Supino Reto com Halteres", sets: 4, reps: "10-12", rest: 60, notes: "Maior amplitude de movimento e estabilidade para os ombros." },
  { muscle: "peito", name: "Crucifixo na Polia (Crossover)", sets: 3, reps: "12-15", rest: 45, notes: "Aperte 1 segundo no pico de contração no centro." },
  { muscle: "peito", name: "Voador / Peck Deck Máquina", sets: 3, reps: "12-15", rest: 45, notes: "Excelente para novatos aprenderem o isolamento do peitoral." },
  { muscle: "peito", name: "Supino Máquina Articulada", sets: 4, reps: "10-12", rest: 60, notes: "Muito seguro para iniciantes aumentarem a carga com firmeza." },
  { muscle: "peito", name: "Flexão de Braço (Solo)", sets: 3, reps: "10-15", rest: 60, notes: "Corpo em linha reta e abdômen contraído o tempo todo." },

  // COSTAS
  { muscle: "costas", name: "Puxada Frontal Alta na Polia", sets: 4, reps: "8-10", rest: 60, notes: "Puxe a barra até a altura do queixo, estufando o peito." },
  { muscle: "costas", name: "Remada Baixa no Triângulo", sets: 4, reps: "10-12", rest: 60, notes: "Coluna ereta, puxe o triângulo no abdômen sem curvar as costas." },
  { muscle: "costas", name: "Remada Curvada com Barra", sets: 3, reps: "8-10", rest: 90, notes: "Tronco inclinado a 45 graus, puxe a barra rente às pernas." },
  { muscle: "costas", name: "Pulldown na Polia (Corda/Barra)", sets: 3, reps: "12-15", rest: 45, notes: "Braços estendidos, ative as costas (dorsais) sem dobrar cotovelos." },
  { muscle: "costas", name: "Remada Unilateral com Halter (Serrote)", sets: 3, reps: "10-12", rest: 45, notes: "Apoie o joelho no banco e puxe o halter rente ao quadril." },
  { muscle: "costas", name: "Remada Máquina Articulada", sets: 4, reps: "10-12", rest: 60, notes: "Apoio no peito para proteger a lombar do iniciante." },
  { muscle: "costas", name: "Barra Fixa (Graviton ou Livre)", sets: 3, reps: "6-10", rest: 90, notes: "Exercício rei para abrir as costas e ganhar força." },

  // PERNAS (QUADRÍCEPS)
  { muscle: "pernas", name: "Agachamento Livre com Barra", sets: 4, reps: "8-10", rest: 90, notes: "Pés na largura dos ombros, desça até 90 graus ou mais." },
  { muscle: "pernas", name: "Leg Press 45°", sets: 4, reps: "10-12", rest: 90, notes: "Não trave os joelhos no topo, desça bem controlando o peso." },
  { muscle: "pernas", name: "Cadeira Extensora", sets: 4, reps: "12-15", rest: 45, notes: "Segure 1 segundo no topo contraindo a coxa fortemente." },
  { muscle: "pernas", name: "Agachamento no Hack Machine", sets: 4, reps: "10-12", rest: 90, notes: "Encosto apoiado, excelente e seguro para as pernas do novato." },
  { muscle: "pernas", name: "Agachamento Búlgaro com Halteres", sets: 3, reps: "10-12", rest: 60, notes: "Pé de trás apoiado no banco, foco total na perna da frente." },
  { muscle: "pernas", name: "Afundo / Passada com Halteres", sets: 3, reps: "12 passos", rest: 60, notes: "Passo firme mantendo o tronco ereto e equilibrado." },
  { muscle: "pernas", name: "Agachamento Goblet com Halter", sets: 3, reps: "12-15", rest: 60, notes: "Segure o halter junto ao peito, perfeito para aprender a agachar." },

  // POSTERIOR & GLÚTEOS
  { muscle: "posterior", name: "Mesa Flexora", sets: 4, reps: "10-12", rest: 60, notes: "Puxe os calcanhares no glúteo sem tirar o quadril do banco." },
  { muscle: "posterior", name: "Cadeira Flexora", sets: 4, reps: "12-15", rest: 45, notes: "Ajuste o rolo nos tornozelos e flexione as pernas para baixo." },
  { muscle: "posterior", name: "Stiff com Barra ou Halteres", sets: 4, reps: "10-12", rest: 60, notes: "Coluna reta e joelhos semi-flexionados, sinta o posterior alongar." },
  { muscle: "posterior", name: "Elevação Pélvica com Barra/Halter", sets: 4, reps: "10-12", rest: 60, notes: "Apoie as costas no banco e aperte o glúteo 2s no topo." },
  { muscle: "posterior", name: "Cadeira Abdutora", sets: 3, reps: "15-20", rest: 45, notes: "Abra as pernas controlando o movimento, foco no glúteo médio." },
  { muscle: "posterior", name: "Cadeira Adutora", sets: 3, reps: "15-20", rest: 45, notes: "Feche as pernas com força, foco na parte interna da coxa." },

  // OMBROS
  { muscle: "ombros", name: "Desenvolvimento com Halteres", sets: 4, reps: "8-10", rest: 60, notes: "Suba os halteres em arco sem bater em cima, desça a 90 graus." },
  { muscle: "ombros", name: "Elevação Lateral com Halteres", sets: 4, reps: "12-15", rest: 45, notes: "Cotovelos levemente dobrados, erga até a linha do ombro." },
  { muscle: "ombros", name: "Elevação Lateral na Polia", sets: 3, reps: "12-15", rest: 45, notes: "Tensão constante desde o início do movimento." },
  { muscle: "ombros", name: "Crucifixo Invertido na Máquina", sets: 3, reps: "12-15", rest: 45, notes: "Foco no deltoide posterior para desenhar a parte de trás do ombro." },
  { muscle: "ombros", name: "Elevação Frontal com Halteres", sets: 3, reps: "12", rest: 45, notes: "Erga os braços alternados até a altura dos olhos." },
  { muscle: "ombros", name: "Face Pull na Polia com Corda", sets: 3, reps: "15", rest: 45, notes: "Puxe a corda em direção ao rosto com cotovelos bem altos." },

  // BÍCEPS & ANTEBRAÇO
  { muscle: "biceps", name: "Rosca Direta com Barra W", sets: 4, reps: "10-12", rest: 60, notes: "Cotovelos colados ao tronco, suba sem balançar a lombar." },
  { muscle: "biceps", name: "Rosca Martelo com Halteres", sets: 3, reps: "10-12", rest: 45, notes: "Pegada neutra (palmas voltadas para dentro), engrossa o braço." },
  { muscle: "biceps", name: "Rosca Scott na Máquina", sets: 3, reps: "10-12", rest: 60, notes: "Isolamento total do bíceps com apoio seguro nos braços." },
  { muscle: "biceps", name: "Rosca no Banco Inclinado 45°", sets: 3, reps: "10-12", rest: 60, notes: "Alongamento máximo do bíceps, excelente para o pico muscular." },
  { muscle: "biceps", name: "Rosca Concentrada com Halter", sets: 3, reps: "12", rest: 45, notes: "Cotovelo apoiado na parte interna da coxa, foco e contração." },
  { muscle: "biceps", name: "Rosca na Polia Baixa", sets: 3, reps: "12-15", rest: 45, notes: "Cabo puxando constantemente, sem ponto de descanso." },
  { muscle: "biceps", name: "Flexão de Punho para Antebraço", sets: 3, reps: "15-20", rest: 40, notes: "Apoie os antebraços no banco e flexione os punhos para cima." },

  // TRÍCEPS
  { muscle: "triceps", name: "Tríceps Corda na Polia", sets: 4, reps: "12-15", rest: 45, notes: "Abra a corda para fora no final do movimento para contrair tudo." },
  { muscle: "triceps", name: "Tríceps Pulley Barra Reta / V", sets: 4, reps: "10-12", rest: 45, notes: "Cotovelos travados ao lado do corpo, empurre até estender." },
  { muscle: "triceps", name: "Tríceps Francês com Halter", sets: 3, reps: "10-12", rest: 60, notes: "Segure o halter atrás da cabeça mantendo cotovelos fechados." },
  { muscle: "triceps", name: "Tríceps Testa com Barra W", sets: 3, reps: "10-12", rest: 60, notes: "Deitado no banco, desça a barra controlando até a testa." },
  { muscle: "triceps", name: "Mergulho no Banco (Paralelas)", sets: 3, reps: "12-15", rest: 60, notes: "Mãos apoiadas no banco, desça o corpo rente e empurre com os braços." },

  // PANTURRILHA
  { muscle: "panturrilha", name: "Panturrilha em Pé na Máquina / Smith", sets: 4, reps: "15-20", rest: 45, notes: "Alongue bem o calcanhar na descida e suba na ponta máxima dos pés." },
  { muscle: "panturrilha", name: "Panturrilha Sentado (Gêmeos)", sets: 4, reps: "15-20", rest: 45, notes: "Foco no músculo sóleo, faça o movimento completo e cadenciado." },
  { muscle: "panturrilha", name: "Panturrilha no Leg Press", sets: 4, reps: "15-20", rest: 45, notes: "Apoie só as pontas dos pés na base inferior e empurre com os tornozelos." },

  // TRAPÉZIO
  { muscle: "trapezio", name: "Encolhimento com Halteres", sets: 4, reps: "12-15", rest: 45, notes: "Erga os ombros em direção às orelhas, segure 1 segundo no topo." },
  { muscle: "trapezio", name: "Encolhimento com Barra", sets: 4, reps: "12-15", rest: 45, notes: "Movimento puramente vertical para cima, sem girar os ombros." },

  // ABDÔMEN & CORE
  { muscle: "abdomen", name: "Abdominal Supra no Solo", sets: 4, reps: "15-20", rest: 45, notes: "Solte todo o ar ao subir e aperte a musculatura abdominal." },
  { muscle: "abdomen", name: "Prancha Abdominal", sets: 3, reps: "45-60 seg", rest: 45, notes: "Corpo reto como uma tábua, sem deixar o quadril cair." },
  { muscle: "abdomen", name: "Elevação de Pernas na Barra Fixa", sets: 3, reps: "12-15", rest: 45, notes: "Suba os joelhos ou pernas até 90 graus sem balanço." },
  { muscle: "abdomen", name: "Abdominal Infra no Banco", sets: 3, reps: "15-20", rest: 45, notes: "Tire o quadril levemente do banco no final da subida." },
  { muscle: "abdomen", name: "Abdominal na Roda (Ab Wheel)", sets: 3, reps: "8-12", rest: 60, notes: "Role para frente com abdômen travado e retorne com força." }
];

// --- MODELOS DE PLANILHAS PRONTAS DE TREINO ---
const WORKOUT_TEMPLATES = {
  daily_recommended: () => {
    const currentDay = STATE.activeDayIndex;
    const def = DEFAULT_WORKOUT_ROUTINES[currentDay];
    return {
      title: def.title,
      exercises: def.exercises.map(e => ({ ...e, id: "ex_" + Date.now() + "_" + Math.random().toString(36).substr(2, 4), done: false }))
    };
  },
  beginner_adaptation: () => ({
    title: "Adaptação Iniciante / Novato Total",
    exercises: [
      { id: "b1", name: "Leg Press 45°", sets: 3, reps: "12-15", weight: 40, rest: 60, notes: "Movimento controlado, pés firmes", done: false },
      { id: "b2", name: "Puxada Frontal Alta na Polia", sets: 3, reps: "10-12", weight: 25, rest: 60, notes: "Puxe até o peito, costas retas", done: false },
      { id: "b3", name: "Supino Máquina Articulada", sets: 3, reps: "10-12", weight: 20, rest: 60, notes: "Máquina guiada segura para novato", done: false },
      { id: "b4", name: "Cadeira Extensora", sets: 3, reps: "12-15", weight: 20, rest: 45, notes: "Segure 1s em cima", done: false },
      { id: "b5", name: "Abdominal Supra no Solo", sets: 3, reps: "15-20", weight: 0, rest: 45, notes: "Solte o ar na subida", done: false }
    ]
  }),
  push_day: () => ({
    title: "Ficha A: Peito, Tríceps & Ombros (Push)",
    exercises: [
      { id: "p1", name: "Supino Reto com Barra", sets: 4, reps: "8-10", weight: 30, rest: 60, notes: "Desça no meio do peitoral", done: false },
      { id: "p2", name: "Supino Inclinado com Halteres", sets: 4, reps: "10-12", weight: 14, rest: 60, notes: "Foco no peitoral superior", done: false },
      { id: "p3", name: "Crucifixo na Polia (Crossover)", sets: 3, reps: "12-15", weight: 15, rest: 45, notes: "Aperte 1s no meio", done: false },
      { id: "p4", name: "Desenvolvimento com Halteres", sets: 4, reps: "10-12", weight: 12, rest: 60, notes: "Ombros a 90 graus", done: false },
      { id: "p5", name: "Elevação Lateral com Halteres", sets: 4, reps: "12-15", weight: 6, rest: 45, notes: "Sem usar impulso", done: false },
      { id: "p6", name: "Tríceps Corda na Polia", sets: 4, reps: "12-15", weight: 20, rest: 45, notes: "Abra a corda no final", done: false }
    ]
  }),
  pull_day: () => ({
    title: "Ficha B: Costas, Bíceps & Abdômen (Pull)",
    exercises: [
      { id: "pl1", name: "Puxada Frontal Alta na Polia", sets: 4, reps: "8-10", weight: 35, rest: 60, notes: "Puxe até o queixo/peito", done: false },
      { id: "pl2", name: "Remada Baixa no Triângulo", sets: 4, reps: "10-12", weight: 30, rest: 60, notes: "Coluna ereta e peito aberto", done: false },
      { id: "pl3", name: "Remada Curvada com Barra", sets: 3, reps: "8-10", weight: 25, rest: 90, notes: "Tronco inclinado a 45°", done: false },
      { id: "pl4", name: "Rosca Direta com Barra W", sets: 4, reps: "10-12", weight: 16, rest: 60, notes: "Cotovelos colados ao corpo", done: false },
      { id: "pl5", name: "Rosca Martelo com Halteres", sets: 3, reps: "10-12", weight: 10, rest: 45, notes: "Foco no braquial e antebraço", done: false },
      { id: "pl6", name: "Prancha Abdominal", sets: 3, reps: "45 seg", weight: 0, rest: 45, notes: "Corpo reto e travado", done: false }
    ]
  }),
  legs_day: () => ({
    title: "Ficha C: Pernas Completo & Panturrilhas (Legs)",
    exercises: [
      { id: "l1", name: "Agachamento Livre com Barra", sets: 4, reps: "8-10", weight: 40, rest: 90, notes: "Desça até 90 graus", done: false },
      { id: "l2", name: "Leg Press 45°", sets: 4, reps: "10-12", weight: 100, rest: 90, notes: "Amplitude completa sem travar joelho", done: false },
      { id: "l3", name: "Cadeira Extensora", sets: 4, reps: "12-15", weight: 30, rest: 45, notes: "Segura 1s em cima", done: false },
      { id: "l4", name: "Mesa Flexora", sets: 4, reps: "10-12", weight: 25, rest: 60, notes: "Posterior de coxa", done: false },
      { id: "l5", name: "Panturrilha em Pé na Máquina", sets: 4, reps: "15-20", weight: 35, rest: 45, notes: "Alongue e suba no máximo", done: false }
    ]
  }),
  glutes_focus: () => ({
    title: "Ficha D: Glúteos & Posterior (Foco Inferiores)",
    exercises: [
      { id: "g1", name: "Elevação Pélvica com Barra/Halter", sets: 4, reps: "10-12", weight: 30, rest: 60, notes: "Contraia o glúteo 2s no topo", done: false },
      { id: "g2", name: "Agachamento Búlgaro", sets: 3, reps: "10-12", weight: 10, rest: 60, notes: "Foco na perna da frente", done: false },
      { id: "g3", name: "Stiff com Barra ou Halteres", sets: 4, reps: "10-12", weight: 20, rest: 60, notes: "Coluna reta, sinta posterior", done: false },
      { id: "g4", name: "Cadeira Flexora", sets: 4, reps: "12-15", weight: 25, rest: 45, notes: "Descida controlada", done: false },
      { id: "g5", name: "Cadeira Abdutora", sets: 3, reps: "15-20", weight: 30, rest: 45, notes: "Glúteo médio, segure 1s aberta", done: false }
    ]
  })
};

let currentSelectedMuscle = "all";
let currentSearchTerm = "";

function populateExerciseCatalogCards() {
  const container = document.getElementById("exerciseCatalogCards");
  const datalist = document.getElementById("exerciseDatalist");
  if (!container) return;

  const term = (currentSearchTerm || "").toLowerCase().trim();
  const filtered = EXERCISE_CATALOG.filter(ex => {
    const matchesMuscle = (currentSelectedMuscle === "all" || ex.muscle === currentSelectedMuscle);
    const matchesSearch = !term || ex.name.toLowerCase().includes(term) || (ex.notes && ex.notes.toLowerCase().includes(term));
    return matchesMuscle && matchesSearch;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; color: var(--text-muted); font-size: 0.75rem; padding: 12px 0;">
        Nenhum aparelho encontrado com "${term}".<br>
        Você pode digitar o nome que quiser no campo abaixo!
      </div>
    `;
  } else {
    const muscleEmojis = {
      peito: "🦾", costas: "🦅", pernas: "🦵", posterior: "🍑",
      ombros: "⚡", biceps: "💪", triceps: "🥊", panturrilha: "👟",
      trapezio: "🔺", abdomen: "🛡️"
    };

    container.innerHTML = filtered.map(ex => {
      const emoji = muscleEmojis[ex.muscle] || "🏋️";
      return `
        <div class="catalog-exercise-card" onclick="selectCatalogExercise('${ex.name.replace(/'/g, "\\'")}')">
          <div style="display: flex; justify-content: space-between; align-items: center; gap: 6px;">
            <strong style="color: #fff; font-size: 0.82rem;">${emoji} ${ex.name}</strong>
            <span style="font-size: 0.65rem; color: #00d2ff; background: rgba(0,210,255,0.14); padding: 2px 6px; border-radius: 4px; font-weight: 700; white-space: nowrap;">
              ${ex.sets}x ${ex.reps}
            </span>
          </div>
          <div style="font-size: 0.68rem; color: var(--text-muted); margin-top: 2px;">
            ${ex.notes}
          </div>
        </div>
      `;
    }).join('');
  }

  // Preenche Datalist de sugestões para o teclado do celular
  if (datalist) {
    datalist.innerHTML = EXERCISE_CATALOG.map(ex => `<option value="${ex.name}">`).join('');
  }
}

function handleCatalogSearch(term) {
  currentSearchTerm = term;
  populateExerciseCatalogCards();
}

function filterExercisesByMuscle(muscleGroup, btnElement) {
  triggerHaptic('light');
  currentSelectedMuscle = muscleGroup;

  if (btnElement && btnElement.parentElement) {
    const buttons = btnElement.parentElement.querySelectorAll('.quick-chip-btn');
    buttons.forEach(b => b.classList.remove('active'));
    btnElement.classList.add('active');
  }

  populateExerciseCatalogCards();
}

function selectCatalogExercise(exName) {
  if (!exName) return;
  triggerHaptic('light');
  const ex = EXERCISE_CATALOG.find(item => item.name === exName);
  if (!ex) return;

  document.getElementById("exerciseNameInput").value = ex.name;
  document.getElementById("exerciseSetsInput").value = ex.sets;
  document.getElementById("exerciseRepsInput").value = ex.reps;
  document.getElementById("exerciseRestInput").value = ex.rest;
  document.getElementById("exerciseNotesInput").value = ex.notes;

  // Destaque visual no card selecionado
  const cards = document.querySelectorAll(".catalog-exercise-card");
  cards.forEach(c => {
    if (c.innerText.includes(ex.name)) {
      c.style.borderColor = "var(--accent-green)";
      c.style.background = "rgba(0, 210, 255, 0.22)";
    } else {
      c.style.borderColor = "";
      c.style.background = "";
    }
  });

  const tipBox = document.getElementById("exerciseExecutionTipBox");
  if (tipBox) {
    tipBox.style.display = "block";
    tipBox.innerHTML = `💡 <strong>Dica de Execução para Novatos:</strong> ${ex.notes}`;
  }
}

function openAddExerciseModal() {
  triggerHaptic('light');
  document.getElementById("exerciseModalTitle").innerText = "Adicionar Exercício";
  document.getElementById("exerciseId").value = "";
  document.getElementById("exerciseForm").reset();

  currentSelectedMuscle = "all";
  currentSearchTerm = "";
  const searchInput = document.getElementById("catalogSearchInput");
  if (searchInput) searchInput.value = "";

  const chipsContainer = document.getElementById("exerciseMuscleFilterChips");
  if (chipsContainer) {
    const buttons = chipsContainer.querySelectorAll('.quick-chip-btn');
    buttons.forEach((b, idx) => {
      if (idx === 0) b.classList.add('active');
      else b.classList.remove('active');
    });
  }

  populateExerciseCatalogCards();

  const tipBox = document.getElementById("exerciseExecutionTipBox");
  if (tipBox) {
    tipBox.style.display = "none";
    tipBox.innerText = "";
  }

  document.getElementById("exerciseModal").classList.add("open");
}

function openEditExerciseModal(exId) {
  triggerHaptic('light');
  const currentDay = (typeof STATE.activeDayIndex === 'number') ? STATE.activeDayIndex : 0;
  const routine = (STATE.routines && STATE.routines[currentDay]) ? STATE.routines[currentDay] : DEFAULT_WORKOUT_ROUTINES[0];
  const ex = (routine.exercises || []).find(e => e.id === exId);
  if (!ex) return;

  document.getElementById("exerciseModalTitle").innerText = "Editar Exercício";
  document.getElementById("exerciseId").value = ex.id;
  document.getElementById("exerciseNameInput").value = ex.name;
  document.getElementById("exerciseSetsInput").value = ex.sets;
  document.getElementById("exerciseRepsInput").value = ex.reps;
  document.getElementById("exerciseWeightInput").value = ex.weight || 0;
  document.getElementById("exerciseRestInput").value = ex.rest || 60;
  document.getElementById("exerciseNotesInput").value = ex.notes || "";

  populateExerciseCatalogCards();

  const tipBox = document.getElementById("exerciseExecutionTipBox");
  if (tipBox) {
    if (ex.notes) {
      tipBox.style.display = "block";
      tipBox.innerHTML = `💡 <strong>Dica / Observação:</strong> ${ex.notes}`;
    } else {
      tipBox.style.display = "none";
    }
  }

  document.getElementById("exerciseModal").classList.add("open");
}

function closeExerciseModal() {
  triggerHaptic('light');
  document.getElementById("exerciseModal").classList.remove("open");
}

function openWorkoutTemplatesModal() {
  try {
    triggerHaptic('light');
    const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
    if (!STATE.routines) STATE.routines = JSON.parse(JSON.stringify(DEFAULT_WORKOUT_ROUTINES));
    if (!STATE.routines[currentDay]) {
      STATE.routines[currentDay] = JSON.parse(JSON.stringify(DEFAULT_WORKOUT_ROUTINES[currentDay] || DEFAULT_WORKOUT_ROUTINES[0]));
    }
    const routine = STATE.routines[currentDay];
    
    const dailyTitleEl = document.getElementById("templateDailyTitle");
    const dailyDescEl = document.getElementById("templateDailyDesc");
    if (dailyTitleEl && routine) {
      dailyTitleEl.innerText = `⚡ Treino Oficial de Hoje (${routine.dayName || 'Hoje'}: ${routine.title || 'Treino'})`;
    }
    if (dailyDescEl && routine) {
      dailyDescEl.innerText = `Carrega a ficha oficial balanceada de ${routine.title || 'Treino'} com exercícios e cargas sugeridas.`;
    }

    const modal = document.getElementById("workoutTemplatesModal");
    if (modal) {
      modal.classList.add("open");
    } else {
      console.error("Modal workoutTemplatesModal não encontrado no DOM!");
    }
  } catch (err) {
    console.error("Erro em openWorkoutTemplatesModal:", err);
    const modal = document.getElementById("workoutTemplatesModal");
    if (modal) modal.classList.add("open");
  }
}

function closeWorkoutTemplatesModal() {
  triggerHaptic('light');
  const modal = document.getElementById("workoutTemplatesModal");
  if (modal) modal.classList.remove("open");
}

function loadWorkoutTemplate(templateType) {
  try {
    triggerHaptic('success');
    const currentDay = (typeof STATE.activeDayIndex === 'number') ? STATE.activeDayIndex : 0;
    if (!STATE.routines) STATE.routines = JSON.parse(JSON.stringify(DEFAULT_WORKOUT_ROUTINES));
    if (!STATE.routines[currentDay]) {
      STATE.routines[currentDay] = JSON.parse(JSON.stringify(DEFAULT_WORKOUT_ROUTINES[currentDay] || DEFAULT_WORKOUT_ROUTINES[0]));
    }
    const routine = STATE.routines[currentDay];

    if (templateType === 'clear') {
      if (!confirm(`Deseja realmente limpar todos os exercícios de ${routine.dayName || 'hoje'}?`)) return;
      routine.exercises = [];
      saveState();
      closeWorkoutTemplatesModal();
      renderWorkoutTab();
      return;
    }

    const templateFn = WORKOUT_TEMPLATES[templateType];
    if (!templateFn) return;

    const result = templateFn();
    if (!confirm(`Deseja carregar a planilha "${result.title}" para ${routine.dayName || 'hoje'}?\n\n(A ficha deste dia será preenchida com os exercícios recomendados).`)) {
      return;
    }

    routine.title = result.title;
    routine.exercises = result.exercises;

    saveState();
    closeWorkoutTemplatesModal();
    renderWorkoutTab();
    sfx.playLevelUp();
    alert(`✓ Planilha "${result.title}" montada com sucesso para ${routine.dayName || 'hoje'}! Bora treinar! 💪`);
  } catch (err) {
    console.error("Erro ao carregar template:", err);
    alert("Erro ao carregar planilha. Tente novamente.");
  }
}

function handleSaveExercise(e) {
  e.preventDefault();
  const exId = document.getElementById("exerciseId").value;
  const name = document.getElementById("exerciseNameInput").value.trim();
  const sets = parseInt(document.getElementById("exerciseSetsInput").value, 10);
  const reps = document.getElementById("exerciseRepsInput").value.trim();
  const weight = parseFloat(document.getElementById("exerciseWeightInput").value) || 0;
  const rest = parseInt(document.getElementById("exerciseRestInput").value, 10) || 60;
  const notes = document.getElementById("exerciseNotesInput").value.trim();

  const routine = STATE.routines[STATE.activeDayIndex];

  if (exId) {
    // Edit
    const item = routine.exercises.find(e => e.id === exId);
    if (item) {
      item.name = name;
      item.sets = sets;
      item.reps = reps;
      item.weight = weight;
      item.rest = rest;
      item.notes = notes;
    }
  } else {
    // Add new
    routine.exercises.push({
      id: "ex_" + Date.now(),
      name,
      sets,
      reps,
      weight,
      rest,
      notes,
      done: false
    });
  }

  saveState();
  closeExerciseModal();
  renderWorkoutTab();
  sfx.playCheck();
}

function toggleExerciseDone(exId) {
  const routine = STATE.routines[STATE.activeDayIndex];
  const ex = routine.exercises.find(e => e.id === exId);
  if (ex) {
    ex.done = !ex.done;
    if (ex.done) {
      sfx.playCheck();
      // Auto-trigger rest timer if requested
      if (ex.rest && confirm(`Exercício concluído! Iniciar descanso de ${ex.rest}s?`)) {
        startRestTimer(ex.rest);
      }
    }
    saveState();
    renderWorkoutTab();
  }
}

function deleteExercise(exId) {
  if (confirm("Deseja realmente remover este exercício?")) {
    const routine = STATE.routines[STATE.activeDayIndex];
    routine.exercises = routine.exercises.filter(e => e.id !== exId);
    saveState();
    renderWorkoutTab();
  }
}

// --- QUICK SESSION MODAL ---
function openQuickSessionModal() {
  document.getElementById("quickSessionModal").classList.add("open");
}

function closeQuickSessionModal() {
  document.getElementById("quickSessionModal").classList.remove("open");
}

function handleSaveQuickSession(e) {
  e.preventDefault();
  const type = document.getElementById("quickSessionType").value.trim() || "Treino Rápido";
  const mins = parseInt(document.getElementById("quickSessionDuration").value, 10) || 45;

  addTrainingMinutes(mins, type);
  closeQuickSessionModal();
  sfx.playCheck();
  alert(`Treino de ${mins} min registrado! Pontos atualizados.`);
}

// --- PWA INSTALL ENGINE FOR MOBILE ---
let deferredInstallPrompt = null;

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;

  const nativeBox = document.getElementById('nativeInstallBox');
  if (nativeBox) nativeBox.style.display = 'block';

  const banner = document.getElementById('installAppBanner');
  if (banner) banner.style.display = 'flex';
});

window.addEventListener('appinstalled', () => {
  deferredInstallPrompt = null;
  const banner = document.getElementById('installAppBanner');
  if (banner) banner.style.display = 'none';
  const headerBtn = document.getElementById('headerInstallBtn');
  if (headerBtn) headerBtn.style.display = 'none';
  triggerHaptic('levelup');
  sfx.playLevelUp();
  alert('🎉 IronLevel instalado com sucesso no seu celular!');
});

function openInstallModal() {
  triggerHaptic('light');
  document.getElementById('installModal').classList.add('open');
}

function closeInstallModal() {
  triggerHaptic('light');
  document.getElementById('installModal').classList.remove('open');
}

async function triggerPwaInstall() {
  triggerHaptic('medium');
  if (deferredInstallPrompt) {
    deferredInstallPrompt.prompt();
    const { outcome } = await deferredInstallPrompt.userChoice;
    if (outcome === 'accepted') {
      deferredInstallPrompt = null;
      closeInstallModal();
    }
  } else {
    openInstallModal();
  }
}

function checkStandaloneMode() {
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  if (isStandalone) {
    const banner = document.getElementById('installAppBanner');
    if (banner) banner.style.display = 'none';
    const headerBtn = document.getElementById('headerInstallBtn');
    if (headerBtn) headerBtn.style.display = 'none';
  }
}

// --- AUTO-UPDATE & OPTIMIZATION ENGINE (Executa automaticamente a cada 2 minutos) ---
const AUTO_UPDATE_INTERVAL_MS = 2 * 60 * 1000; // 2 minutos (120 segundos)
let lastAutoOptimizedAt = Date.now();

async function runAutoOptimizationAndCheck() {
  try {
    // 1. Aciona checagem de nova versão no Service Worker
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg) {
        await reg.update();
      }
    }

    // 2. Verifica se uma versão mais recente foi enviada para o GitHub
    const checkRes = await fetch('./sw.js?check=' + Date.now(), { cache: 'no-store' });
    if (checkRes.ok) {
      const swCode = await checkRes.text();
      const match = swCode.match(/CACHE_NAME\s*=\s*['"]([^'"]+)['"]/);
      if (match && match[1]) {
        const remoteVersion = match[1];
        const localVersion = localStorage.getItem('ironlevel_cache_ver') || 'ironlevel-v6';

        if (remoteVersion !== localVersion) {
          console.log(`[Auto-Update] Nova versão detectada (${remoteVersion}). Atualizando em segundo plano...`);
          localStorage.setItem('ironlevel_cache_ver', remoteVersion);

          // Limpa caches obsoletos para liberar memória e manter o celular otimizado
          if ('caches' in window) {
            const keys = await caches.keys();
            await Promise.all(keys.filter(k => k !== remoteVersion).map(k => caches.delete(k)));
          }
        }
      }
    }

    // 3. Otimização de memória e estado (salva integridade e limpa lixo)
    if (typeof saveState === 'function') {
      saveState();
    }
    lastAutoOptimizedAt = Date.now();
    console.log('[IronLevel] Otimização periódica de 2 minutos concluída com sucesso.');
  } catch (err) {
    // Falha silenciosa caso o aparelho esteja temporariamente offline
    console.log('[Auto-Update] Verificação em background silenciosa:', err);
  }
}

function startAutoUpdateEngine() {
  // Primeira checagem após 10 segundos da inicialização
  setTimeout(runAutoOptimizationAndCheck, 10000);
  // Checagem contínua estritamente a cada 2 minutos
  setInterval(runAutoOptimizationAndCheck, AUTO_UPDATE_INTERVAL_MS);

  // GESTÃO DE CICLO DE VIDA DO DISPOSITIVO (TELA BLOQUEADA / DESBLOQUEADA)
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      // 1. Ressincroniza todos os cronômetros na hora com o relógio do sistema (Date.now())
      syncAllTimersWithWallClock();
      // 2. Se o descanso acabou durante o bloqueio da tela, dispara o alarme
      checkExpiredRestTimer();
      // 3. Se algum treino está ativo, reativa o Screen Wake Lock
      if (timerRunning || gpsTracking || ropeActive) {
        requestScreenWakeLock();
      }
      const elapsed = Date.now() - lastAutoOptimizedAt;
      if (elapsed >= AUTO_UPDATE_INTERVAL_MS) {
        runAutoOptimizationAndCheck();
      }
    } else {
      // Tela bloqueada ou aba minimizada: salva o estado exato dos cronômetros
      saveActiveWorkoutTimerSession();
      saveActiveGpsSession();
      saveActiveRopeSession();
    }
  });

  window.addEventListener('pageshow', () => {
    syncAllTimersWithWallClock();
    checkExpiredRestTimer();
  });

  window.addEventListener('focus', () => {
    syncAllTimersWithWallClock();
    checkExpiredRestTimer();
    if (timerRunning || gpsTracking || ropeActive) {
      requestScreenWakeLock();
    }
  });
}

// --- THEME PICKER & LIVE PREVIEW ---
function applyTheme(themeName) {
  STATE.user.theme = themeName || 'green';
  document.body.dataset.theme = (themeName === 'green' || !themeName) ? '' : themeName;

  const themeIds = ['green', 'orange', 'purple', 'red', 'blue', 'gold', 'shadow'];
  themeIds.forEach(t => {
    const card = document.getElementById(`theme-card-${t}`);
    if (card) {
      if (t === (themeName || 'green')) {
        card.classList.add('active');
      } else {
        card.classList.remove('active');
      }
    }
  });

  saveState();
}

function openThemeModal() {
  triggerHaptic('light');
  // Define o novo tema Fogo Azul & Preto (Solo Leveling) como padrão
  if (!STATE.user.theme || STATE.user.theme === 'green') {
    STATE.user.theme = 'shadow';
  }
  applyTheme(STATE.user.theme);
  document.getElementById('themeModal').classList.add('open');
}

function closeThemeModal() {
  triggerHaptic('medium');
  document.getElementById('themeModal').classList.remove('open');
}

function previewAndSelectTheme(themeName) {
  triggerHaptic('success');
  applyTheme(themeName);
}

// --- ABOUT MODAL ---
function openAboutModal() {
  document.getElementById("aboutModal").classList.add("open");
}

function closeAboutModal() {
  document.getElementById("aboutModal").classList.remove("open");
}

// --- PROFILE PHOTO & MODAL LOGIC ---
let tempProfilePhoto = null;
let cachedUserPhotoImg = null;

function updateCachedUserPhoto() {
  if (STATE.user && STATE.user.photo) {
    cachedUserPhotoImg = new Image();
    cachedUserPhotoImg.src = STATE.user.photo;
  } else {
    cachedUserPhotoImg = null;
  }
}

function triggerProfilePhotoInput() {
  triggerHaptic('light');
  const input = document.getElementById('profilePhotoInput');
  if (input) input.click();
}

function updateModalAvatarLetter() {
  const nameInput = document.getElementById("profileNameInput");
  const letterEl = document.getElementById("modalAvatarLetter");
  if (letterEl && !tempProfilePhoto) {
    const letter = (nameInput.value.trim().charAt(0) || "G").toUpperCase();
    letterEl.innerText = letter;
  }
}

function handlePhotoSelected(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;

  if (!file.type.startsWith('image/')) {
    alert("Por favor, selecione um arquivo de imagem válido.");
    return;
  }

  const reader = new FileReader();
  reader.onload = function(e) {
    const img = new Image();
    img.onload = function() {
      // Redimensiona para max 256x256 mantendo qualidade e economizando espaço no navegador
      const maxDim = 256;
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        }
      } else {
        if (height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, width, height);

      tempProfilePhoto = canvas.toDataURL('image/jpeg', 0.85);
      renderModalAvatarPreview();
      triggerHaptic('success');
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

function removeProfilePhoto() {
  triggerHaptic('light');
  tempProfilePhoto = null;
  const input = document.getElementById('profilePhotoInput');
  if (input) input.value = '';
  renderModalAvatarPreview();
}

function renderModalAvatarPreview() {
  const preview = document.getElementById('modalAvatarPreview');
  const removeBtn = document.getElementById('btnRemovePhoto');
  const nameInput = document.getElementById("profileNameInput");
  const currentLetter = (nameInput ? nameInput.value.trim().charAt(0) || "G" : "G").toUpperCase();

  if (tempProfilePhoto) {
    preview.innerHTML = `<img src="${tempProfilePhoto}" alt="Foto de perfil">`;
    if (removeBtn) removeBtn.style.display = 'inline-flex';
  } else {
    preview.innerHTML = `<span id="modalAvatarLetter">${currentLetter}</span>`;
    if (removeBtn) removeBtn.style.display = 'none';
  }
}

function openProfileModal() {
  triggerHaptic('light');
  tempProfilePhoto = STATE.user.photo || null;
  document.getElementById("profileNameInput").value = STATE.user.name || "";
  document.getElementById("profileGoalInput").value = STATE.user.goal || "Hipertrofia";
  
  const ageInput = document.getElementById("profileAgeInput");
  if (ageInput) ageInput.value = STATE.user.age || "";

  const countryInput = document.getElementById("profileCountryInput");
  if (countryInput && STATE.user.country) {
    for (let i = 0; i < countryInput.options.length; i++) {
      if (countryInput.options[i].value.startsWith(STATE.user.country)) {
        countryInput.selectedIndex = i;
        break;
      }
    }
  }

  const memberText = document.getElementById("profileMemberText");
  if (memberText) {
    const num = STATE.user.memberNumber || getCommunityUsersCount();
    memberText.innerText = `Guerreiro Oficial #${num.toLocaleString('pt-BR')} no App`;
  }

  renderModalAvatarPreview();
  document.getElementById("profileModal").classList.add("open");
}

function closeProfileModal() {
  triggerHaptic('light');
  tempProfilePhoto = null;
  document.getElementById("profileModal").classList.remove("open");
}

function handleSaveProfile(e) {
  e.preventDefault();
  const name = document.getElementById("profileNameInput").value.trim() || "Guerreiro";
  const goal = document.getElementById("profileGoalInput").value;
  const ageInput = document.getElementById("profileAgeInput");
  const age = ageInput ? parseInt(ageInput.value, 10) : null;
  
  const countryInput = document.getElementById("profileCountryInput");
  let countryName = STATE.user.country || "Brasil";
  let countryFlag = STATE.user.countryFlag || "🇧🇷";
  if (countryInput && countryInput.value) {
    const parts = countryInput.value.split("|");
    countryName = parts[0] || countryName;
    countryFlag = parts[1] || countryFlag;
  }

  STATE.user.name = name;
  STATE.user.goal = goal;
  if (age) STATE.user.age = age;
  STATE.user.country = countryName;
  STATE.user.countryFlag = countryFlag;
  STATE.user.avatar = name.charAt(0).toUpperCase();
  STATE.user.photo = tempProfilePhoto;
  STATE.user.registered = true;
  if (!STATE.user.memberNumber) {
    let cur = getCommunityUsersCount();
    cur++;
    localStorage.setItem('ironlevel_community_users_count', cur);
    STATE.user.memberNumber = cur;
  }

  updateCachedUserPhoto();
  saveState();
  closeProfileModal();
  triggerHaptic('success');
  sfx.playCheck();
  renderAll();
  updateAllCommunityCounters();
}

// --- LEVEL UP CELEBRATION MODAL & CONFETTI ---
function triggerLevelUpModal(levelObj) {
  sfx.playLevelUp();
  const iconEl = document.getElementById("levelUpIcon");
  if (iconEl) {
    iconEl.innerHTML = `<div style="display:flex; justify-content:center; margin-bottom: 12px;">${getRankBadgeHtml(levelObj.rankTier, levelObj.rankTier === 'SS')}</div>`;
  }
  document.getElementById("levelUpTitle").innerText = `RANK ${levelObj.rankTier}: ${levelObj.name.toUpperCase()}`;
  document.getElementById("levelUpDesc").innerText = `Você atingiu ${STATE.totalPoints.toFixed(1)} pontos (${Math.floor(STATE.totalMinutes/60)}h ${STATE.totalMinutes%60}m acumulados)! Rank de Herói: ${levelObj.rank}`;
  document.getElementById("levelUpModal").classList.add("open");
  launchConfetti();
}

function closeLevelUpModal() {
  document.getElementById("levelUpModal").classList.remove("open");
}

// Simple Canvas Confetti
function launchConfetti() {
  const canvas = document.getElementById("confettiCanvas");
  const ctx = canvas.getContext("2d");
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  const particles = [];
  const colors = ["#10b981", "#f59e0b", "#3b82f6", "#ef4444", "#8b5cf6", "#fbbf24"];

  for (let i = 0; i < 90; i++) {
    particles.push({
      x: canvas.width / 2,
      y: canvas.height / 2,
      vx: (Math.random() - 0.5) * 16,
      vy: (Math.random() - 0.8) * 16,
      color: colors[Math.floor(Math.random() * colors.length)],
      size: Math.random() * 8 + 4,
      rotation: Math.random() * 360,
      rotSpeed: (Math.random() - 0.5) * 10
    });
  }

  let frames = 0;
  function updateConfetti() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.35; // Gravity
      p.rotation += p.rotSpeed;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate((p.rotation * Math.PI) / 180);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
      ctx.restore();
    });

    frames++;
    if (frames < 120) {
      requestAnimationFrame(updateConfetti);
    } else {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  }
  updateConfetti();
}

// --- TAB SWITCHING ---
function switchTab(tabId) {
  try { sfx.init(); } catch (e) {}
  try { triggerHaptic('light'); } catch (e) {}

  const tabs = ['home', 'workout', 'running', 'levels', 'share'];
  tabs.forEach(t => {
    const el = document.getElementById(`tab-${t}`);
    const navBtn = document.getElementById(`nav-${t}`);
    if (el) {
      el.classList.remove('active');
      el.style.display = 'none';
    }
    if (navBtn) navBtn.classList.remove('active');
  });

  const activeEl = document.getElementById(`tab-${tabId}`);
  const activeNav = document.getElementById(`nav-${tabId}`);
  if (activeEl) {
    activeEl.classList.add('active');
    activeEl.style.display = 'block';
  }
  if (activeNav) activeNav.classList.add('active');

  window.scrollTo({ top: 0, behavior: 'smooth' });

  try {
    if (tabId === 'home') renderHomeTab();
    if (tabId === 'workout') renderWorkoutTab();
    if (tabId === 'running') {
      renderRunningTab();
      if (typeof currentRunSubtab !== 'undefined' && currentRunSubtab === 'gps') {
        setTimeout(initRunMapIfNeeded, 150);
      }
    }
    if (tabId === 'levels') renderLevelsTab();
    if (tabId === 'share') renderShareTab();
  } catch (err) {
    console.error(`Erro ao renderizar aba ${tabId}:`, err);
  }
}

// --- RENDER FUNCTIONS ---
function renderHeader() {
  const avatarEl = document.getElementById("headerAvatar");
  if (STATE.user && STATE.user.photo) {
    avatarEl.innerHTML = `<img src="${STATE.user.photo}" alt="${STATE.user.name}">`;
  } else {
    avatarEl.innerHTML = (STATE.user && STATE.user.avatar) ? STATE.user.avatar : "G";
  }
  const currentLevelObjHeader = getLevelForPoints(STATE.totalPoints);
  const flag = (STATE.user && STATE.user.countryFlag) ? `<span style="margin-right: 4px;">${STATE.user.countryFlag}</span>` : '';
  const userNameEl = document.getElementById("headerUserName");
  if (userNameEl) {
    userNameEl.innerHTML = `${flag}${STATE.user.name} <span class="level-tag" id="headerLevelTag">RANK ${currentLevelObjHeader.rankTier || 'E'} • NV ${STATE.currentLevel}</span>`;
  }
  const streakEl = document.getElementById("headerStreakCount");
  if (streakEl) streakEl.innerText = STATE.streakDays || 1;
  updateAllCommunityCounters();
}

function renderHomeTab() {
  renderHeader();
  document.getElementById("todayDateStr").innerText = getFormattedDayMonth();

  const currentLevelObj = getLevelForPoints(STATE.totalPoints);
  const nextLevelObj = LEVELS.find(l => l.level === currentLevelObj.level + 1) || currentLevelObj;

  // Level Hero
  const heroBadgeEl = document.getElementById("heroLevelBadge");
  if (heroBadgeEl) {
    heroBadgeEl.innerText = currentLevelObj.rankTier || "E";
    heroBadgeEl.className = `level-icon-badge rank-${(currentLevelObj.rankTier || 'E').toLowerCase().replace('+', '-plus')}`;
  }
  document.getElementById("heroLevelName").innerText = `Rank ${currentLevelObj.rankTier} • ${currentLevelObj.name}`;
  document.getElementById("heroLevelRank").innerText = currentLevelObj.rank;

  // Progress Bar
  const range = nextLevelObj.minPoints - currentLevelObj.minPoints;
  const currentInTier = STATE.totalPoints - currentLevelObj.minPoints;
  const pct = range > 0 ? Math.min(100, Math.max(5, (currentInTier / range) * 100)) : 100;
  document.getElementById("heroLevelProgressBar").style.width = `${pct}%`;

  document.getElementById("heroCurrentPoints").innerText = `${STATE.totalPoints.toFixed(2)} Pontos`;
  document.getElementById("heroNextLevelPoints").innerText = nextLevelObj.level > currentLevelObj.level 
    ? `Próx: Rank ${nextLevelObj.rankTier} (${nextLevelObj.minPoints} pts)` 
    : "Rank Supremo Alcançado! ⚡";

  const totalHours = Math.floor(STATE.totalMinutes / 60);
  const totalRemainMins = STATE.totalMinutes % 60;
  document.getElementById("heroTotalHoursDisplay").innerText = `${totalHours}h ${totalRemainMins}m`;

  // Hours until next point:
  const minsInCurrentPoint = STATE.totalMinutes % 120;
  const minsToNextPt = 120 - minsInCurrentPoint;
  const hToNext = Math.floor(minsToNextPt / 60);
  const mToNext = minsToNextPt % 60;
  document.getElementById("hoursToNextPt").innerText = `${hToNext}h ${String(mToNext).padStart(2, '0')}m`;

  // Alerta de Missão Surpresa Semanal
  renderSurpriseMissionCard();

  // Daily Challenge Card
  document.getElementById("challengeTitle").innerText = STATE.dailyChallenge.title;
  const todayTotalMin = STATE.todaySessions.reduce((acc, s) => acc + s.durationMin, 0);
  const chPct = Math.min(100, Math.round((todayTotalMin / STATE.dailyChallenge.targetMinutes) * 100));
  document.getElementById("challengeProgressBar").style.width = `${chPct}%`;
  document.getElementById("challengeProgressText").innerText = `${todayTotalMin} / ${STATE.dailyChallenge.targetMinutes} min concluídos`;

  const statusBadge = document.getElementById("challengeStatusBadge");
  const btnCh = document.getElementById("btnCompleteChallenge");
  if (STATE.dailyChallenge.completed || todayTotalMin >= STATE.dailyChallenge.targetMinutes) {
    statusBadge.innerText = "Concluído! 🏆";
    statusBadge.style.color = "var(--accent-green)";
    btnCh.innerText = "Concluído ✔";
    btnCh.style.background = "var(--accent-green)";
  } else {
    statusBadge.innerText = "Em Andamento";
    statusBadge.style.color = "var(--accent-orange)";
    btnCh.innerText = "Concluir";
    btnCh.style.background = "var(--accent-orange)";
  }

  // Today Stats Grid
  const sessionCount = STATE.todaySessions.length;
  document.getElementById("todaySessionsCount").innerText = sessionCount;
  document.getElementById("todaySessionsDesc").innerText = sessionCount === 1 ? "1 sessão registrada" : `${sessionCount} sessões hoje`;

  document.getElementById("todayDurationTotal").innerText = `${todayTotalMin} min`;
  const todayPts = (todayTotalMin / 120).toFixed(2);
  document.getElementById("todayPointsGained").innerText = todayPts;

  const todayKm = STATE.todayRuns.reduce((acc, r) => acc + r.km, 0);
  const todayRunMin = STATE.todayRuns.reduce((acc, r) => acc + r.minutes, 0);
  document.getElementById("todayKmTotal").innerText = `${todayKm.toFixed(1)} km`;
  document.getElementById("todayRunTime").innerText = `${todayRunMin} min cardio`;

  document.getElementById("totalPointsSummary").innerText = STATE.totalPoints.toFixed(2);

  // Today Sessions List
  const sessionsListEl = document.getElementById("todaySessionsList");
  document.getElementById("todaySessionsBadge").innerText = `${sessionCount} sessões`;
  if (sessionCount === 0) {
    sessionsListEl.innerHTML = `
      <p style="color: var(--text-muted); font-size: 0.8rem; text-align: center; padding: 12px 0;">
        Você ainda não registrou nenhum treino hoje. Bora treinar! 💪
      </p>
    `;
  } else {
    sessionsListEl.innerHTML = STATE.todaySessions.map((s, idx) => `
      <div class="session-item">
        <div>
          <span style="font-weight: 700; color: #fff;">Sessão #${idx + 1}: ${s.type}</span>
          <div style="font-size: 0.72rem; color: var(--text-muted);">
            Registrado às ${s.timeStr} • Duração: <strong>${s.durationMin} min</strong>
          </div>
        </div>
        <span class="session-badge">+${s.pointsEarned} pt</span>
      </div>
    `).join('');
  }
}

// --- WORKOUT SUBTABS: ROUTINE vs MUSCLE GUIDE ---
let currentWorkoutSubtab = 'routine';
let currentGuideMuscle = 'all';

function switchWorkoutSubtab(subtab) {
  try { sfx.init(); } catch (e) {}
  try { triggerHaptic('light'); } catch (e) {}
  currentWorkoutSubtab = subtab;

  const btnRoutine = document.getElementById("btnSubWorkoutRoutine");
  const btnGuide = document.getElementById("btnSubWorkoutGuide");
  const viewRoutine = document.getElementById("viewWorkoutRoutine");
  const viewGuide = document.getElementById("viewWorkoutGuide");

  if (btnRoutine) btnRoutine.classList.toggle("active", subtab === 'routine');
  if (btnGuide) btnGuide.classList.toggle("active", subtab === 'guide');

  if (viewRoutine) viewRoutine.style.display = (subtab === 'routine') ? 'block' : 'none';
  if (viewGuide) viewGuide.style.display = (subtab === 'guide') ? 'block' : 'none';

  if (subtab === 'routine') {
    renderWorkoutRoutineView();
  } else {
    renderWorkoutGuideView();
  }
}

// --- DETECT MUSCLE FOR EXERCISE ---
function detectMuscleForExercise(name, notes) {
  const str = ((name || '') + ' ' + (notes || '')).toLowerCase();
  if (str.match(/supino|crucifixo|peito|peitoral|flex[ãa]o|crossover|voador|peck deck/)) return 'peito';
  if (str.match(/puxada|remada|barra fixa|pulldown|costas|dorsal|lombar|serrote/)) return 'costas';
  if (str.match(/agachamento|leg press|extensora|hack|afundo|passada|quadr[íi]ceps/)) return 'pernas';
  if (str.match(/flexora|stiff|posterior|isquiotibiais|pelvica|p[ée]lvica|gl[úu]teo|abdutora|adutora/)) return 'posterior';
  if (str.match(/desenvolvimento|lateral|frontal|ombro|deltoide|face pull|manguito/)) return 'ombros';
  if (str.match(/rosca|b[íi]ceps|antebra[çc]o|martelo|scott/)) return 'biceps';
  if (str.match(/tr[íi]ceps|franc[êe]s|corda|testa|mergulho|coice/)) return 'triceps';
  if (str.match(/abdominal|prancha|infra|supra|obl[íi]quo|abd[ôo]men/)) return 'abdomen';
  if (str.match(/panturrilha|g[êe]meos|s[óo]leo/)) return 'panturrilha';
  if (str.match(/trap[ée]zio|encolhimento/)) return 'trapezio';
  return 'peito';
}

function getMuscleTargetName(muscleKey) {
  const map = {
    peito: 'Peitoral (Maior & Superior)',
    costas: 'Dorsais & Costas',
    trapezio: 'Trapézio Superior',
    ombros: 'Deltoides (Ombros)',
    biceps: 'Bíceps Braquial',
    triceps: 'Tríceps (3 Cabeças)',
    pernas: 'Quadríceps (Coxas)',
    posterior: 'Posterior de Coxa & Glúteos',
    abdomen: 'Reto Abdominal & Core',
    panturrilha: 'Panturrilhas (Gêmeos)'
  };
  return map[muscleKey] || 'Músculo Alvo';
}

// --- SVG ANATOMICAL THUMBNAIL RENDERER (COMO NA FOTO DO HEVY / APP) ---
function renderMuscleThumbnailSvg(muscle) {
  const m = (muscle || 'peito').toLowerCase();
  const isBack = ['costas', 'triceps', 'posterior', 'trapezio', 'panturrilha'].includes(m);
  const red = '#ef4444';
  const body = '#64748b';
  const glow = 'drop-shadow(0 0 3px rgba(239,68,68,0.85))';

  if (!isBack) {
    // VISÃO ANTERIOR (FRENTE)
    const isPec = m === 'peito';
    const isDelt = m === 'ombros';
    const isBic = m === 'biceps';
    const isAbs = m === 'abdomen';
    const isQuad = m === 'pernas';

    return `
      <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="8" r="4.5" fill="${body}"/>
        <rect x="30" y="12.5" width="4" height="3" rx="1" fill="${body}"/>
        <path d="M19 16 C17 17 16 21 18 24 C19 23 21 20 22 17 Z" fill="${isDelt ? red : body}" style="${isDelt ? `filter:${glow};` : ''}"/>
        <path d="M45 16 C47 17 48 21 46 24 C45 23 43 20 42 17 Z" fill="${isDelt ? red : body}" style="${isDelt ? `filter:${glow};` : ''}"/>
        <path d="M23 16.5 C27 16.5 31 17.5 31 23 C26 24 22 23 22 18.5 Z" fill="${isPec ? red : body}" style="${isPec ? `filter:${glow};` : ''}"/>
        <path d="M41 16.5 C37 16.5 33 17.5 33 23 C38 24 42 23 42 18.5 Z" fill="${isPec ? red : body}" style="${isPec ? `filter:${glow};` : ''}"/>
        <path d="M17 24 C15 26 16 30 18 32 C19 30 20 27 19 24 Z" fill="${isBic ? red : body}" style="${isBic ? `filter:${glow};` : ''}"/>
        <path d="M47 24 C49 26 48 30 46 32 C45 30 44 27 45 24 Z" fill="${isBic ? red : body}" style="${isBic ? `filter:${glow};` : ''}"/>
        <path d="M18 32 L15 39 C15 40 16 40 17 39 L19 33 Z" fill="${body}"/>
        <path d="M46 32 L49 39 C49 40 48 40 47 39 L45 33 Z" fill="${body}"/>
        <g fill="${isAbs ? red : body}" style="${isAbs ? `filter:${glow};` : ''}">
          <rect x="28" y="24" width="3.5" height="3" rx="0.5"/>
          <rect x="32.5" y="24" width="3.5" height="3" rx="0.5"/>
          <rect x="28" y="28" width="3.5" height="3" rx="0.5"/>
          <rect x="32.5" y="28" width="3.5" height="3" rx="0.5"/>
          <rect x="28.5" y="32" width="3" height="3" rx="0.5"/>
          <rect x="32.5" y="32" width="3" height="3" rx="0.5"/>
        </g>
        <path d="M26 36 L38 36 L37 39 L27 39 Z" fill="${body}"/>
        <path d="M25 39 C23 43 24 50 28 51 C30 47 31 43 31 39 Z" fill="${isQuad ? red : body}" style="${isQuad ? `filter:${glow};` : ''}"/>
        <path d="M39 39 C41 43 40 50 36 51 C34 47 33 43 33 39 Z" fill="${isQuad ? red : body}" style="${isQuad ? `filter:${glow};` : ''}"/>
        <path d="M26 52 L30 52 L29 61 L27 61 Z" fill="${body}"/>
        <path d="M38 52 L34 52 L35 61 L37 61 Z" fill="${body}"/>
      </svg>
    `;
  } else {
    // VISÃO POSTERIOR (COSTAS)
    const isBackMuscles = m === 'costas' || m === 'trapezio';
    const isTri = m === 'triceps';
    const isHam = m === 'posterior';
    const isCalf = m === 'panturrilha';

    return `
      <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="32" cy="8" r="4.5" fill="${body}"/>
        <path d="M25 14 L39 14 L41 19 L32 23 L23 19 Z" fill="${isBackMuscles ? red : body}" style="${isBackMuscles ? `filter:${glow};` : ''}"/>
        <path d="M23 19 C26 22 29 23 29 32 C25 30 22 26 22 20 Z" fill="${isBackMuscles ? red : body}" style="${isBackMuscles ? `filter:${glow};` : ''}"/>
        <path d="M41 19 C38 22 35 23 35 32 C39 30 42 26 42 20 Z" fill="${isBackMuscles ? red : body}" style="${isBackMuscles ? `filter:${glow};` : ''}"/>
        <path d="M18 20 C16 23 16 28 18 31 C19 28 20 24 19 20 Z" fill="${isTri ? red : body}" style="${isTri ? `filter:${glow};` : ''}"/>
        <path d="M46 20 C48 23 48 28 46 31 C45 28 44 24 45 20 Z" fill="${isTri ? red : body}" style="${isTri ? `filter:${glow};` : ''}"/>
        <path d="M17 31 L15 39 C15 40 16 40 17 39 L19 32 Z" fill="${body}"/>
        <path d="M47 31 L49 39 C49 40 48 40 47 39 L45 32 Z" fill="${body}"/>
        <path d="M24 34 C23 39 31 39 31 34 Z" fill="${isHam ? red : body}" style="${isHam ? `filter:${glow};` : ''}"/>
        <path d="M40 34 C41 39 33 39 33 34 Z" fill="${isHam ? red : body}" style="${isHam ? `filter:${glow};` : ''}"/>
        <path d="M25 39 C23 43 24 50 28 51 C30 47 31 43 31 39 Z" fill="${isHam ? red : body}" style="${isHam ? `filter:${glow};` : ''}"/>
        <path d="M39 39 C41 43 40 50 36 51 C34 47 33 43 33 39 Z" fill="${isHam ? red : body}" style="${isHam ? `filter:${glow};` : ''}"/>
        <path d="M25 52 C23 55 24 59 28 60 C29 58 30 55 29 52 Z" fill="${isCalf ? red : body}" style="${isCalf ? `filter:${glow};` : ''}"/>
        <path d="M39 52 C41 55 40 59 36 60 C35 58 34 55 35 52 Z" fill="${isCalf ? red : body}" style="${isCalf ? `filter:${glow};` : ''}"/>
      </svg>
    `;
  }
}

// --- RENDER WORKOUT TAB ---
function renderWorkoutTab() {
  if (currentWorkoutSubtab === 'guide') {
    renderWorkoutGuideView();
  } else {
    renderWorkoutRoutineView();
  }
}

// Alternar Bi-Set em um exercício
function toggleExerciseBiSet(id) {
  triggerHaptic('light');
  const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
  const routine = STATE.routines[currentDay];
  if (!routine || !routine.exercises) return;
  const ex = routine.exercises.find(e => e.id === id);
  if (ex) {
    ex.isBiSet = !ex.isBiSet;
    saveState();
    renderWorkoutRoutineView();
  }
}

// Adicionar nova divisão (ex: Treino D, E, F...)
function addNewWorkoutDivision() {
  triggerHaptic('medium');
  const letters = ["A", "B", "C", "D", "E", "F", "G", "H", "I"];
  const totalRoutines = Object.keys(STATE.routines || {}).length;
  const nextLetter = letters[totalRoutines] || `Divisão ${totalRoutines + 1}`;

  const title = prompt(`Nome da nova divisão (ex: Treino ${nextLetter} - Foco Bíceps):`, `Treino ${nextLetter}`);
  if (title && title.trim()) {
    const newIdx = totalRoutines;
    STATE.routines[newIdx] = {
      dayName: `Divisão ${nextLetter}`,
      title: title.trim(),
      exercises: []
    };
    STATE.activeDayIndex = newIdx;
    saveState();
    renderWorkoutRoutineView();
  }
}

// --- ENSURE EXERCISE HAS STRUCTURED SERIES (ESTILO METAFIT) ---
function ensureExerciseSeries(ex) {
  if (!ex.series || !Array.isArray(ex.series) || ex.series.length === 0) {
    const numSets = parseInt(ex.sets) || 3;
    const defaultReps = parseInt(ex.reps) || 12;
    const defaultWeight = parseFloat(ex.weight) || 0;
    ex.series = [];
    for (let i = 1; i <= numSets; i++) {
      ex.series.push({
        setNum: i,
        weight: defaultWeight,
        reps: defaultReps,
        prevWeight: defaultWeight,
        prevReps: defaultReps,
        prevRest: ex.rest || 60,
        done: !!ex.done
      });
    }
  }
  return ex.series;
}

// Alternar Expandir/Recolher card do exercício
function toggleExerciseExpand(exId) {
  triggerHaptic('light');
  const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
  const routine = STATE.routines[currentDay];
  if (!routine || !routine.exercises) return;
  const ex = routine.exercises.find(e => e.id === exId);
  if (ex) {
    ex.isExpanded = (ex.isExpanded === false) ? true : false;
    saveState();
    renderWorkoutRoutineView();
  }
}

// Concluir/Desmarcar série individual (SET-BY-SET TRACKING)
function toggleSetDone(exId, setNum) {
  try {
    const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
    const routine = STATE.routines[currentDay];
    if (!routine || !routine.exercises) return;
    const ex = routine.exercises.find(e => e.id === exId);
    if (!ex) return;
    ensureExerciseSeries(ex);

    const s = ex.series.find(item => item.setNum === setNum);
    if (!s) return;

    s.done = !s.done;

    if (s.done) {
      try {
        if (typeof sfx !== 'undefined' && typeof sfx.playCheck === 'function') {
          sfx.playCheck();
        }
      } catch (e) {}
      triggerHaptic('success');
      s.prevWeight = s.weight;
      s.prevReps = s.reps;

      // Dispara descanso automático configurado no exercício
      startRestTimer(ex.rest || 60);

      // Se o cronômetro do treino ainda não estiver rodando, inicia
      if (!timerRunning) {
        toggleWorkoutTimer();
      }
    } else {
      triggerHaptic('light');
    }

    // Se todas as séries estiverem feitas, marca o exercício como concluído
    ex.done = ex.series.every(item => item.done);

    saveState();
    renderWorkoutRoutineView();
    updateActiveWorkoutBottomBar();
  } catch (err) {
    console.error("Erro ao marcar série:", err);
  }
}

// Concluir/Desmarcar todas as séries de um exercício de uma vez só
function toggleAllExerciseSetsDone(exId) {
  try {
    const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
    const routine = STATE.routines[currentDay];
    if (!routine || !routine.exercises) return;
    const ex = routine.exercises.find(e => e.id === exId);
    if (!ex) return;
    ensureExerciseSeries(ex);

    const areAllDone = ex.series.every(s => s.done);
    const targetState = !areAllDone;

    ex.series.forEach(s => {
      s.done = targetState;
      if (targetState) {
        s.prevWeight = s.weight;
        s.prevReps = s.reps;
      }
    });
    ex.done = targetState;

    if (targetState) {
      try {
        if (typeof sfx !== 'undefined' && typeof sfx.playCheck === 'function') {
          sfx.playCheck();
        }
      } catch (e) {}
      triggerHaptic('success');
      startRestTimer(ex.rest || 60);
      if (!timerRunning) {
        toggleWorkoutTimer();
      }
    } else {
      triggerHaptic('light');
    }

    saveState();
    renderWorkoutRoutineView();
    updateActiveWorkoutBottomBar();
  } catch (err) {
    console.error("Erro ao alternar todas as séries:", err);
  }
}

// Atualizar valor de Carga (kg) ou Reps de uma série
function updateSetData(exId, setNum, field, val) {
  const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
  const routine = STATE.routines[currentDay];
  if (!routine || !routine.exercises) return;
  const ex = routine.exercises.find(e => e.id === exId);
  if (!ex) return;
  ensureExerciseSeries(ex);

  const s = ex.series.find(item => item.setNum === setNum);
  if (!s) return;

  if (field === 'weight') {
    s.weight = parseFloat(val) || 0;
    ex.weight = s.weight;
  } else if (field === 'reps') {
    s.reps = parseInt(val) || 0;
  }
  saveState();
  updateActiveWorkoutBottomBar();
}

// Adicionar mais uma série ao exercício (+ adicionar série)
function addExerciseSet(exId) {
  triggerHaptic('medium');
  const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
  const routine = STATE.routines[currentDay];
  if (!routine || !routine.exercises) return;
  const ex = routine.exercises.find(e => e.id === exId);
  if (!ex) return;
  ensureExerciseSeries(ex);

  const nextNum = ex.series.length + 1;
  const lastSet = ex.series[ex.series.length - 1] || { weight: ex.weight || 0, reps: 12, prevRest: ex.rest || 60 };

  ex.series.push({
    setNum: nextNum,
    weight: lastSet.weight,
    reps: lastSet.reps,
    prevWeight: lastSet.weight,
    prevReps: lastSet.reps,
    prevRest: ex.rest || 60,
    done: false
  });
  ex.sets = ex.series.length;
  ex.isExpanded = true;

  saveState();
  renderWorkoutRoutineView();
  updateActiveWorkoutBottomBar();
}

// INICIAR TREINO (Acompanha o treino sem complicação, sem filmar nada)
function startWorkoutSessionPro(triggerVib = true) {
  if (triggerVib) {
    sfx.playLevelUp();
    triggerHaptic('heavy');
  }
  if (!timerRunning) {
    toggleWorkoutTimer();
  }

  // Garante que todos os exercícios do treino fiquem abertos prontos para anotar as séries
  const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
  const routine = STATE.routines[currentDay];
  if (routine && routine.exercises) {
    routine.exercises.forEach(e => {
      ensureExerciseSeries(e);
      e.isExpanded = true;
    });
    saveState();
  }

  renderWorkoutRoutineView();
  updateActiveWorkoutBottomBar();

  // Scroll suave para o primeiro exercício
  const container = document.getElementById("exerciseListContainer");
  if (container) {
    container.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

// FINALIZAR TREINO PRO
function finishWorkoutSessionPro() {
  timerSeconds = getActualWorkoutSeconds();
  pauseWorkoutTimer();
  releaseScreenWakeLock();

  const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
  const routine = STATE.routines[currentDay];
  const minutes = Math.max(1, Math.round(timerSeconds / 60));

  let totalSeries = 0;
  let completedSeries = 0;
  let totalVolumeKg = 0;

  (routine.exercises || []).forEach(ex => {
    ensureExerciseSeries(ex);
    ex.series.forEach(s => {
      totalSeries++;
      if (s.done) {
        completedSeries++;
        totalVolumeKg += ((s.weight || 0) * (s.reps || 0));
        s.prevWeight = s.weight;
        s.prevReps = s.reps;
      }
      s.done = false;
    });
    ex.done = false;
  });

  const promptMsg = `🏁 Finalizar ${routine.title || 'Treino'}?\n\n` +
    `⏱️ Duração: ${minutes} minutos\n` +
    `💪 Séries Feitas: ${completedSeries} de ${totalSeries}\n` +
    (totalVolumeKg > 0 ? `🏋️ Volume Levantado: ${totalVolumeKg.toLocaleString('pt-BR')} kg\n\n` : '\n') +
    `Registrar e somar pontos de Level Up?`;

  if (confirm(promptMsg)) {
    addTrainingMinutes(minutes, routine.title || "Musculação");
    sfx.playLevelUp();
    resetWorkoutTimer();
    saveState();
    updateActiveWorkoutBottomBar();
    switchTab('home');
  } else {
    toggleWorkoutTimer();
  }
}

// ATUALIZAR BARRA FIXA INFERIOR DO TREINO EM ANDAMENTO
function updateActiveWorkoutBottomBar() {
  const bar = document.getElementById("activeWorkoutBar");
  const footerBtn = document.getElementById("startWorkoutFooter");
  if (!bar) return;

  const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
  const routine = STATE.routines ? STATE.routines[currentDay] : null;
  if (!routine) return;

  let totalSeries = 0;
  let completedSeries = 0;
  (routine.exercises || []).forEach(ex => {
    ensureExerciseSeries(ex);
    ex.series.forEach(s => {
      totalSeries++;
      if (s.done) completedSeries++;
    });
  });

  const pct = totalSeries > 0 ? Math.round((completedSeries / totalSeries) * 100) : 0;

  if (timerRunning) {
    bar.style.display = "flex";
    if (footerBtn) footerBtn.style.display = "none";
  } else {
    bar.style.display = "none";
    if (footerBtn) footerBtn.style.display = "block";
  }

  const titleBadge = document.getElementById("activeWorkoutTitleBadge");
  const timerDisp = document.getElementById("activeWorkoutTimerDisplay");
  const progText = document.getElementById("activeWorkoutProgressText");

  const letters = ["A", "B", "C", "D", "E", "F", "G"];
  const letter = letters[currentDay] || (currentDay + 1);

  if (titleBadge) titleBadge.innerText = `TREINO ${letter} · EM ANDAMENTO`;
  if (timerDisp) timerDisp.innerText = formatSeconds(timerSeconds);
  if (progText) progText.innerText = `${completedSeries}/${totalSeries} SÉRIES · ${pct}%`;
}

// RENDERIZAR CARD INDIVIDUAL METAFIT COM TABELA DE SÉRIES
function renderExerciseCardMetaFit(ex, idx, isInsideBiset) {
  ensureExerciseSeries(ex);
  const muscle = ex.muscle || detectMuscleForExercise(ex.name, ex.notes);
  const targetLabel = getMuscleTargetName(muscle);
  const svgThumb = renderMuscleThumbnailSvg(muscle);
  const isExpanded = (ex.isExpanded !== false);

  const totalSets = ex.series.length;
  const completedSets = ex.series.filter(s => s.done).length;

  const seriesRowsHtml = ex.series.map(s => {
    const isChecked = !!s.done;
    const prevText = (s.prevWeight > 0 || s.prevReps > 0)
      ? `${s.prevWeight}kg × ${s.prevReps} ⏱️ ${s.prevRest || ex.rest || 60}s`
      : `Novo · ${ex.rest || 60}s`;

    return `
      <div class="set-row ${isChecked ? 'set-completed' : ''}">
        <span class="set-num-badge">${s.setNum}</span>
        <span class="set-prev-record" title="Desempenho na última vez">${prevText}</span>
        <div class="set-input-wrap">
          <input type="number" step="0.5" class="set-input-field" value="${s.weight}" 
            oninput="updateSetData('${ex.id}', ${s.setNum}, 'weight', this.value)"
            onchange="updateSetData('${ex.id}', ${s.setNum}, 'weight', this.value)"
            onfocus="this.select()" title="Carga em kg" />
        </div>
        <div class="set-input-wrap wrap-reps">
          <input type="number" class="set-input-field" value="${s.reps}" 
            oninput="updateSetData('${ex.id}', ${s.setNum}, 'reps', this.value)"
            onchange="updateSetData('${ex.id}', ${s.setNum}, 'reps', this.value)"
            onfocus="this.select()" title="Repetições feitas" />
        </div>
        <button type="button" class="btn-set-check ${isChecked ? 'checked' : ''}" 
          onclick="event.stopPropagation(); toggleSetDone('${ex.id}', ${s.setNum})" title="Concluir Série">
          ${isChecked ? '✓' : ''}
        </button>
      </div>
    `;
  }).join('');

  return `
    <div class="exercise-card-metafit ${ex.isBiSet ? 'is-biset' : ''}" id="ex-card-${ex.id}">
      <div class="exercise-metafit-header" onclick="toggleExerciseExpand('${ex.id}')">
        <div style="display: flex; align-items: center; gap: 10px; flex: 1; min-width: 0;">
          <span class="exercise-order-num">${idx + 1}</span>
          <div class="exercise-thumb-mini" title="Foco Anatômico: ${targetLabel}">
            ${svgThumb}
          </div>
          <div style="min-width: 0; flex: 1;">
            <div class="exercise-metafit-title">
              ${ex.name}
              ${ex.isBiSet && !isInsideBiset ? '<span class="badge-biset-tag">BI-SET</span>' : ''}
            </div>
            <div class="exercise-metafit-muscle">
              ${targetLabel} · <strong>${completedSets}/${totalSets}</strong> séries concluídas
            </div>
          </div>
        </div>
        <div style="display: flex; align-items: center; gap: 8px;">
          <button type="button" class="btn-exercise-header-check ${completedSets === totalSets && totalSets > 0 ? 'checked' : ''}" onclick="event.stopPropagation(); toggleAllExerciseSetsDone('${ex.id}')" title="Marcar/Desmarcar todas as séries">
            ${completedSets === totalSets && totalSets > 0 ? '✓' : '○'}
          </button>
          <span class="expand-chevron" style="transform: ${isExpanded ? 'rotate(180deg)' : 'rotate(0deg)'};">▼</span>
        </div>
      </div>

      <div class="exercise-metafit-body" style="display: ${isExpanded ? 'block' : 'none'};">
        <div class="sets-table-header">
          <span style="width: 32px; text-align: center;">SET</span>
          <span style="flex: 1.4; text-align: left; padding-left: 2px;">ANTERIOR</span>
          <span style="width: 65px; text-align: center;">CARGA KG</span>
          <span style="width: 55px; text-align: center;">REPS</span>
          <span style="width: 36px; text-align: center;">✓</span>
        </div>

        <div class="sets-rows-container">
          ${seriesRowsHtml}
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 10px;">
          <button class="btn-add-set" onclick="addExerciseSet('${ex.id}')">
            + adicionar série
          </button>
          <div style="display: flex; gap: 6px;">
            <button class="btn-icon-xs" onclick="toggleExerciseBiSet('${ex.id}')" title="Alternar Bi-Set">
              ${ex.isBiSet ? '⚡ Bi-Set Ativo' : '⚡ Bi-Set'}
            </button>
            <button class="btn-icon-xs" onclick="openEditExerciseModal('${ex.id}')" title="Editar">✏️</button>
            <button class="btn-icon-xs" onclick="deleteExercise('${ex.id}')" title="Excluir">🗑️</button>
          </div>
        </div>

        ${ex.notes ? `
          <div class="trainer-note-box">
            <div class="trainer-note-label">🎯 OBSERVAÇÃO DO TREINADOR</div>
            <div class="trainer-note-text">${ex.notes}</div>
          </div>
        ` : ''}
      </div>
    </div>
  `;
}

// VIEW 1: RENDERIZA O TREINO DO DIA (ESTILO METAFIT)
function renderWorkoutRoutineView() {
  const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
  if (!STATE.routines) STATE.routines = JSON.parse(JSON.stringify(DEFAULT_WORKOUT_ROUTINES));
  if (!STATE.routines[currentDay]) {
    STATE.routines[currentDay] = JSON.parse(JSON.stringify(DEFAULT_WORKOUT_ROUTINES[currentDay] || DEFAULT_WORKOUT_ROUTINES[0]));
  }
  const routine = STATE.routines[currentDay];

  // 1. Division Pills Bar: A, B, C, D, E... [+ Divisão] como na foto
  const pillsBar = document.getElementById("divisionPillsBar");
  if (pillsBar) {
    const letters = ["A", "B", "C", "D", "E", "F", "G"];
    const routineKeys = Object.keys(STATE.routines).map(k => parseInt(k)).sort((a,b) => a - b);
    
    let htmlPills = routineKeys.map((idx) => {
      const letter = letters[idx] || (idx + 1);
      const isActive = (idx === STATE.activeDayIndex);
      return `
        <button class="division-pill ${isActive ? 'active' : ''}" onclick="setWorkoutDay(${idx})" title="${STATE.routines[idx].title || ''}">
          ${letter}
        </button>
      `;
    }).join('');

    htmlPills += `
      <button class="division-pill btn-add-div" onclick="addNewWorkoutDivision()" title="Criar nova divisão">
        + Divisão
      </button>
    `;
    pillsBar.innerHTML = htmlPills;
  }

  // 2. Header & Meta info
  const labelEl = document.getElementById("workoutDayLabel");
  const titleEl = document.getElementById("workoutDayTitle");
  const countEl = document.getElementById("exerciseCountBadge");
  const exCountText = document.getElementById("workoutExCountText");
  const estTimeText = document.getElementById("workoutEstimatedTimeText");

  const exList = routine.exercises || [];
  let totalSetsCount = 0;
  exList.forEach(e => {
    ensureExerciseSeries(e);
    totalSetsCount += e.series.length;
  });

  const estMinutes = Math.max(20, Math.round(totalSetsCount * 2.5));

  if (labelEl) labelEl.innerText = routine.dayName || "Divisão";
  if (titleEl) titleEl.innerText = routine.title || "Meu Treino";
  if (countEl) countEl.innerText = exList.length;
  if (exCountText) exCountText.innerText = `${exList.length} exercícios (${totalSetsCount} séries)`;
  if (estTimeText) estTimeText.innerText = `~${estMinutes} min`;

  // 3. Exercise Cards MetaFit
  const container = document.getElementById("exerciseListContainer");
  if (!container) return;

  if (exList.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 26px 12px; color: var(--text-muted); font-size: 0.85rem; background: rgba(255,255,255,0.02); border-radius: var(--radius-sm); border: 1px dashed var(--border-color); margin-top: 10px;">
        <div style="font-size: 1.8rem; margin-bottom: 6px;">📋</div>
        Nenhum exercício montado nesta divisão ainda.<br>
        <span style="font-size: 0.75rem; color: var(--text-dark);">Escolha uma opção para começar:</span>
        <div style="display: flex; gap: 8px; justify-content: center; margin-top: 14px; flex-wrap: wrap;">
          <button type="button" class="btn btn-outline" style="padding: 8px 14px; font-size: 0.78rem; color: #38bdf8; border-color: rgba(56,189,248,0.5);" onclick="switchWorkoutSubtab('guide')">
            🧬 Abrir Guia de Músculos
          </button>
          <button type="button" class="btn btn-primary" style="padding: 8px 14px; font-size: 0.78rem;" onclick="openAddExerciseModal()">
            + Adicionar Exercício
          </button>
        </div>
      </div>
    `;
    updateActiveWorkoutBottomBar();
    return;
  }

  // Agrupamento Inteligente de Bi-Sets
  let cardsHtml = '';
  let i = 0;
  while (i < exList.length) {
    const currentEx = exList[i];
    const nextEx = exList[i + 1];

    if (currentEx.isBiSet && nextEx && nextEx.isBiSet) {
      cardsHtml += `
        <div class="biset-group-card">
          <div class="biset-group-header">
            <span class="biset-tag-pill">BI-SET</span>
            <span>2 exercícios emendados sem pausa · descanso ao fim do bloco</span>
          </div>
          ${renderExerciseCardMetaFit(currentEx, i, true)}
          ${renderExerciseCardMetaFit(nextEx, i + 1, true)}
        </div>
      `;
      i += 2;
    } else {
      cardsHtml += renderExerciseCardMetaFit(currentEx, i, false);
      i++;
    }
  }

  container.innerHTML = cardsHtml;
  updateActiveWorkoutBottomBar();
}

// VIEW 2: GUIA DE MÚSCULOS & EXERCÍCIOS
function filterGuideMuscle(muscleKey) {
  triggerHaptic('light');
  currentGuideMuscle = muscleKey;
  renderWorkoutGuideView();
}

function addExerciseFromGuide(catalogIdx) {
  triggerHaptic('success');
  const exTemplate = EXERCISE_CATALOG[catalogIdx];
  if (!exTemplate) return;

  const currentDay = (typeof STATE.activeDayIndex === 'number' && STATE.activeDayIndex >= 0) ? STATE.activeDayIndex : 0;
  if (!STATE.routines) STATE.routines = JSON.parse(JSON.stringify(DEFAULT_WORKOUT_ROUTINES));
  if (!STATE.routines[currentDay]) {
    STATE.routines[currentDay] = { dayName: "Treino", title: "Meu Treino", exercises: [] };
  }

  const newExercise = {
    id: "ex_" + Date.now() + "_" + Math.random().toString(36).substr(2, 4),
    name: exTemplate.name,
    muscle: exTemplate.muscle,
    sets: exTemplate.sets || 4,
    reps: exTemplate.reps || "10-12",
    weight: exTemplate.weight || 0,
    rest: exTemplate.rest || 60,
    notes: exTemplate.notes || "",
    isBiSet: false,
    done: false
  };

  STATE.routines[currentDay].exercises.push(newExercise);
  saveState();

  alert(`✔ "${exTemplate.name}" adicionado à sua ficha do dia!`);
}

function renderWorkoutGuideView() {
  // 1. Muscle Filter Bar
  const filterBar = document.getElementById("muscleFilterBar");
  const muscles = [
    { key: "all", label: "Todos", icon: "⚡" },
    { key: "peito", label: "Peito", icon: "🔴" },
    { key: "costas", label: "Costas", icon: "🔴" },
    { key: "ombros", label: "Ombros", icon: "🔴" },
    { key: "biceps", label: "Bíceps", icon: "🔴" },
    { key: "triceps", label: "Tríceps", icon: "🔴" },
    { key: "pernas", label: "Quadríceps", icon: "🔴" },
    { key: "posterior", label: "Posterior/Glúteos", icon: "🔴" },
    { key: "abdomen", label: "Abdômen", icon: "🔴" },
    { key: "panturrilha", label: "Panturrilhas", icon: "🔴" }
  ];

  if (filterBar) {
    filterBar.innerHTML = muscles.map(m => `
      <button class="muscle-filter-btn ${currentGuideMuscle === m.key ? 'active' : ''}" onclick="filterGuideMuscle('${m.key}')">
        <span>${m.icon}</span> ${m.label}
      </button>
    `).join('');
  }

  // 2. Muscle Detail Card (Anatomia e Biomecânica)
  const detailCard = document.getElementById("muscleDetailCard");
  if (detailCard) {
    const detailMap = {
      all: {
        title: "Mapa Muscular Completo",
        primary: "Todos os grupos musculares principais",
        synergist: "Ativação global do corpo",
        tip: "Selecione um grupo muscular nos botões acima para ver exatamente a anatomia e os exercícios ideais para hipertrofia."
      },
      peito: {
        title: "Peitoral Maior & Clavicular (Superior)",
        primary: "Peitoral Maior (fibras superiores, médias e inferiores)",
        synergist: "Deltoide Anterior e Tríceps Braquial",
        tip: "Foque na aproximação dos cotovelos no final da contração (adução do braço) para ativar 100% das fibras do peito."
      },
      costas: {
        title: "Grande Dorsal, Trapézio & Romboides",
        primary: "Grande Dorsal (abertura das asas) e Trapézio Médio/Inferior",
        synergist: "Bíceps Braquial, Braquial e Antebraços",
        tip: "Puxe direcionando o movimento com os cotovelos e estufe bem o peito para não roubar carga com os braços."
      },
      ombros: {
        title: "Deltoides (Anterior, Lateral e Posterior)",
        primary: "Deltoide Lateral (largura de ombro) e Anterior",
        synergist: "Trapézio Superior e Tríceps",
        tip: "Na elevação lateral, mantenha os cotovelos levemente flexionados e incline o halter como se estivesse vertendo um copo d'água."
      },
      biceps: {
        title: "Bíceps Braquial & Braquiorradial",
        primary: "Bíceps (Cabeça Longa e Curta) e Braquial Anterior",
        synergist: "Flexores do Antebraço",
        tip: "Mantenha os cotovelos travados na linha do tronco e faça a rotação máxima do punho para fora (supinação) no topo."
      },
      triceps: {
        title: "Tríceps Braquial (3 Cabeças)",
        primary: "Cabeça Lateral, Longa e Medial do Tríceps (ocupa 60% do braço)",
        synergist: "Peitoral Maior e Deltoides",
        tip: "Estenda completamente os cotovelos e aperte por 1 segundo na contração máxima de cada repetição."
      },
      pernas: {
        title: "Quadríceps (Vasto Lateral, Medial e Reto Femoral)",
        primary: "Quadríceps da coxa",
        synergist: "Glúteo Máximo, Adutores e Panturrilhas",
        tip: "Agache descendo abaixo de 90 graus controlando o peso sem deixar os joelhos entrarem para dentro (valgo dinâmico)."
      },
      posterior: {
        title: "Isquiotibiais & Glúteo Máximo",
        primary: "Bíceps Femoral, Semitendíneo e Glúteo",
        synergist: "Lombar e Adutores",
        tip: "No stiff e na flexora, mantenha a coluna totalmente travada e empurre o quadril para trás sentindo o alongamento do músculo."
      },
      abdomen: {
        title: "Reto Abdominal & Core",
        primary: "Reto do Abdômen (Supra e Infra) e Oblíquos",
        synergist: "Transverso do Abdômen e Quadrado Lombar",
        tip: "Solte todo o ar na subida do movimento para contrair a musculatura profunda do abdômen ao máximo."
      },
      panturrilha: {
        title: "Gastrocnêmio & Sóleo",
        primary: "Gastrocnêmio (cabeça medial e lateral) e Sóleo",
        synergist: "Tendão de Aquiles e Músculos dos Pés",
        tip: "Alongue ao máximo o calcanhar na descida (pausa de 1s) e suba na ponta extrema dos dedos para recrutar todas as fibras."
      }
    };

    const info = detailMap[currentGuideMuscle] || detailMap.all;
    detailCard.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6px;">
        <h4 style="font-size: 0.95rem; font-weight: 800; color: #fff; margin: 0;">${info.title}</h4>
        <span style="font-size: 0.65rem; background: rgba(239,68,68,0.2); color: #f87171; padding: 2px 6px; border-radius: 4px; font-weight: 700; border: 1px solid rgba(239,68,68,0.4);">
          🔴 Foco Alvo
        </span>
      </div>
      <div style="font-size: 0.74rem; color: #cbd5e1; margin-bottom: 4px;">
        <strong>🎯 Músculo Primário:</strong> ${info.primary}
      </div>
      <div style="font-size: 0.74rem; color: #cbd5e1; margin-bottom: 6px;">
        <strong>⚡ Sinergistas (Apoio):</strong> ${info.synergist}
      </div>
      <div style="font-size: 0.72rem; color: #fde047; background: rgba(245, 158, 11, 0.1); border-left: 3px solid #f59e0b; padding: 6px 8px; border-radius: 0 6px 6px 0;">
        💡 <strong>Dica do Treinador:</strong> ${info.tip}
      </div>
    `;
  }

  // 3. Exercise Catalog Grid
  const listContainer = document.getElementById("guideExerciseList");
  if (!listContainer) return;

  const filtered = EXERCISE_CATALOG.filter(ex => {
    if (currentGuideMuscle === 'all') return true;
    if (currentGuideMuscle === 'posterior') return ex.muscle === 'posterior';
    return ex.muscle === currentGuideMuscle;
  });

  listContainer.innerHTML = filtered.map((ex, idx) => {
    const originalIdx = EXERCISE_CATALOG.indexOf(ex);
    const muscle = ex.muscle || detectMuscleForExercise(ex.name, ex.notes);
    const targetLabel = getMuscleTargetName(muscle);
    const svgThumb = renderMuscleThumbnailSvg(muscle);

    return `
      <div class="guide-card-pro">
        <div class="exercise-thumb-box" title="Foco Anatômico: ${targetLabel}">
          ${svgThumb}
        </div>
        <div style="flex: 1; min-width: 0;">
          <div style="font-size: 0.9rem; font-weight: 800; color: #fff; margin-bottom: 2px;">${ex.name}</div>
          <div style="font-size: 0.72rem; color: #cbd5e1;">
            Séries: <strong>${ex.sets}</strong> × <strong>${ex.reps}</strong> · Descanso: <strong>${ex.rest || 60}s</strong>
          </div>
          <div class="muscle-target-badge" style="margin-top: 3px;">
            🎯 ${targetLabel}
          </div>
          ${ex.notes ? `<div style="font-size: 0.68rem; color: #94a3b8; margin-top: 3px;">💡 ${ex.notes}</div>` : ''}
        </div>
        <button class="btn btn-primary" style="padding: 6px 10px; font-size: 0.7rem; flex-shrink: 0;" onclick="addExerciseFromGuide(${originalIdx})" title="Adicionar à ficha de hoje">
          + Adicionar
        </button>
      </div>
    `;
  }).join('');
}

function renderRunningTab() {
  const todayRuns = STATE.todayRuns || [];
  const history = STATE.runningHistory || [];

  const todayKm = todayRuns.reduce((acc, r) => acc + (r.km || 0), 0);
  const todayMins = todayRuns.reduce((acc, r) => acc + (r.minutes || 0), 0);
  const todayJumps = todayRuns.reduce((acc, r) => acc + (r.jumps || 0), 0);
  const totalGeneralKm = history.reduce((acc, r) => acc + (r.km || 0), 0);

  const heroKmEl = document.getElementById("runHeroKmToday");
  const heroTimeEl = document.getElementById("runHeroTimeToday");
  const heroJumpsEl = document.getElementById("runHeroJumpsToday");

  if (heroKmEl) heroKmEl.innerText = todayKm.toFixed(1);
  if (heroTimeEl) heroTimeEl.innerText = `${todayMins}m`;
  if (heroJumpsEl) heroJumpsEl.innerText = todayJumps.toLocaleString('pt-BR');

  const historyEl = document.getElementById("runningHistoryList");
  if (history.length === 0) {
    historyEl.innerHTML = `
      <p style="color: var(--text-muted); font-size: 0.8rem; text-align: center; padding: 14px 0;">
        Nenhuma atividade de cardio registrada ainda. Escolha GPS ou Corda e bora! ⚡
      </p>
    `;
  } else {
    historyEl.innerHTML = history.slice(0, 25).map(r => {
      const isRope = r.activity === 'rope' || r.isSensor;
      const isBike = r.activity === 'bike';
      const isGps = !!(r.isGps || (r.route && r.route.length > 0));
      const isOfficial = isGps || isRope || r.isSensor;
      const points = isOfficial ? (r.minutes / 120).toFixed(2) : '0.00';

      let badgeStyle = 'background: rgba(255,255,255,0.05); color: var(--text-muted); border: 1px solid rgba(255,255,255,0.1);';
      let badgeText = `0 pt (Manual)`;
      let typeTag = `<span style="font-size: 0.65rem; color: var(--text-muted); background: rgba(255,255,255,0.06); padding: 1px 6px; border-radius: 4px; margin-left: 6px;">📝 Esteira</span>`;
      let primaryLine = `<strong style="color: #fff; font-size: 0.95rem;">🏃‍♂️ ${r.km} km</strong> <span style="color: var(--text-muted); font-size: 0.85rem;">em</span> <strong style="color: var(--accent-green); font-size: 0.95rem;">${r.minutes} min</strong>`;
      let secondaryLine = `Data: ${r.date} às ${r.timeStr} • Ritmo: <span style="color: var(--accent-orange); font-weight: 700;">${r.pace}</span>`;

      if (isRope) {
        badgeStyle = 'background: rgba(59,130,246,0.15); color: #60a5fa; border: 1px solid rgba(59,130,246,0.3); font-weight:700;';
        badgeText = `+${points} pt`;
        typeTag = `<span style="font-size: 0.65rem; color: #60a5fa; background: rgba(59,130,246,0.15); padding: 1px 6px; border-radius: 4px; font-weight: 700; margin-left: 6px;">📲 Sensor Corda</span>`;
        primaryLine = `<strong style="color: #fff; font-size: 0.95rem;">🪢 ${r.jumps || 0} pulos</strong> <span style="color: var(--text-muted); font-size: 0.85rem;">em</span> <strong style="color: var(--accent-green); font-size: 0.95rem;">${r.minutes} min</strong>`;
        secondaryLine = `Data: ${r.date} às ${r.timeStr} • Cadência: <span style="color: #60a5fa; font-weight: 700;">${r.pace}</span>${r.calories ? ` • ~${r.calories} kcal` : ''}`;
      } else if (isBike) {
        badgeStyle = 'background: rgba(0,210,255,0.15); color: #00d2ff; border: 1px solid rgba(0,210,255,0.3); font-weight:700;';
        badgeText = `+${points} pt`;
        typeTag = `<span style="font-size: 0.65rem; color: #00d2ff; background: rgba(0,210,255,0.15); padding: 1px 6px; border-radius: 4px; font-weight: 700; margin-left: 6px;">🚴 GPS Bike</span>`;
        primaryLine = `<strong style="color: #fff; font-size: 0.95rem;">🚴 ${r.km} km</strong> <span style="color: var(--text-muted); font-size: 0.85rem;">em</span> <strong style="color: var(--accent-green); font-size: 0.95rem;">${r.minutes} min</strong>`;
        secondaryLine = `Data: ${r.date} às ${r.timeStr} • Vel. Média: <span style="color: #00d2ff; font-weight: 700;">${r.pace}</span>`;
      } else if (isGps) {
        badgeStyle = 'background: rgba(16,185,129,0.15); color: var(--accent-green); border: 1px solid rgba(16,185,129,0.3); font-weight:700;';
        badgeText = `+${points} pt`;
        typeTag = `<span style="font-size: 0.65rem; color: var(--accent-green); background: rgba(16,185,129,0.12); padding: 1px 6px; border-radius: 4px; font-weight: 700; margin-left: 6px;">🏃‍♂️ GPS Corrida</span>`;
      }

      return `
      <div class="session-item" style="display: flex; flex-direction: column; align-items: stretch; gap: 8px; padding: 12px; margin-bottom: 8px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;">
          <div style="flex: 1;">
            <div style="display: flex; align-items: center; flex-wrap: wrap; gap: 4px;">
              ${primaryLine}
              ${typeTag}
            </div>
            <div style="font-size: 0.72rem; color: var(--text-muted); margin-top: 3px;">
              ${secondaryLine}
            </div>
          </div>
          <span class="session-badge" style="${badgeStyle}; white-space: nowrap;">${badgeText}</span>
        </div>

        <div style="display: flex; gap: 6px; flex-wrap: wrap; align-items: center; padding-top: 6px; border-top: 1px solid rgba(255,255,255,0.06);">
          ${(r.route && r.route.length > 0) ? `
            <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.7rem; color: var(--accent-orange); border-color: rgba(245,158,11,0.4); display: inline-flex; align-items: center; gap: 4px;" onclick="openRouteModal('${r.id}')">
              🗺️ Ver Rota
            </button>
          ` : ''}
          <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.7rem; color: #60a5fa; border-color: rgba(96,165,250,0.4); display: inline-flex; align-items: center; gap: 4px;" onclick="openEditRunModal('${r.id}')">
            ✏️ Alterar Tempo
          </button>
          <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.7rem; color: #ef4444; border-color: rgba(239,68,68,0.4); display: inline-flex; align-items: center; gap: 4px; margin-left: auto;" onclick="deleteRun('${r.id}')">
            🗑️ Apagar
          </button>
        </div>
      </div>
      `;
    }).join('');
  }
}

// --- GLOBAL LEADERBOARD & HERO RANKING ENGINE ---
let currentLevelsSubtab = 'ranking';
let currentRankingFilter = 'points';

const GLOBAL_ATHLETES_SEED = [
  { id: "g1", name: "Titan Victor", country: "🇧🇷", level: 7, rank: "Lenda Suprema", rankTier: "S+", points: 54.0, km: 78.5, streak: 35, avatarBg: "#f59e0b" },
  { id: "g2", name: "Marcus Stone", country: "🇺🇸", level: 6, rank: "Caçador Nacional", rankTier: "S", points: 38.5, km: 52.0, streak: 22, avatarBg: "#ef4444" },
  { id: "g3", name: "Lucas Viking", country: "🇧🇷", level: 5, rank: "Mestre dos Pesos", rankTier: "A", points: 24.0, km: 64.2, streak: 19, avatarBg: "#8b5cf6" },
  { id: "g4", name: "Alexandre Kuro", country: "🇯🇵", level: 5, rank: "Mestre dos Pesos", rankTier: "A", points: 18.5, km: 34.0, streak: 14, avatarBg: "#10b981" },
  { id: "g5", name: "Diego Alencar", country: "🇧🇷", level: 4, rank: "Guerreiro de Elite", rankTier: "B", points: 13.0, km: 28.5, streak: 10, avatarBg: "#3b82f6" },
  { id: "g6", name: "Sarah Iron", country: "🇨🇦", level: 4, rank: "Guerreiro de Elite", rankTier: "B", points: 10.5, km: 42.0, streak: 12, avatarBg: "#ec4899" },
  { id: "g7", name: "Rodrigo B.", country: "🇧🇷", level: 3, rank: "Caçador Notável", rankTier: "C", points: 7.0, km: 16.5, streak: 7, avatarBg: "#f97316" },
  { id: "g8", name: "Enzo Fitt", country: "🇵🇹", level: 3, rank: "Caçador Notável", rankTier: "C", points: 5.5, km: 14.0, streak: 6, avatarBg: "#06b6d4" },
  { id: "g9", name: "Matheus Silva", country: "🇧🇷", level: 2, rank: "Caçador em Treino", rankTier: "D", points: 3.5, km: 9.0, streak: 4, avatarBg: "#10b981" },
  { id: "g10", name: "Carlos Treino", country: "🇧🇷", level: 1, rank: "Novato Desperto", rankTier: "E", points: 1.0, km: 4.5, streak: 2, avatarBg: "#64748b" }
];

function switchLevelsSubtab(subtab) {
  triggerHaptic('light');
  currentLevelsSubtab = subtab;
  
  const rankBtn = document.getElementById("subtab-ranking-btn");
  const tiersBtn = document.getElementById("subtab-tiers-btn");
  const rankView = document.getElementById("subtab-ranking-view");
  const tiersView = document.getElementById("subtab-tiers-view");

  if (subtab === 'ranking') {
    if (rankBtn) rankBtn.classList.add("active");
    if (tiersBtn) tiersBtn.classList.remove("active");
    if (rankView) rankView.style.display = "block";
    if (tiersView) tiersView.style.display = "none";
    renderRankingView();
  } else {
    if (rankBtn) rankBtn.classList.remove("active");
    if (tiersBtn) tiersBtn.classList.add("active");
    if (rankView) rankView.style.display = "none";
    if (tiersView) tiersView.style.display = "block";
    renderLevelsTiersView();
  }
}

function setRankingFilter(filter) {
  triggerHaptic('light');
  currentRankingFilter = filter;
  const btnPts = document.getElementById("rankFilterPoints");
  const btnRuns = document.getElementById("rankFilterRuns");
  if (filter === 'points') {
    if (btnPts) {
      btnPts.style.borderColor = "var(--accent-green)";
      btnPts.style.color = "var(--accent-green)";
    }
    if (btnRuns) {
      btnRuns.style.borderColor = "var(--border-color)";
      btnRuns.style.color = "var(--text-muted)";
    }
  } else {
    if (btnRuns) {
      btnRuns.style.borderColor = "var(--accent-green)";
      btnRuns.style.color = "var(--accent-green)";
    }
    if (btnPts) {
      btnPts.style.borderColor = "var(--border-color)";
      btnPts.style.color = "var(--text-muted)";
    }
  }
  renderRankingView();
}

function getGlobalLeaderboardList() {
  const totalKm = (STATE.runningHistory || []).reduce((acc, r) => acc + (r.km || 0), 0);
  const currentLevelObj = getLevelForPoints(STATE.totalPoints);

  const userItem = {
    id: "user_me",
    isUser: true,
    name: STATE.user.name || "Guerreiro",
    country: (STATE.user && STATE.user.countryFlag) ? STATE.user.countryFlag : "🇧🇷",
    level: STATE.currentLevel,
    rank: currentLevelObj.rank,
    rankTier: currentLevelObj.rankTier || "E",
    points: STATE.totalPoints,
    km: parseFloat(totalKm.toFixed(1)),
    streak: STATE.streakDays || 1,
    photo: STATE.user.photo || null,
    avatarBg: "var(--accent-green)"
  };

  const list = [...GLOBAL_ATHLETES_SEED, userItem];

  if (currentRankingFilter === 'points') {
    // Sort by points descending, then level descending (pontos e nível juntos)
    list.sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      return b.level - a.level;
    });
  } else {
    list.sort((a, b) => b.km - a.km);
  }

  // RANK SS SUPREMO: O líder isolado (#1 em pontos e nível) ascende ao Rank SS Supremo!
  if (list.length > 0) {
    list.forEach((item, index) => {
      if (index === 0) {
        item.isTop1Supreme = true;
        item.rankTier = "SS";
        item.rank = "Herói Supremo (Top 1 Geral)";
      } else {
        item.isTop1Supreme = false;
      }
    });
  }

  return list;
}

function renderRankingView(animated = false) {
  if (animated) {
    triggerHaptic('success');
    sfx.playCheck();
  }

  const list = getGlobalLeaderboardList();
  document.getElementById("leaderboardCountLabel").innerText = `${list.length} Atletas Conectados`;

  // Render Top 3 Podium
  const top1 = list[0];
  const top2 = list[1];
  const top3 = list[2];

  const renderPodiumAvatar = (item) => {
    if (item.photo) {
      return `<img src="${item.photo}" alt="${item.name}">`;
    }
    const initial = item.name.charAt(0).toUpperCase();
    return `<span style="color: #fff;">${initial}</span>`;
  };

  const podiumEl = document.getElementById("podiumContainer");
  if (podiumEl && top1 && top2 && top3) {
    podiumEl.innerHTML = `
      <!-- 2º LUGAR -->
      <div class="podium-step rank-2">
        <div class="podium-avatar-box">
          <div class="podium-avatar" style="background: ${top2.avatarBg};">
            ${renderPodiumAvatar(top2)}
          </div>
          <div class="podium-badge" style="transform: scale(0.9);">${getRankBadgeHtml(top2.rankTier)}</div>
        </div>
        <div class="podium-name">${top2.name} ${top2.isUser ? '(Você)' : ''}</div>
        <div class="podium-pts">${currentRankingFilter === 'points' ? `${top2.points.toFixed(1)} pts` : `${top2.km} km`}</div>
        <div class="podium-block">2</div>
      </div>

      <!-- 1º LUGAR: RANK SS SUPREMO -->
      <div class="podium-step rank-1">
        <div class="podium-avatar-box">
          <div class="podium-crown" style="font-size: 1.05rem; font-weight: 900; color: #00d2ff; text-shadow: 0 0 10px #00d2ff; letter-spacing: 0.5px;">⚡ SUPREMO</div>
          <div class="podium-avatar" style="background: ${top1.avatarBg}; box-shadow: 0 0 16px rgba(0, 210, 255, 0.7); border-color: #00d2ff;">
            ${renderPodiumAvatar(top1)}
          </div>
          <div class="podium-badge" style="transform: scale(0.95);">${getRankBadgeHtml('SS', true)}</div>
        </div>
        <div class="podium-name" style="color: #38bdf8; font-size: 0.9rem; font-weight: 800;">${top1.name} ${top1.isUser ? '(Você)' : ''}</div>
        <div class="podium-pts" style="font-size: 0.8rem; color: #00d2ff; font-weight: 800;">${currentRankingFilter === 'points' ? `${top1.points.toFixed(1)} pts` : `${top1.km} km`}</div>
        <div class="podium-block" style="border-top: 2px solid #00d2ff; box-shadow: inset 0 0 12px rgba(0,210,255,0.25);">1</div>
      </div>

      <!-- 3º LUGAR -->
      <div class="podium-step rank-3">
        <div class="podium-avatar-box">
          <div class="podium-avatar" style="background: ${top3.avatarBg};">
            ${renderPodiumAvatar(top3)}
          </div>
          <div class="podium-badge" style="transform: scale(0.9);">${getRankBadgeHtml(top3.rankTier)}</div>
        </div>
        <div class="podium-name">${top3.name} ${top3.isUser ? '(Você)' : ''}</div>
        <div class="podium-pts">${currentRankingFilter === 'points' ? `${top3.points.toFixed(1)} pts` : `${top3.km} km`}</div>
        <div class="podium-block">3</div>
      </div>
    `;
  }

  // User Sticky Rank
  const userRank = list.findIndex(c => c.isUser) + 1;
  const userItem = list.find(c => c.isUser);
  const userStickyEl = document.getElementById("userStickyRankBox");

  let overtakeInfo = "";
  if (userRank === 1) {
    overtakeInfo = `<span style="color: #00d2ff; font-weight: 900; text-shadow: 0 0 8px rgba(0,210,255,0.6);">⚡ VOCÊ É O RANK SS SUPREMO DO MUNDO!</span>`;
  } else if (userRank > 1) {
    const ahead = list[userRank - 2];
    if (currentRankingFilter === 'points') {
      const diff = (ahead.points - userItem.points) + 0.1;
      const hoursDiff = (diff * 2).toFixed(1);
      overtakeInfo = `Faltam <strong>${diff.toFixed(1)} pts</strong> (~${hoursDiff}h de treino) para ultrapassar <strong>${ahead.name}</strong> (#${userRank - 1})!`;
    } else {
      const diffKm = (ahead.km - userItem.km).toFixed(1);
      overtakeInfo = `Faltam <strong>${diffKm} km</strong> para ultrapassar <strong>${ahead.name}</strong> (#${userRank - 1})!`;
    }
  }

  if (userStickyEl) {
    const isTop1 = userRank === 1;
    userStickyEl.innerHTML = `
      <div class="user-rank-card ${isTop1 ? 'card-supreme-tier' : ''}">
        <div style="display: flex; align-items: center; gap: 10px;">
          <div style="font-size: 1.4rem; font-weight: 900; color: ${isTop1 ? '#00d2ff' : 'var(--accent-green)'}; min-width: 32px;">
            #${userRank}
          </div>
          <div class="leader-avatar" style="width: 44px; height: 44px; border-color: ${isTop1 ? '#00d2ff' : 'var(--accent-green)'};">
            ${renderPodiumAvatar(userItem)}
          </div>
          <div>
            <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
              <span style="font-weight: 800; font-size: 0.95rem; color: #fff;">${userItem.name}</span>
              <span style="font-size: 0.7rem; color: var(--accent-green); font-weight: 700;">(VOCÊ)</span>
              ${getRankBadgeHtml(userItem.rankTier, userItem.isTop1Supreme)}
            </div>
            <div style="font-size: 0.72rem; color: var(--text-muted); margin-top: 3px;">
              Nível ${userItem.level} • ${overtakeInfo}
            </div>
          </div>
        </div>
        <div style="text-align: right;">
          <div style="font-size: 1.15rem; font-weight: 900; color: ${isTop1 ? '#00d2ff' : 'var(--accent-orange)'};">
            ${currentRankingFilter === 'points' ? `${userItem.points.toFixed(1)} pts` : `${userItem.km} km`}
          </div>
          <div style="font-size: 0.65rem; color: var(--text-muted);">Sua pontuação</div>
        </div>
      </div>
    `;
  }

  // Leaderboard Full Table
  const listEl = document.getElementById("leaderboardList");
  if (listEl) {
    listEl.innerHTML = list.map((item, idx) => {
      const rankNum = idx + 1;
      const rankDisplay = `#${rankNum}`;
      let rankClass = "";
      if (rankNum === 1) { rankClass = "top-1"; }
      else if (rankNum === 2) { rankClass = "top-2"; }
      else if (rankNum === 3) { rankClass = "top-3"; }

      const isMe = item.isUser;
      const isSupreme = item.isTop1Supreme || item.rankTier === 'SS';
      const avatarHtml = item.photo 
        ? `<img src="${item.photo}" alt="${item.name}">` 
        : `<span style="color: #fff;">${item.name.charAt(0).toUpperCase()}</span>`;

      return `
        <div class="leader-item ${isMe ? 'is-user' : ''} ${isSupreme ? 'card-supreme-tier' : ''}">
          <div class="leader-rank-col ${rankClass}" style="${isSupreme ? 'color: #00d2ff; font-weight: 900;' : ''}">${rankDisplay}</div>
          <div class="leader-user-info">
            <div class="leader-avatar" style="background: ${item.avatarBg || 'var(--bg-card)'}; ${isSupreme ? 'border-color: #00d2ff;' : ''}">
              ${avatarHtml}
            </div>
            <div>
              <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
                <span style="font-weight: 800; font-size: 0.88rem; color: ${isSupreme ? '#38bdf8' : (isMe ? 'var(--accent-green)' : '#fff')};">
                  <span>${item.country}</span> ${item.name} ${isMe ? '<span style="font-size:0.68rem; color: var(--accent-green); font-weight:800;">(VOCÊ)</span>' : ''}
                </span>
                ${getRankBadgeHtml(item.rankTier, item.isTop1Supreme)}
              </div>
              <div style="font-size: 0.7rem; color: var(--text-muted); margin-top: 2px;">
                Nível ${item.level} • ${item.rank}
              </div>
            </div>
          </div>
          <div class="leader-stats-col">
            <div style="font-weight: 800; font-size: 0.95rem; color: ${isSupreme ? '#00d2ff' : 'var(--accent-orange)'};">
              ${currentRankingFilter === 'points' ? `${item.points.toFixed(1)} pts` : `${item.km} km`}
            </div>
            <div style="font-size: 0.65rem; color: var(--text-muted);">
              ${currentRankingFilter === 'points' ? `${Math.floor(item.points * 2)}h treino` : `🔥 ${item.streak} dias`}
            </div>
          </div>
        </div>
      `;
    }).join('');
  }
}

function renderLevelsTiersView() {
  const listEl = document.getElementById("levelsHierarchyList");
  if (!listEl) return;
  listEl.innerHTML = LEVELS.map(l => {
    const isCurrent = l.level === STATE.currentLevel;
    const isUnlocked = STATE.totalPoints >= l.minPoints;
    const requiredHours = l.minPoints * 2;
    const isSupreme = l.rankTier === 'SS';

    return `
      <div class="card ${isCurrent ? 'card-highlight' : ''} ${isSupreme ? 'card-supreme-tier' : ''}" style="margin-bottom: 8px; padding: 12px 14px; opacity: ${isUnlocked ? '1' : '0.6'};">
        <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px;">
          <div style="display: flex; align-items: center; gap: 10px;">
            ${getRankBadgeHtml(l.rankTier, isSupreme)}
            <div>
              <div style="font-weight: 800; font-size: 0.95rem; color: ${isSupreme ? '#38bdf8' : (isCurrent ? 'var(--accent-green)' : '#fff')};">
                Nível ${l.level}: ${l.name} ${isCurrent ? '⭐ (VOCÊ)' : ''}
              </div>
              <div style="font-size: 0.72rem; color: var(--text-muted);">${l.rank}</div>
            </div>
          </div>
          <div style="text-align: right; font-size: 0.75rem; white-space: nowrap;">
            <div style="font-weight: 700; color: ${isSupreme ? '#00d2ff' : 'var(--accent-orange)'};">${l.minPoints} Pontos</div>
            <div style="font-size: 0.65rem; color: var(--text-muted);">(${requiredHours}h de treino)</div>
          </div>
        </div>
      </div>
    `;
  }).join('');

  // Badges Grid
  const badgesGrid = document.getElementById("badgesGrid");
  if (!badgesGrid) return;
  badgesGrid.innerHTML = STATE.badges.map(b => `
    <div style="background: rgba(255,255,255,0.03); border: 1px solid ${b.unlocked ? 'var(--accent-green)' : 'var(--border-color)'}; border-radius: var(--radius-sm); padding: 10px; text-align: center; opacity: ${b.unlocked ? '1' : '0.45'};">
      <div style="font-size: 1.8rem; margin-bottom: 4px;">${b.icon}</div>
      <div style="font-size: 0.8rem; font-weight: 800; color: ${b.unlocked ? '#fff' : 'var(--text-muted)'};">${b.name}</div>
      <div style="font-size: 0.68rem; color: var(--text-muted); margin-top: 2px;">${b.desc}</div>
      <span style="display: inline-block; font-size: 0.62rem; margin-top: 6px; padding: 2px 6px; border-radius: 4px; background: ${b.unlocked ? 'rgba(16,185,129,0.2)' : 'rgba(255,255,255,0.05)'}; color: ${b.unlocked ? 'var(--accent-green)' : 'var(--text-muted)'};">
        ${b.unlocked ? 'DESBLOQUEADO' : 'BLOQUEADO'}
      </span>
    </div>
  `).join('');
}

function renderLevelsTab() {
  if (currentLevelsSubtab === 'ranking') {
    renderRankingView();
  } else {
    renderLevelsTiersView();
  }
}

// --- SHARE CARD GENERATOR (CANVAS) ---
function generateDailyShareCard() {
  const canvas = document.getElementById("shareCanvas");
  const ctx = canvas.getContext("2d");
  const width = canvas.width;
  const height = canvas.height;

  // Background
  const gradient = ctx.createLinearGradient(0, 0, 0, height);
  gradient.addColorStop(0, "#0d131f");
  gradient.addColorStop(0.5, "#0a0d14");
  gradient.addColorStop(1, "#05080c");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  // Subtle border accent
  ctx.strokeStyle = "rgba(16, 185, 129, 0.4)";
  ctx.lineWidth = 10;
  ctx.strokeRect(10, 10, width - 20, height - 20);

  // Brand Header
  ctx.fillStyle = "#10b981";
  ctx.font = "bold 28px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
  ctx.fillText("⚡ IRONLEVEL APP", 40, 60);

  // Date
  ctx.fillStyle = "#94a3b8";
  ctx.font = "500 20px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
  ctx.fillText(new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' }), 40, 92);

  // User Profile Row
  if (cachedUserPhotoImg && cachedUserPhotoImg.complete && cachedUserPhotoImg.naturalWidth > 0) {
    const avatarX = 40;
    const avatarY = 114;
    const avatarSize = 46;

    ctx.save();
    ctx.beginPath();
    ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(cachedUserPhotoImg, avatarX, avatarY, avatarSize, avatarSize);
    ctx.restore();

    ctx.strokeStyle = "rgba(16, 185, 129, 0.8)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 34px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
    ctx.fillText(STATE.user.name.toUpperCase(), 100, 150);
  } else {
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 34px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
    ctx.fillText(STATE.user.name.toUpperCase(), 40, 150);
  }

  const currentLevelObj = getLevelForPoints(STATE.totalPoints);

  // Level Badge Box
  ctx.fillStyle = "rgba(16, 185, 129, 0.15)";
  ctx.strokeStyle = "#10b981";
  ctx.lineWidth = 2;
  roundRect(ctx, 40, 175, width - 80, 110, 16, true, true);

  // Hero Rank Badge
  ctx.fillStyle = "#ffffff";
  ctx.font = "bold 36px 'Impact', system-ui";
  ctx.fillText(currentLevelObj.rankTier || 'E', 75, 246);

  ctx.fillStyle = "#10b981";
  ctx.font = "bold 26px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
  ctx.fillText(`RANK ${currentLevelObj.rankTier}: ${currentLevelObj.name.toUpperCase()}`, 145, 222);

  ctx.fillStyle = "#cbd5e1";
  ctx.font = "18px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
  ctx.fillText(`Patente de Herói: ${currentLevelObj.rank} • Pontos: ${STATE.totalPoints.toFixed(2)} pts`, 145, 256);

  // Stats Grid 2x2
  const todayTotalMin = STATE.todaySessions.reduce((acc, s) => acc + s.durationMin, 0);
  const todayKm = STATE.todayRuns.reduce((acc, r) => acc + r.km, 0);
  const sessionCount = STATE.todaySessions.length;

  const statBoxes = [
    { label: "SESSÕES HOJE", val: `${sessionCount} treinos`, sub: "Consistência diária", x: 40, y: 310, w: 300, h: 100 },
    { label: "TEMPO TOTAL", val: `${todayTotalMin} min`, sub: `+${(todayTotalMin/120).toFixed(2)} pts acumulados`, x: 380, y: 310, w: 300, h: 100 },
    { label: "CARDIO & CORRIDA", val: `${todayKm.toFixed(1)} km`, sub: "Distância percorrida", x: 40, y: 430, w: 300, h: 100 },
    { label: "SEQUÊNCIA DIÁRIA", val: `🔥 ${STATE.streakDays} dias`, sub: "Foco inabalável", x: 380, y: 430, w: 300, h: 100 }
  ];

  statBoxes.forEach(b => {
    ctx.fillStyle = "rgba(255, 255, 255, 0.04)";
    ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
    roundRect(ctx, b.x, b.y, b.w, b.h, 12, true, true);

    ctx.fillStyle = "#94a3b8";
    ctx.font = "bold 14px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
    ctx.fillText(b.label, b.x + 16, b.y + 30);

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 28px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
    ctx.fillText(b.val, b.x + 16, b.y + 64);

    ctx.fillStyle = "#10b981";
    ctx.font = "13px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
    ctx.fillText(b.sub, b.x + 16, b.y + 86);
  });

  // Workout Details of Today
  ctx.fillStyle = "rgba(245, 158, 11, 0.08)";
  ctx.strokeStyle = "rgba(245, 158, 11, 0.25)";
  roundRect(ctx, 40, 555, width - 80, 225, 16, true, true);

  ctx.fillStyle = "#f59e0b";
  ctx.font = "bold 20px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
  ctx.fillText("📋 RESUMO DAS ATIVIDADES DO DIA", 60, 595);

  ctx.fillStyle = "#e2e8f0";
  ctx.font = "17px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";

  let startLineY = 635;
  if (STATE.todaySessions.length === 0) {
    ctx.fillText("• Nenhum treino de musculação registrado hoje ainda.", 60, startLineY);
  } else {
    STATE.todaySessions.slice(0, 4).forEach((s, i) => {
      ctx.fillText(`• ${s.type} - ${s.durationMin} min às ${s.timeStr} (+${s.pointsEarned} pt)`, 60, startLineY + (i * 32));
    });
  }

  if (todayKm > 0) {
    ctx.fillStyle = "#ef4444";
    ctx.fillText(`• Corrida: ${todayKm.toFixed(1)} km concluídos com sucesso! 🏃‍♂️`, 60, 745);
  }

  // Footer Motivational Box
  ctx.fillStyle = "#ffffff";
  ctx.font = "italic 20px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
  ctx.textAlign = "center";
  ctx.fillText('"A dor do treino é temporária. O orgulho é para sempre."', width / 2, 835);

  ctx.fillStyle = "#10b981";
  ctx.font = "bold 18px -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto";
  ctx.fillText("Treine todos os dias • 2 Horas = 1 Ponto • Suba de Nível!", width / 2, 875);
  ctx.textAlign = "left"; // reset
}

function roundRect(ctx, x, y, width, height, radius, fill, stroke) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
  if (fill) ctx.fill();
  if (stroke) ctx.stroke();
}

function renderShareTab() {
  generateDailyShareCard();
}

// Download Canvas as PNG
function downloadShareCard() {
  const canvas = document.getElementById("shareCanvas");
  const link = document.createElement("a");
  link.download = `meu-treino-${getTodayDateStr()}.png`;
  link.href = canvas.toDataURL("image/png");
  link.click();
}

// Web Share API
async function shareDailyCard() {
  const canvas = document.getElementById("shareCanvas");
  if (navigator.share && canvas.toBlob) {
    canvas.toBlob(async (blob) => {
      const file = new File([blob], `treino-${getTodayDateStr()}.png`, { type: 'image/png' });
      const currentLevelObj = getLevelForPoints(STATE.totalPoints);
      const text = `🔥 Treino pago no IronLevel!\nRank de Herói: [RANK ${currentLevelObj.rankTier}] ${currentLevelObj.name}\nPontos Acumulados: ${STATE.totalPoints.toFixed(2)} pts\nSequência: ${STATE.streakDays} dias seguidos!`;
      try {
        await navigator.share({
          title: "Meu Treino no IronLevel",
          text: text,
          files: [file]
        });
      } catch (err) {
        // Fallback to text copy or download
        downloadShareCard();
      }
    });
  } else {
    downloadShareCard();
    copyShareText();
    alert("Card baixado em imagem! O resumo em texto também foi copiado para sua área de transferência para enviar no WhatsApp!");
  }
}

// Copy Summary Text
function copyShareText() {
  const currentLevelObj = getLevelForPoints(STATE.totalPoints);
  const todayTotalMin = STATE.todaySessions.reduce((acc, s) => acc + s.durationMin, 0);
  const todayKm = STATE.todayRuns.reduce((acc, r) => acc + r.km, 0);

  const text = `🔥 *TREINO PAGO - IRONLEVEL* 🔥\n` +
    `👤 *Atleta:* ${STATE.user.name}\n` +
    `⚡ *Rank de Herói:* [RANK ${currentLevelObj.rankTier}] ${currentLevelObj.name}\n` +
    `⭐ *Pontos:* ${STATE.totalPoints.toFixed(2)} pts (2h de treino = 1 pt)\n` +
    `⏱️ *Tempo Hoje:* ${todayTotalMin} minutos\n` +
    (todayKm > 0 ? `🏃‍♂️ *Corrida:* ${todayKm.toFixed(1)} km\n` : '') +
    `🔥 *Sequência:* ${STATE.streakDays} dias seguidos!\n` +
    `Bora pra cima! Rumo ao próximo Rank! 💪`;

  navigator.clipboard.writeText(text).then(() => {
    alert("Texto copiado para a área de transferência! Cole no WhatsApp ou Instagram!");
  }).catch(() => {
    prompt("Copie o texto abaixo:", text);
  });
}

function renderAll() {
  renderHomeTab();
  renderWorkoutTab();
  renderRunningTab();
  renderLevelsTab();
  updateAllCommunityCounters();
}

// --- SISTEMA DE CADASTRO (ONBOARDING) E CONTADOR DA COMUNIDADE ---
const BASE_COMMUNITY_USERS = 3428;

function getCommunityUsersCount() {
  const saved = localStorage.getItem('ironlevel_community_users_count');
  if (saved) {
    const val = parseInt(saved, 10);
    if (!isNaN(val) && val >= BASE_COMMUNITY_USERS) return val;
  }
  const count = BASE_COMMUNITY_USERS + (STATE.user && STATE.user.registered ? 1 : 0);
  return count;
}

function updateAllCommunityCounters() {
  const count = getCommunityUsersCount();
  const countFormatted = count.toLocaleString('pt-BR');

  // 1. Header Pill
  const headerCountEl = document.getElementById("headerCommunityCount");
  if (headerCountEl) headerCountEl.innerText = countFormatted;

  // 2. Ranking Tab Counter
  const rankingCountEl = document.getElementById("rankingCommunityCount");
  if (rankingCountEl) rankingCountEl.innerText = countFormatted;

  // 3. Atletas Treinando Agora (dinâmico com horário)
  const activeNowEl = document.getElementById("rankingActiveNowCount");
  if (activeNowEl) {
    const hour = new Date().getHours();
    const bonus = (hour >= 17 && hour <= 21) ? 58 : (hour >= 6 && hour <= 9 ? 34 : 12);
    activeNowEl.innerText = (175 + bonus).toString();
  }

  // 4. Modal de Onboarding / Cadastro
  const onbCounterEl = document.getElementById("onbCommunityCounterNumber");
  if (onbCounterEl) onbCounterEl.innerText = countFormatted;

  const onbNextEl = document.getElementById("onbNextMemberNumber");
  if (onbNextEl) {
    const nextNum = (STATE.user && STATE.user.memberNumber) ? STATE.user.memberNumber : (count + (STATE.user && STATE.user.registered ? 0 : 1));
    onbNextEl.innerText = `#${nextNum.toLocaleString('pt-BR')}`;
  }

  // 5. Badge no Modal de Perfil
  const profileMemberText = document.getElementById("profileMemberText");
  if (profileMemberText) {
    const num = (STATE.user && STATE.user.memberNumber) ? STATE.user.memberNumber : count;
    profileMemberText.innerText = `Guerreiro Oficial #${num.toLocaleString('pt-BR')} no App`;
  }
}

function openOnboardingModal(forceEdit = false) {
  triggerHaptic('light');
  const modal = document.getElementById("onboardingModal");
  if (!modal) return;

  // Pre-popula campos se já existirem
  const nameInput = document.getElementById("onbNameInput");
  const ageInput = document.getElementById("onbAgeInput");
  const countrySelect = document.getElementById("onbCountrySelect");
  const otherCountryWrap = document.getElementById("onbOtherCountryWrap");
  const otherCountryInput = document.getElementById("onbOtherCountryInput");

  if (nameInput) {
    nameInput.value = (STATE.user && STATE.user.name && STATE.user.name !== "Guerreiro") ? STATE.user.name : "";
  }
  if (ageInput && STATE.user && STATE.user.age) {
    ageInput.value = STATE.user.age;
  }
  if (countrySelect && STATE.user && STATE.user.country) {
    let found = false;
    for (let i = 0; i < countrySelect.options.length; i++) {
      if (countrySelect.options[i].value.startsWith(STATE.user.country)) {
        countrySelect.selectedIndex = i;
        found = true;
        break;
      }
    }
    if (!found && STATE.user.country) {
      countrySelect.value = "Outro|🌐";
      if (otherCountryWrap) otherCountryWrap.style.display = "block";
      if (otherCountryInput) otherCountryInput.value = STATE.user.country;
    }
  }

  // Objetivo
  if (STATE.user && STATE.user.goal) {
    const cards = document.querySelectorAll('.onb-goal-card');
    cards.forEach(c => {
      const inp = c.querySelector('input');
      if (inp && inp.value === STATE.user.goal) {
        selectOnbGoal(c, STATE.user.goal);
      }
    });
  }

  updateAllCommunityCounters();
  modal.style.display = "flex";

  if (nameInput && !nameInput.value) {
    setTimeout(() => nameInput.focus(), 300);
  }
}

function closeOnboardingModal() {
  const modal = document.getElementById("onboardingModal");
  if (modal) {
    modal.style.display = "none";
  }
}

function handleOnbCountryChange(val) {
  const otherWrap = document.getElementById("onbOtherCountryWrap");
  if (!otherWrap) return;
  if (val.startsWith("Outro")) {
    otherWrap.style.display = "block";
    const inp = document.getElementById("onbOtherCountryInput");
    if (inp) inp.focus();
  } else {
    otherWrap.style.display = "none";
  }
}

function selectOnbGoal(cardEl, goalValue) {
  triggerHaptic('light');
  document.querySelectorAll('.onb-goal-card').forEach(c => c.classList.remove('active'));
  if (cardEl) {
    cardEl.classList.add('active');
    const inp = cardEl.querySelector('input');
    if (inp) inp.checked = true;
  }
}

function handleCompleteOnboarding(e) {
  e.preventDefault();
  triggerHaptic('success');

  const nameInput = document.getElementById("onbNameInput");
  const ageInput = document.getElementById("onbAgeInput");
  const countrySelect = document.getElementById("onbCountrySelect");
  const otherCountryInput = document.getElementById("onbOtherCountryInput");

  const name = nameInput ? nameInput.value.trim() : "";
  const age = ageInput ? parseInt(ageInput.value, 10) : null;

  if (!name || name.length < 2) {
    alert("Por favor, digite seu nome ou apelido (mínimo 2 letras)!");
    if (nameInput) nameInput.focus();
    return;
  }

  if (!age || age < 10 || age > 110) {
    alert("Por favor, digite uma idade válida (entre 10 e 110 anos)!");
    if (ageInput) ageInput.focus();
    return;
  }

  let countryName = "Brasil";
  let countryFlag = "🇧🇷";

  if (countrySelect && countrySelect.value) {
    const parts = countrySelect.value.split("|");
    countryName = parts[0] || "Brasil";
    countryFlag = parts[1] || "🇧🇷";
    if (countryName === "Outro" && otherCountryInput && otherCountryInput.value.trim()) {
      countryName = otherCountryInput.value.trim();
      countryFlag = "🌐";
    }
  }

  const checkedGoal = document.querySelector('input[name="onbGoal"]:checked');
  const goal = checkedGoal ? checkedGoal.value : "Hipertrofia";

  // Se for primeiro cadastro, incrementa contador da comunidade
  if (!STATE.user.registered) {
    let cur = getCommunityUsersCount();
    cur++;
    localStorage.setItem('ironlevel_community_users_count', cur);
    STATE.user.memberNumber = cur;
  }

  STATE.user.name = name;
  STATE.user.age = age;
  STATE.user.country = countryName;
  STATE.user.countryFlag = countryFlag;
  STATE.user.goal = goal;
  STATE.user.avatar = name.charAt(0).toUpperCase();
  STATE.user.registered = true;
  STATE.user.registeredDate = STATE.user.registeredDate || new Date().toISOString();

  saveState();
  closeOnboardingModal();

  renderAll();
  updateAllCommunityCounters();

  if (typeof sfx !== 'undefined' && sfx.playLevelUp) {
    sfx.playLevelUp();
  } else if (typeof sfx !== 'undefined' && sfx.playCheck) {
    sfx.playCheck();
  }

  if (typeof launchConfetti === 'function') {
    launchConfetti();
  }

  showToast(`⚔️ Registro Oficial Concluído! Bem-vindo, ${name}! (${countryFlag} Guerreiro #${STATE.user.memberNumber})`);
}

function checkFirstTimeOnboarding() {
  const isRegistered = STATE.user && STATE.user.registered === true;
  if (!isRegistered) {
    // Abre a tela de cadastro para novos usuários
    setTimeout(() => {
      openOnboardingModal();
    }, 450);
  }
}

// --- INIT APP ---
window.addEventListener("DOMContentLoaded", () => {
  loadState();
  updateCachedUserPhoto();
  // Define o novo tema Fogo Azul & Preto (Solo Leveling) como padrão
  if (!STATE.user.theme || STATE.user.theme === 'green') {
    STATE.user.theme = 'shadow';
  }
  applyTheme(STATE.user.theme);
  checkDateTurnover();
  checkStandaloneMode();
  STATE.activeDayIndex = getCurrentDayOfWeekIndex();
  populateExerciseCatalogCards();
  renderAll();
  restoreActiveWorkoutTimerSession();
  restoreActiveGpsSession();
  restoreActiveRopeSession();
  checkExpiredRestTimer();
  checkFirstTimeOnboarding();
  startAutoUpdateEngine();
});
